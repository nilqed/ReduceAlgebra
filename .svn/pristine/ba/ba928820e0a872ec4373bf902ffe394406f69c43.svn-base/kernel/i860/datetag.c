char * datetag ()
  { return ( 
" Wed May 11 16:07:07 1994 "
           ); } 
