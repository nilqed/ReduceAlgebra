/* 
 * sigs.c - External routines to deal with signals
 * 
 * Author:	Leigh Stoller
 * 		Computer Science Dept.
 * 		University of Utah
 * Date:	18-Aug-1986
 * 
 */

#include <signal.h>
#include <ieeefp.h>

/* Tag( psl_sigset )
 */
psl_sigset( sig, action )
void (*action)();
int sig;
{
  fpsetround(FP_RN);
  if (signal(sig, SIG_IGN) != SIG_IGN)
             signal(sig, action);
}

