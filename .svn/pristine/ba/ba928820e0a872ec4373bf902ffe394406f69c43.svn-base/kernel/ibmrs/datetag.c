char * datetag ()
  { return ( 
" Thu Jan 19 12:46:23 1995 "
           ); } 
