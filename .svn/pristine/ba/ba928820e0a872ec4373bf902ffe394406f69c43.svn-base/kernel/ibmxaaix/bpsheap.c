/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         bpsheap.c
% Description:  Code to dynamically set up bps and heap structures
% Author:       RAM, HP/FSD
% Created:      9-Mar-84
% Modified:
% Mode:         Text
% Package:
%
% (c) Copyright 1987, University of Utah, all rights reserved.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

/* Use 1 if using compacting collector ($pxnk/compact-gc.sl).
   Use 2 if using copying collector ($pnk/copying-gc.sl).
   Be sure to update $pxnk/load-psl.sl to include correct collector. */

#include <stdio.h>

#define NUMBEROFHEAPS 2

#define MINHEAPSIZE    1000000  /* Default total in number of bytes. */
#define BPSSIZE        2800000    /* Default bps size in number of bytes */
#define BPSRESERVE     10000

int     alreadysetbpsandheap;
int     max_image_size;
int     obreakvalue;
int     bpsupperbound;
int     oldbps;
int     memhigh;

extern int  alreadysetbpsandheap;
extern int  lastbps;
extern int  nextbps;
extern int  bpslowerbound;
extern int  _infbitlength_;

extern int  heaplowerbound;
extern int  heapupperbound;
extern int  heaplast;
extern int  heaptrapbound;

#if (NUMBEROFHEAPS == 1)
extern int  gcarraylowerbound;
#endif

#if (NUMBEROFHEAPS == 2)
extern int  oheaplowerbound;
extern int  oheapupperbound;
extern int  oheaplast;
extern int  oheaptrapbound;
#endif

  /* from os-hooks */
extern int bpssize,heapsize;
extern char * image,* kerneldir;


 /* Write this ourselves to keep from including half the math library */
static power(x, n)
     int x, n;
{
  int i, p;

  p = 1;
  for (i = 1; i <= n; ++i)
    p = p * x;
  return(p);
}

setbpsandheap(argc,argv)
     int argc;
     char *argv[];
{
  int    i;
  int current_size_in_bytes;
  int total;
  char * membase; int memsize,memoffs;

  if (image!=NULL) 
image_hdr();

  /* insure valid values */
  bpssize = BPSSIZE;

  if (heapsize == 0)
    heapsize = MINHEAPSIZE;


  /* On systems in which the image does not start at address 0, this won't
     really allocate the full maximum, but close enough. */
  current_size_in_bytes = (int)malloc(4); /* (int) sbrk(0); */
  max_image_size = power(2, _infbitlength_); /* 1 more than allowable size */

  if ((heapsize + bpssize + current_size_in_bytes) >= max_image_size) {
    heapsize = max_image_size - bpssize -current_size_in_bytes;
    printf("*** Size requested will result in pointer values larger than\n");
    printf("*** PSL items can handle. Will allocate maximum size instead.\n\n");
  }

  heapsize =(heapsize / 4) * 4;  /* ensure full words */
  bpssize =(bpssize / 4) * 4;

  /* printf("total heap size: %d (%X) bytes, bps size: %d (%X) bytes\n",
          heapsize,heapsize,bpssize,bpssize);
  */
  heapsize =heapsize / 2;

        /* allocate total memory */
  membase= (char*)malloc(4);   /*look where we are now*/ 
  if (image!=NULL) memoffs= memoffset(oldbps,(int)membase);
           else memoffs= BPSRESERVE;
 
  memsize= bpssize+heapsize*2+memoffs+8;
  membase = (char*)malloc(memsize);
  if ((int)membase == -1) { perror("GETBPS"); exit(-1); };

       /* now compute true final offset */
  if (image!=NULL) memoffs= memoffset(oldbps,(int)membase);
           else memoffs= BPSRESERVE;

         /* bps pointers */
  bpslowerbound = (int)membase+memoffs;
  nextbps=bpslowerbound;
  bpsupperbound  = bpslowerbound+bpssize;
  lastbps = bpsupperbound;
  
         /* heap pointers */
  heaplowerbound = lastbps+4;
  heapupperbound        = heaplowerbound + heapsize;
  heaplast              = heaplowerbound;
  heaptrapbound         = heapupperbound -120;

  oheaplowerbound    = heapupperbound;
  oheapupperbound     = oheaplowerbound + heapsize;
  oheaplast           = oheaplowerbound;
  oheaptrapbound      = oheapupperbound -120;

  memhigh             = oheaptrapbound+4;
  obreakvalue = 0;

  printf("heap size = %d LISP items\n",
                (heapupperbound-heaplowerbound)/4);
  if (image!=NULL) image_body();
  heapsize =heapsize * 2;

}

int memoffset(oldbase,actbase)
    int oldbase,actbase;
   {int d;
    d=oldbase-actbase;
    if (d<0)
    {printf("old bps %x below current free memory start %x\n",oldbase,actbase);
     printf("   cannot load image\n");
     exit(-1);};
     /* printf("memory gap: %x = %d\n",d,d); */
     return(d);
   }



allocatemorebps()
{
  int increment,x;
  char * base;
  increment= BPSSIZE/2;
  x = memhigh + increment;
  x = x % 0x7ffffff;
  increment= x - memhigh;
  increment= (increment >> 2) << 2;
  if(increment<50000)
    {printf("current model does not allow more BPS\n");
     return(-1);};
  base=(char*)malloc(increment);
  if(base==NULL)
    {printf("Operating System refuses more memory for BPS\n");
     return(-1);}
  bpslowerbound=(int) base;
  bpsupperbound=bpslowerbound+increment;
  memhigh = memhigh + increment;
  return(increment);
}


/* Tag( alterheapsize )
 */
alterheapsize(increment)
int increment;
{
}
