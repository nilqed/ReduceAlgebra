/******************************************************************************
*
* File:         os-hooks.c
* Description:  OS specific startup and cleanup hooks.
* Author:       RAM, HP/FSD
* Created:      9-Mar-84
* Modified:	15-Jul-85 10:10:51 (RAM)
* Mode:         Text
* Package:      
* Status:       Experimental (Do Not Distribute)
*
* (c) Copyright 1984, Hewlett-Packard Company, all rights reserved.
*
******************************************************************************
* Revisions:
*
******************************************************************************
*/
#include <stdio.h>
#include <setjmp.h>

int bpssize,heapsize;
char * image, * kerneldir;

jmp_buf mainenv;

int returval=0;

main(argc,argv)
int argc;
char *argv[];
{
  int val,i;
  char c;
  
  /* val=setjmp(mainenv); /* set non-local return point for exit	*/
  heapsize = bpssize = 0;
  image = kerneldir = NULL;
  versuch();
  /* e_timc ((long) 0); /* reset the timer */
  for(i=0;i<argc;i++)
   if(argv[i][0]=='-')
    {c=argv[i][1];
     if((c=='I') || (c=='i')) image=argv[i+1];
      /* if((c=='B') || (c=='b')) sscanf(argv[i+1],"%d",&bpssize); */
     if((c=='H') || (c=='h')) sscanf(argv[i+1],"%d",&heapsize);
     if((c=='K') || (c=='k')) kerneldir=argv[i+1];
    };
  /* for(i=0;i<argc;i++) printf("%s\n",argv[i]); */
  make_code();  /* ascii-ebcic code tables, in unix-io.c */
  pslmain(argc,argv);

exit(returval);

}
  

os_startup_hook(argc, argv)
     int argc;
     char *argv[];
{

  setbpsandheap(argc, argv);	/* Allocate bps and heap areas. */


}

os_cleanup_hook(retv)
{
returval = retv;
}

clear_iob()
{
}

clear_dtabsize()
{
 }

