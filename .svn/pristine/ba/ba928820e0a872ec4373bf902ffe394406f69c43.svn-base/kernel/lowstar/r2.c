#include <stdio.h>
#define LAENGE 100
#define ANZ_PRIMES 100
#define SHORT short unsigned
#define ZWEI_LAENGE 200

SHORT EINS[2];
int small_primes[ANZ_PRIMES];
main ()
{
	int i;
	SHORT a[200];
	SHORT ZWEI[2];
	SHORT b[200];
	ZWEI[0]=1;ZWEI[1]=2;
	EINS[0]=1;EINS[1]=1;
	small_primes[0] = 2;
	small_primes[1] = 3;
	small_primes[2] = 5;
	small_primes[3] = 7;
	small_primes[4] = 11;
	small_primes[5] = 13;
	small_primes[6] = 17;
	small_primes[7] = 19;
	small_primes[8] = 23;
	small_primes[9] = 29;
	small_primes[10] = 31;
	small_primes[11] = 37;
	small_primes[12] = 41;
	small_primes[13] = 43;
	small_primes[14] = 47;
	small_primes[15] = 53;
	small_primes[16] = 59;
	small_primes[17] = 61;
	small_primes[18] = 67;
	small_primes[19] = 71;
	small_primes[20] = 73;
	small_primes[21] = 79;
	small_primes[22] = 83;
	small_primes[23] = 89;
	small_primes[24] = 91;
	small_primes[25] = 97;
	small_primes[26] = 101;
	small_primes[27] = 103;
	small_primes[28] = 107;
	small_primes[29] = 109;
	small_primes[30] = 113;
	small_primes[31] = 127;
	small_primes[32] = 131;
	small_primes[33] = 137;
	small_primes[34] = 139;
	small_primes[35] = 149;
	small_primes[36] = 151;
	small_primes[37] = 157;
	small_primes[38] = 163;
	small_primes[39] = 167;
	small_primes[40] = 173;
	small_primes[41] = 179;
	small_primes[42] = 181;
	small_primes[43] = 191;
	small_primes[44] = 193;
	small_primes[45] = 197;
	small_primes[46] = 199;
	small_primes[47] = 211;
	small_primes[48] = 223;
	small_primes[49] = 227;
	small_primes[50] = 229;
	small_primes[51] = 233;
	small_primes[52] = 239;
	small_primes[53] = 241;
	small_primes[54] = 251;
	small_primes[55] = 257;
	small_primes[56] = 263;
	small_primes[57] = 269;
	small_primes[58] = 271;
	small_primes[59] = 277;
	small_primes[60] = 281;
	small_primes[61] = 283;
	small_primes[62] = 293;
	small_primes[63] = 307;
	small_primes[64] = 311;
	small_primes[65] = 313;
	small_primes[66] = 317;
	small_primes[67] = 331;
	small_primes[68] = 337;
	small_primes[69] = 347;
	small_primes[70] = 349;
	small_primes[71] = 353;
	small_primes[72] = 359;
	small_primes[73] = 367;
	small_primes[74] = 373;
	small_primes[75] = 379;
	small_primes[76] = 383;
	small_primes[77] = 389;
	small_primes[78] = 397;
	small_primes[79] = 401;
	small_primes[80] = 409;
	small_primes[81] = 419;
	small_primes[82] = 421;
	small_primes[83] = 431;
	small_primes[84] = 433;
	small_primes[85] = 439;
	small_primes[86] = 443;
	small_primes[87] = 449;
	small_primes[88] = 457;
	small_primes[89] = 461;
	small_primes[90] = 463;
	small_primes[91] = 467;
	small_primes[92] = 479;
	small_primes[93] = 487;
	small_primes[94] = 491;
	small_primes[95] = 499;
	small_primes[96] = 503;
	small_primes[97] = 509;
	small_primes[98] = 521;
	small_primes[99] = 523;
	readue("Miller-Rabin-Test : Berechne alle Primzahlen >= ",a);
	readue("                                             <= ",b);
	if (a[1] % 2 == 0)
		++a[1];
	while (comp(a,b) == 1) {
		if (rabin(a))
			writeue("",a);
		add(a,ZWEI,a);
	}	
#ifdef STAT
	STATISTIK();
#endif		
}

rabin(operand)
SHORT operand[];
{
	int retcod,i,j,k,tes;
	SHORT zahl[ZWEI_LAENGE],b[ZWEI_LAENGE],pot[ZWEI_LAENGE],vergleich[ZWEI_LAENGE];
	b[0]=1;
	retcod = 1;
	k=0;
	sub(operand,EINS,zahl);
	while (zahl[1] % 2 == 0) {
		++k;
		shift(zahl,-1,zahl);
	}

	/* Waehle b */
	for (i=0;((i<10) && (retcod));i++) {

		b[1]=small_primes[i]; /* Waehle Basis b */
		/* Berechne b^Zahl mod operand */
		mexp(b,zahl,pot,operand);
		if (test(pot,operand))
			continue;
		retcod = 0;
		for (j=0;j<k;++j) {
			mmult(pot,pot,pot,operand);
			tes = test(pot,operand);
			if (tes == -1) {
				retcod = 1;
				break;
			}
			if (tes == 1)
				/* d.h. 1 erscheint vor -1; d.h. operand nicht prim */
				return(0);
		}
		if (!retcod)
			return(0);
	}
	return(1);
}		
	
test(zahl,modul)
int zahl[], modul[];
/* teste, ob zahl == 1 mod modul ist   --> retcod = 1
	     zahl == -1 mod modul      --> retcod = -1
		     sonst                 retcod = 0
*/
{
	SHORT rest[ZWEI_LAENGE];
	div(zahl,modul,rest,rest);
	if ((rest[0] == 1) && (rest[1] == 1))
		return(1);
	sub(modul,rest,rest);
	if ((rest[0] == 1) && (rest[1] == 1))
		return(-1);
	return(0);
}		


