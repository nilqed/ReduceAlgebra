#include <stdio.h>
#define SHORT short unsigned
#define LAENGE 100
#define ZWEI_LAENGE 200
#define EINGABE_LAENGE 1000         /* Fuer Stringeingabe mit gets */
#define STRING_ENDE 0               /* Erkennung des Stringendes nach Einlese*/
#define BITS 16                     /* Anzahl verwendeter Bits pro Langwort */
				    /* Die Multiplikation zweier Langwoerter sollte */
				    /* problemlos ausgefuehrt werden koennen */
#define HOEHE_ZEHN_POTENZ 10000	    /* groesste Zehner-potenz < ZWEI_HOCH_BITS */
#define ZEHN_POTENZ 4		    /* entsprechender Exponent zur Basis 10 */	
#define ZWEI_HOCH_BITS 0x10000      /* Zum Testen auf Overflow */
#define HOECHST_BIT 0x8000
#define OVERFLOW_LOESCH 0xffff      /* Zum Loeschen eines Overflow-Bits;
				       OVERFLOW_LOESCH = 2^BITS- 1       */
#define AUS_FORMAT "%09u"
#define LOW_AUS_ZEHNPOTENZ 0xca00
#define HIGH_AUS_ZEHNPOTENZ 0x3b9a
#define AUS_LAENGE 1000

/* Beschreibung des Moduls :
   Lange Zahlen, a, sind vom Datentyp int a[100]. Intern stellen wir sie allerdi
   durch short unsigned a[200] dar, was denselben Speicherplatz wie int a[100]
   belegt. Dabei steht in a[0] die genaue Laenge
   der Zahl.
   Beispiel : a[0] = 3
	      a[1] = 1
	      a[2] = 2
	      a[3] = 3
	      Dann bezeichnet a die ganze Zahl
		 1 + 2*2^16 + 3*(2^16)^2

   Auf diesen langen Zahlen sind folgende Funktionen definiert :

	ARITHMETIK :

	Addition       : add(summand1,summand2,ergebnis)

	Subtraktion    : sub(operand1,operand2,ergebnis)
		Returncode  0 falls Subtraktion erfolgreich
			   -1 falls der zweite Operand groesser als der erste war.
			      In diesem Fall hat ergebnis keinen definierten Wert!!

	Multiplikation : mult(operand1,operand2,ergebnis)

	Shift          : shift(operand1,operand2,ergebnis)
		Hier ist operand2 vom Typ int !!!

	Division       : div(divident,divisor,quotient,rest)
		Returncode  0 falls Division erfolgreich
			   -1 falls Division durch 0 auftrat

	Vergleich      : comp(zahl1,zahl2)
		Returncode -1 falls zahl1 > zahl2
			    0 falls zahl1 = zahl2
		           +1 falls zahl1 < zahl2

	Kopieren       : trans(zahl1,zahl2)

	Zuweisung      : zuweis(zahl1,zahl2)
			 zahl1 vom Typ SHORT, zahl2 lang
			 Zuweisung : zahl2 := zahl1	

	Zufallszahlen  : zufall(zahl,minlaenge,maxlaenge)
		Eingabe : zwei Grenzen minlaenge <= maxlaenge
			  beide vom Typ SHORT

		Ausgabe : zahl vom Typ lange Zahl, deren Laenge
			  zwischen minlaenge und maxlaenge liegt.


	MODULOARITHMETIK :

	Moduloaddition       : madd(operand1,operand2,ergebnis,modul)

	Modulosubtraktion    : msub(operand1,operand2,ergebnis,modul)

	Modulomultiplikation : mmult(operand1,operand2,ergebnis,modul)

	Modulodivision       : mdiv(operand1,operand2,ergebnis,modul)
		Returncode  0 falls ggT(operand2,modul) teilt operand1
			   -1 falls Division nicht moeglich

	Moduloexponentiation : mexp(operand1,operand2,ergebnis,modul)

	GGT                  : GGT(operand1,modul,ergebnis,invers)
		berechnet ergebnis = ggT(operand1,modul)
		invers mod modul mit operand1*invers = ergebnis mod modul


	EIN-/AUSGABE (dezimal):

	Einlesen : readue(text,zahl)

	Ausgabe  : writeue(text,zahl)


Programmiert von
			Wolfgang Kampkoetter
			Universitaet Gesamthochschule Essen
			Fachbereich 6, Mathematik
			Raum T03 R02 C02
			Universitaetsstr. 3
			4300 Essen 1
			Tel.: (0201) 183-2529

*/

/* Folgende Variablen sind fuer statistische Auswertungen. Statistische Auswertu
werden nur dann gemacht, wenn mit der Compileroption -DSTAT compiliert wird */

#ifdef STAT
	int ANZ_ADD = 0;
	int ANZ_SUB = 0;
	int ANZ_MULT = 0;
	int ANZ_SHIFT = 0;
	int ANZ_DIV = 0;
	int ANZ_COMP = 0;
	int ANZ_TRANS = 0;
#endif

add(summand1,summand2,ergebnis)
SHORT summand1[],summand2[],ergebnis[];
{
	unsigned carry;
	SHORT i,laenge1,laenge2;
	SHORT *s1,*s2,*summe;
#ifdef STAT
	++ANZ_ADD;
#endif		
	summe = ergebnis + 1;
	if (*summand1 > *summand2) {
		s1 = summand1;
		s2 = summand2;
	}
	else {
		s1 = summand2;
		s2 = summand1;
	}
	/* s1 zeigt auf die laengere der beiden Zahlen */
	laenge1 = *s1++;  /* s1 zeigt auf die Laenge des Summanden. Diese wird */
	laenge2 = *s2++;  /* ausgelesen und anschliessend der Zeiger inkrementiert,
			     d.h. auf das erste Wort des Summanden positioniert */

	/* Es ist laenge1 >= laenge2 */
	carry = 0;
	 /* Addiere zunaechst bis laenge2 */
	 for (i=1;i <= laenge2;i++) {
		carry += *s1++ + *s2++; /* Addiere die Woerter, auf die s1 bzw. s2
					   zeigen und den carry. Inkrementiere die
					   Zeiger s1 und s2  */
		*summe++ = carry;
		carry >>= BITS;  
	}
	/* s2 ist hier erschoepft; zu addieren ist also, falls s1 noch nicht
	   erschoepft ist, ggf. der carry. */

	/* carry == 0 oder 1 */
	for (;(i <= laenge1) && (carry);i++) {
		carry += *s1++;
		*summe++ = carry;
		carry >>= BITS;
	}
	/* Nach Verlassen dieser Schleife ist carry == 0 oder i > laenge1 */

	/* Falls i <= laenge1, muss der Rest noch kopiert werden */
	for (;i <= laenge1;i++)
		*summe++ = *s1++;
	
	/* Teste auf carry != 0 */
	if (carry) {  /* dann ist carry == 1 */
		if ((*ergebnis = laenge1 + 1) >= ZWEI_LAENGE)
			overflow("add : Overflow");
		*summe = 1;
	}
	else
		*ergebnis = laenge1;
}

sub(operand1,operand2,ergebnis)
SHORT operand1[],operand2[],ergebnis[];
{
	unsigned carry;
	SHORT i,laenge1,laenge2;
	SHORT *s1,*s2,*diff;

#ifdef STAT
	++ANZ_SUB;
#endif		
	laenge1 = *operand1;
	laenge2 = *operand2;
	if (laenge1 < laenge2)
		return(-1);  /* Ergebnis waere negativ */
	s1 = operand1 + 1;
	s2 = operand2 + 1;
	
	/* Hier gilt nun laenge1 >= laenge2 */
	diff = ergebnis + 1;
	carry = 0;

	for (i = 1;i <= laenge2;i++) {
		carry = *s1++ - *s2++ - carry;
		*diff++ = carry;
		carry = (carry >= ZWEI_HOCH_BITS) ? 1 : 0;
	}
	/* s2 ist hier erschoepft */

	/* carry == 0 oder 1 */
	for (;(i <= laenge1) && (carry);i++) {
		carry = *s1++ - carry;
		*diff++ = carry;
		carry = (carry >= ZWEI_HOCH_BITS) ? 1 : 0;
	}
	/* Ab hier ist carry == 0 */

	/* kopiere den Rest */
	for (;(i <= laenge1);i++)
		*diff++ = *s1++;
	
	/* Teste auf carry != 0 */
	if (carry)    /* d.h. ergebnis waere negativ */
		return(-1);
	
	/* die Laenge des Ergebnisses ist <= laenge1 */
	while ((!(*--diff)) && (laenge1))
		--laenge1;
	
	/* Speichere die Laenge ab */
	*ergebnis = laenge1;
	return(0);
}		

mult(operand1,operand2,ergebnis)
SHORT operand1[],operand2[],ergebnis[];
{
	unsigned m;
	SHORT i,j,faktor,laenge1,laenge2,stellen;
	SHORT *f1,*f2,*prod,*produkt,*faktor1,*faktor2;
	SHORT erg[ZWEI_LAENGE];

#ifdef STAT
	++ANZ_MULT;
#endif		
	if (*operand1 > *operand2) {
		faktor1 = operand1;
		faktor2 = operand2;
	}
	else {
		faktor1 = operand2;
		faktor2 = operand1;
	}
	laenge1 = *faktor1++;
	laenge2 = *faktor2;
	/* Hier gilt : laenge1 >= laenge2 >= 0 */

	/* Falls einer der beiden Faktoren gleich 0 ist, so auch das Produkt */
	if (!laenge2) {
		*ergebnis = 0;
		return;
	}

	/* Jetzt ist laenge1 >= laenge2 >= 1 */
	stellen = laenge1 + laenge2;
	/* Die maximale Laenge des Produktes einer m-stelligen mit einer
	   n-stelligen Zahl ist m+n, die minimale Laenge m+n-1 */

	if (stellen >= ZWEI_LAENGE)
		overflow("mult : Overflow");
	
	/* Teste, ob laenge2 == 1; falls ja, speichere sofort in ergebnis */

	if (laenge2 == 1) {
		m = 0;
		faktor = *(faktor2 + 1);
		prod = ergebnis + 1;
		for (i = 1;i <= laenge1;i++) {
			m += (*faktor1++) * faktor;
			*prod++ = m;
			m >>= BITS;

		}
		if (m) {
			*prod = m;
			*ergebnis = stellen;
		}		
		else
			*ergebnis = stellen - 1;
		return;
	}		

	/* Ab jetzt gilt sogar laenge2 >= 2 */

	/* Multiplikation von operand1 mit der vorletzten Stelle von operand2 */
	m = 0;
	f1 = faktor1;
	f2 = faktor2 + 2;
	faktor = *f2++;
	prod = erg + 2;

	for (i = 1;i <= laenge1;i++) {
		m += (*f1++) * faktor;
		*prod++ = m;
		m >>= BITS;
	}
	/* i = laenge1 + 1 */
	*prod++ = m;
	/* Loesche nun die von der vorigen Multiplikation nicht beruehrten Worte */
/*	for (;i < stellen - 1;i++)
		*prod++ = 0;	*/

	m = 0;
	for (j = 3;j <= laenge2;j++) {
		prod = erg + j;
		faktor = *f2++;
		f1 = faktor1;
		for (i = 1;i <= laenge1;i++) { /* Zu Beginn dieser Schleife ist m == 0 */
			m += ((*f1++) * faktor + *prod);
			*prod++ = m;
			m >>= BITS;
		}
		/* Speichere Uebertrag der letzten Multiplikation */
/*		while (m) {
			m += *prod;
			*prod++ = m;
			m >>= BITS;
		}*/
		*prod = m;
		m = 0;
		/* Im Anschluss ist m == 0 fuer naechste Iteration */
	}

	/* Noch fehlt die Multiplikation von operand1 mit operand2[1] */
	/* Es ist m == 0 */
	faktor = *(faktor2 + 1);
	f1 = faktor1;
	prod = erg + 2;
	produkt = ergebnis + 1;
	m = (*f1++) * faktor;
	*produkt++ = m;
	m >>= BITS;
	for (i = 2;i <= laenge1;i++) {
		m += ((*f1++) * faktor + (*prod++));
		*produkt++ = m;
		m >>= BITS;
	}
	/* Jetzt ist i = laenge1 + 1 */
	for (;(m);i++) {
		m += *prod++;
		*produkt++ = m;
		m >>= BITS;
	}
	/* Jetzt ist m == 0; copiere letzte Stellen von erg --> ergebnis */

	for (;i <= stellen;i++)
		*produkt++ = *prod++;
	
	/* prod zeigt nun zu weit vor erg; daher predekrement */
	*ergebnis = (*--produkt) ? (stellen) : (stellen - 1);	
}		

shift(operand1,operand2,ergebnis)
SHORT operand1[];
int operand2;
SHORT ergebnis[];
{
	SHORT rest,bitsminusrest,zwischen;
	int anzahl_woerter,laenge,i,j;
	SHORT *op1,*erg;

#ifdef STAT
	++ANZ_SHIFT;
#endif		
	if (operand2 < 0) { /* Rechtsshift */
		operand2 = -operand2;
		anzahl_woerter = operand2 / BITS;
		rest = operand2 % BITS;
		laenge = *operand1 - anzahl_woerter;

		if (laenge <= 0) {  /* ergebnis == 0 */
			*ergebnis = 0;
			return;
		}		

		op1 = operand1 + anzahl_woerter + 1;
		erg = ergebnis + 1;
		if (!rest) {
			for (i=0;i < laenge;i++)
				*erg++ = *op1++;
			*ergebnis = laenge;
			return;
		}

		/* Es verbleibt der Fall rest != 0 */
		
		bitsminusrest = BITS - rest;
		for (i=1;i<laenge;i++) {
			zwischen = *op1++ >> rest;		
			*erg++ = zwischen | (*op1 << bitsminusrest);
		}	
		if (!(*erg = *op1 >> rest))
			--laenge;
		*ergebnis = laenge;
	}		
	else { /* Linksshift */
		anzahl_woerter = operand2 / BITS;
		rest = operand2 % BITS;
		if ((laenge = anzahl_woerter + *operand1 + 1) >= ZWEI_LAENGE) /* Overflow */
			overflow("Links-Shift : Overflow");

		op1 = operand1 + *operand1;
		erg = ergebnis + laenge;
		
		if (!rest) {
			++op1;
			for (i=1;i<=*operand1;i++)
				*--erg = *--op1;
			/* setze uebersprungene Woerter auf 0 */
			for (;i<laenge;i++)
				*--erg = 0;
			*ergebnis = laenge - 1;
			return;
		}

		/* Es verbleibt der Fall rest != 0 */
		
		bitsminusrest = BITS - rest;
		
		*erg = *op1 >> bitsminusrest;

		for (i=1;i<*operand1;i++) {
			zwischen = *op1 << rest;
			*--erg = zwischen | (*--op1 >> bitsminusrest);
		}
		*--erg = *op1 << rest;
		i++;
		for (;i<laenge;i++)
			*--erg = 0;
		if (*(ergebnis+laenge))
			*ergebnis = laenge;
		else
			*ergebnis = laenge - 1;
	}
}

div(divident,divisor,quotient,rest)
SHORT divident[],divisor[],quotient[],rest[];
{
	int normal_shifts,i,j;
	unsigned two_digits,zw_mult,vergleich,zus_vergleich,carry;
	SHORT first_digit,second_digit,zlaenge,nlaenge,qlaenge,r,q_hat;
	SHORT zaehler[ZWEI_LAENGE],nenner[ZWEI_LAENGE],zwischen[ZWEI_LAENGE];
	SHORT *zzeiger,*zus_zzeiger,*nzeiger,*zwzeiger,*qzeiger;

#ifdef STAT
	++ANZ_DIV;
#endif		
	nlaenge = *divisor;
	if (!nlaenge)
		return(-1);   /* Division durch 0 */
	/* Vergleich auf Nenner > Zaehler */

	if (comp(divident,divisor) == 1) { /* quotient == 0 */
		zlaenge = *divident++;

		*quotient = 0;
		*rest++ = zlaenge;
		for (i=0;i < zlaenge;i++)
			*rest++ = *divident++;
		return(0);
	}
	/* Normalisierung */
	/* Berechne Normalisierungsfaktor */
	normal_shifts = 0;
	i = *(divisor + nlaenge);
	j = HOECHST_BIT;
	while (i < j) {
		i <<= 1;
		++normal_shifts;
	}
	/* Normalisierung : first_digit von divisor sollte >= ZWEI_HOCH_BITS/2 sein */
	zlaenge = *divident + 1;
	if (zlaenge >= ZWEI_LAENGE)
		overflow("div : Overflow bei Normalisierung");
	
	zaehler[zlaenge] = 0;
	shift(divident,normal_shifts,zaehler);
	zlaenge = *divident + 1;
	/* zaehler[zlaenge] ist auf jeden Fall wohldefiniert !!
	   Falls *zaehler = zlaenge, dann auf jeden Fall.
	   Sonst wurde bei der Linksshift-Operation (auch im Fall normal_shifts == 0)
	   zaehler[zlaenge] auf 0 gesetzt */

	if (zlaenge >= ZWEI_LAENGE)
		overflow("div : Overflow bei Normalisierung");
			
	shift(divisor,normal_shifts,nenner);
	/* Nun ist die genaue Laenge des Quotienten gleich zlaenge - nlaenge */
	qlaenge = zlaenge - nlaenge;
	qzeiger = quotient + qlaenge;

	if (nlaenge == 1) {
		/* spezieller Algorithmus */
		first_digit = *(nenner + 1);
		zzeiger = zaehler + zlaenge;
		two_digits = *zzeiger--;
		for (i = 0;i < qlaenge;i++) {
			two_digits = (two_digits << BITS) + *zzeiger--;
			*qzeiger-- = two_digits / first_digit;
			two_digits %= first_digit;
		}
		*quotient = (*(quotient + qlaenge)) ? (qlaenge) : (qlaenge - 1) ;
		
		if (two_digits) {
			*rest++ = 1;
			*rest = two_digits >> normal_shifts;
		}
		else
			*rest = 0;
		return(0);		
	}

	/* Algorithmus fuer divisor [0] > 1 */
	
	first_digit = *(nenner + nlaenge);
	second_digit = *(nenner + nlaenge - 1);
	zzeiger = zaehler + zlaenge;

	for (j = 1;j <= qlaenge;j++) {
		/* Berechne q_hat */

		/* erste Naeherung */
		two_digits = (*zzeiger << BITS) + *(zzeiger - 1);
		if (*zzeiger == first_digit)
			q_hat = OVERFLOW_LOESCH;
		else
			q_hat = two_digits / first_digit;
		zw_mult = second_digit * q_hat;
		vergleich = two_digits - q_hat * first_digit;
		if (vergleich <= OVERFLOW_LOESCH) {
			vergleich = (vergleich << BITS) + *(zzeiger - 2);
			while (zw_mult > vergleich) {
				--q_hat;   /* q_hat war zu gross */
				zw_mult -= second_digit;
				zus_vergleich = vergleich + (first_digit << BITS);
				if (zus_vergleich < vergleich)
					/* d.h. overflow bei addition;
				   	   dann ist q_hat richtig gewaehlt bezueglich
				   	   dieses Tests. Denn zw_mult < Basis^2 */
					break;
				else
					vergleich = zus_vergleich;
			}  /* nun ist q_hat fast richtig gewaehlt*/
		}		
		if (q_hat) {
			/* Multipliziere nun den nenner mit q_hat; ergebnis -> zwischen */
			zw_mult = 0;
			zwzeiger = zwischen + 1;
			nzeiger = nenner + 1;
			for (i = 1;i <= nlaenge;i++) {
				zw_mult += (*nzeiger++) * q_hat;
				*zwzeiger++ = zw_mult;
				zw_mult >>= BITS;
			}
			*zwzeiger = zw_mult;
			
			/* Die Laenge von zwischen ist jetzt nlaenge + 1; ggf. mit fuehrender 0 */
			zus_zzeiger = zzeiger - nlaenge;
			zwzeiger = zwischen + 1;
			carry = 0;
			for (i = 0;i <= nlaenge;i++) {
				carry = *zus_zzeiger - *zwzeiger++ - carry;
				*zus_zzeiger++ = carry;
		                carry = (carry >= ZWEI_HOCH_BITS) ? 1 : 0;
			}
			if (carry) {
				/* ist das Ergebnis negativ, dann ist q_hat
				   immer noch zu gross */
				--q_hat;
				/* addiere nenner auf vorheriges Ergebnis */
				carry = 0;
				nzeiger = nenner + 1;
				zus_zzeiger = zzeiger - nlaenge;
				for (i = 0;i <= nlaenge;i++) {
					carry += *zus_zzeiger + *nzeiger++;
					*zus_zzeiger++ = carry;
					carry >>= BITS;
				}
			}
			*zus_zzeiger += carry;
		}
		/* Nun ist q_hat exakt bestimmt */
		*qzeiger-- = q_hat;
		--zzeiger;
	}
	/* Laengenanpassung */
	while (!(*(quotient + qlaenge)))
		--qlaenge;  /* qlaenge > 0 wegen Zaehler > nenner */
	*quotient = qlaenge;   /* Laengenspeicherung */
	/* Quotient ist berechnet */

	/* Berechne den Rest */
	/* Restlaenge <= nlaenge */
	zzeiger = zaehler + nlaenge;
	while (!(*zzeiger--))
		--nlaenge;
	*zaehler = nlaenge;
	shift(zaehler,-normal_shifts,rest);
	return(0);
}		
				
comp(zahl1,zahl2)
SHORT zahl1[],zahl2[];
{
	int i,null;
	SHORT laenge;

#ifdef STAT
	++ANZ_COMP;
#endif		
	if (*zahl1 < *zahl2)  /* Zahl1 < Zahl2 */
		return(1);
	if (*zahl1 > *zahl2)  /* Zahl1 > Zahl2 */
		return(-1);
	laenge = *zahl2;
	zahl1 += laenge;
	zahl2 += laenge;
	null = 0;
	for (i = 0;(i < laenge) && (!null);i++)
		/* Teste, wann das erste Mal etwas von null verschiedenes
		   bei folgender Multiplikation erscheint */
		null = *zahl1-- - *zahl2--;
	if (null < 0) /* Zahl1 < Zahl2 */
		return(1);
	if (null > 0) /* Zahl1 > Zahl2 */
		return(-1);
	else
		return(0);
}

trans(zahl1,zahl2)
SHORT zahl1[],zahl2[];
{
	int i;
	SHORT laenge;

#ifdef STAT
	++ANZ_TRANS;
#endif		
	laenge = *zahl1;
	for (i = 0;i <= laenge;i++)
		*zahl2++ = *zahl1++;
}

zuweis(zahl1,zahl2)
SHORT zahl1,zahl2[];
{
	if (zahl1) {
		zahl2[0] = 1;
		zahl2[1] = zahl1;
	}
	else
		zahl2[0] = 0;
}

zufall(zahl,minlaenge,maxlaenge)
SHORT zahl[],minlaenge,maxlaenge;
{
	int i;
	SHORT *zeiger;
	if (maxlaenge > LAENGE)
		maxlaenge = LAENGE;
	if (minlaenge > maxlaenge)
		overflow("Zufall : minlaenge > maxlaenge");
	do {
		zeiger = zahl + 1;
		for (i=1;i<=maxlaenge;i++)
			*zeiger++ = rand() % ZWEI_HOCH_BITS;
		*zahl = maxlaenge;
		while ((!(*--zeiger)) && (*zahl))
			--(*zahl);
	} while (*zahl < minlaenge);
}	

madd(operand1,operand2,ergebnis,modul)
SHORT operand1[],operand2[],ergebnis[],modul[];
/* Wir werden zwei Faelle unterscheiden :
   - eine der beiden Summanden ist >= modul
   - beide Summanden sind < modul */
{
	SHORT erg[ZWEI_LAENGE];

	if ((comp(operand1,modul) <= 0) || (comp(operand2,modul) <= 0)) {
	
		/* d.h. operand1 >= modul oder operand2 >= modul;
		   in diesem Fall ist auf jeden Fall eine Division notwendig.
		   Wir addieren aber zuerst die Summanden und dividieren dann. */
		
		add(operand1,operand2,erg);	
		if (div(erg,modul,ergebnis,ergebnis) == -1)
			overflow("madd : modul == 0");
	}
	
	else {
		/* Schnellere Addition : Hier sind beide Summand kleiner als modul.
		   Daher ist ihre Summe kleiner als 2*modul; von der Summe muss daher
		   hoechstens modul subtrahiert; die Division wird hier gespart. */
		
		add(operand1,operand2,erg);
		if (comp(erg,modul) <= 0)
			/* d.h. die Subtraktion ist erforderlich */
			sub(erg,modul,ergebnis);
		else
			trans(erg,ergebnis);
	}
}		

msub(operand1,operand2,ergebnis,modul)
SHORT operand1[],operand2[],ergebnis[],modul[];
{
	SHORT summand1[ZWEI_LAENGE],summand2[ZWEI_LAENGE],erg[ZWEI_LAENGE];
	if (comp(operand1,operand2) <= 0) { /* d.h. operand1 >= operand2 */
		sub(operand1,operand2,erg);

		/* reduziere erg modulo modul */			
		if (comp(erg,modul) <= 0) { /* d.h. erg >= modul */
			if (div(erg,modul,ergebnis,ergebnis))
				overflow("msub : Modul == 0");
		}
		else
			trans(erg,ergebnis);
	}			
	else { /* d.h operand2 > operand1 */
		sub(operand2,operand1,erg);
		/* reduziere erg modulo modul */
		if (comp(erg,modul) < 0) { /* d.h. erg > modul */
			if (div(erg,modul,erg,erg))
				overflow("msub : Modul == 0");
		}
		/* jetzt ist 0 <= erg <= modul */
		if (!*erg) /* d.h. erg == 0 */
			*ergebnis = 0;
		else
			sub(modul,erg,ergebnis);
	}
}		

mmult(operand1,operand2,ergebnis,modul)
SHORT operand1[],operand2[],ergebnis[],modul[];
{
	SHORT erg[ZWEI_LAENGE],faktor1[ZWEI_LAENGE],faktor2[ZWEI_LAENGE];
	if (*operand1 <= *modul) {/* d.h. die Laenge von operand1 <= Laenge von modul */
		if (*operand2 <= *modul) {
			mult(operand1,operand2,erg);
			if (div(erg,modul,ergebnis,ergebnis) == -1)
				overflow("mmult : modul == 0");
			return;
		}
		else { /* d.h. operand2 >> modul : reduziere erst operand2 */
			if (div(operand2,modul,faktor2,faktor2) == -1)
				overflow("mmult : modul == 0");
			mult(operand1,faktor2,erg);
			div(erg,modul,ergebnis,ergebnis);
			return;
		}
	}
	else {
		if (div(operand1,modul,faktor1,faktor1) == -1)
			overflow("mmult : modul == 0");
		if (*operand2 <= *modul) {
			mult(faktor1,operand2,erg);
			div(erg,modul,ergebnis,ergebnis);
			return;
		}
		else {
			div(operand2,modul,faktor2,faktor2);
			mult(faktor1,faktor2,erg);
			div(erg,modul,ergebnis,ergebnis);
		}
	}
}

GGT(operand1,modul,ergebnis,invers)
SHORT operand1[],modul[],ergebnis[],invers[];
/* Berechne den ggt von operand1 und modul; berechne ferner invers mod modul mit
   der Eigenschaft invers * operand1 = ggt mod modul;
   invers ueberschreibt ggf. ergebnis */
{
	SHORT ggt1[ZWEI_LAENGE],ggt2[ZWEI_LAENGE];
	SHORT invers1[ZWEI_LAENGE],invers2[ZWEI_LAENGE];
	SHORT faktor[ZWEI_LAENGE],zwischen[ZWEI_LAENGE];
	int welcher;

	if (div(operand1,modul,ggt2,ggt2) == -1) /* berechne ggt2 = operand1 mod modul
		overflow("GGT : modul == 0");
	if (!ggt2[0]) /* d.h. ggt2 = 0 */
		return(-1); /* in diesem Fall ist ggt = modul */
			
	trans(modul,ggt1);
	invers1[0] = 0;
	invers2[0] = 1;
	invers2[1] = 1;
	welcher = 0;
	while (!welcher) {
		div(ggt1,ggt2,faktor,ggt1);
		if (!ggt1[0]) {
			welcher = 2;
			break;
		}
		mmult(faktor,invers2,zwischen,modul);
		msub(invers1,zwischen,invers1,modul);
		div(ggt2,ggt1,faktor,ggt2);
		if (!ggt2[0])
			welcher = 1;
		else {
			mmult(faktor,invers1,zwischen,modul);
			msub(invers2,zwischen,invers2,modul);
		}
	}
	switch (welcher) {
		case 1 : trans(ggt1,ergebnis);
			 trans(invers1,invers);
			 break;
		case 2 : trans(ggt2,ergebnis);
		         trans(invers2,invers);
			 break;
	}
	return(0);
}

WGGT(operand1,modul,modulexp,ergebnis,invers)
SHORT operand1[],modul[];
int modulexp;
SHORT ergebnis[],invers[];
/* Berechne den ggt von operand1 und modul; berechne ferner invers mod modul mit
   der Eigenschaft invers * operand1 = ggt mod modul;
   invers ueberschreibt ggf. ergebnis */
{
	SHORT ggt1[ZWEI_LAENGE],ggt2[ZWEI_LAENGE];
	SHORT invers1[ZWEI_LAENGE],invers2[ZWEI_LAENGE];
	SHORT faktor[ZWEI_LAENGE],zwischen[ZWEI_LAENGE];
	int welcher;

	trans(operand1,ggt2);
	if (*ggt2 > modulexp) {
		*ggt2 = modulexp;
		while ((!ggt2[*ggt2]) && (*ggt2))
			--(*ggt2);
	}			
	
	if (!ggt2[0]) /* d.h. ggt2 = 0 */
		return(-1); /* in diesem Fall ist ggt = modul */
			
	trans(modul,ggt1);
	invers1[0] = 0;
	invers2[0] = 1;
	invers2[1] = 1;
	welcher = 0;
	while (!welcher) {
		div(ggt1,ggt2,faktor,ggt1);
		if (!ggt1[0]) {
			welcher = 2;
			break;
		}
		mult(faktor,invers2,zwischen);
		if (*zwischen > modulexp) {
			*zwischen = modulexp;
			while ((!zwischen[*zwischen]) && (*zwischen))
				--(*zwischen);
		}			
		msub(invers1,zwischen,invers1,modul);
		div(ggt2,ggt1,faktor,ggt2);
		if (!ggt2[0])
			welcher = 1;
		else {
			mult(faktor,invers1,zwischen);
			if (*zwischen > modulexp) {
				*zwischen = modulexp;
				while ((!zwischen[*zwischen]) && (*zwischen))
					--(*zwischen);
			}
			msub(invers2,zwischen,invers2,modul);
		}
	}
	switch (welcher) {
		case 1 : trans(ggt1,ergebnis);
			 trans(invers1,invers);
			 break;
		case 2 : trans(ggt2,ergebnis);
		         trans(invers2,invers);
			 break;
	}
	return(0);
}

mdiv(operand1,operand2,ergebnis,modul)
SHORT operand1[],operand2[],ergebnis[],modul[];
/* Berechne zunaechst den ggt(operand2,modul) zusammen mit einer langen Zahl inv
   mit der Eigenschaft operand2*invers = ggt(..) mod modul.
   Fall ggt(..) | operand1, dann ist ergebnis = (operand1/ggt) * invers mod modu */
{
	SHORT ggt[ZWEI_LAENGE],invers[ZWEI_LAENGE],quotient[ZWEI_LAENGE],rest[ZWEI_LAENGE];
	/* Berechne zunaechst den ggt von operand2 und modul */
	if (!operand2[0])
		return(-1);
	if (GGT(operand2,modul,ggt,invers) == -1)
		/* in diesem Fall ist ggt(..) = modul, d.h. modul teilt operand2, d.h
		   operand2 = 0 mod modul */
		return(-1);
	div(operand1,ggt,quotient,rest);
	if (rest[0])
		/* d.h. rest != 0 */
		return(-1);
	else {
		mmult(quotient,invers,ergebnis,modul);
		return(0);
	}
}		

MBPOTMULT(operand1,operand2,ergebnis,exponent)
/* Modulo-Multiplikation modulo (2^BITS)^exponent */
/* Zunaechst einfache Loesung : Laengenanpassung */
SHORT operand1[],operand2[],ergebnis[],exponent;
{
	mult(operand1,operand2,ergebnis);
	if (*ergebnis > exponent) {
		*ergebnis = exponent;
		while (!ergebnis[*ergebnis] && *ergebnis)
			--(*ergebnis);
	}
}		

MONTGGT(operand1,modul,modulexp,ergebnis,invers)
SHORT operand1[],modul[];
SHORT modulexp;
SHORT ergebnis[],invers[];
/* Berechne den ggt von operand1 und modul; berechne ferner invers mod modul mit
   der Eigenschaft invers * operand1 = ggt mod modul;
   invers ueberschreibt ggf. ergebnis */
{
	SHORT ggt1[ZWEI_LAENGE],ggt2[ZWEI_LAENGE];
	SHORT invers1[ZWEI_LAENGE],invers2[ZWEI_LAENGE];
	SHORT faktor[ZWEI_LAENGE],zwischen[ZWEI_LAENGE];
	int welcher;

	trans(operand1,ggt2);
	if (*ggt2 > modulexp) {
		*ggt2 = modulexp;
		while ((!ggt2[*ggt2]) && (*ggt2))
			--(*ggt2);
	}			
	
	if (!ggt2[0]) /* d.h. ggt2 = 0 */
		return(-1); /* in diesem Fall ist ggt = modul */
			
	trans(modul,ggt1);
	invers1[0] = 0;
	invers2[0] = 1;
	invers2[1] = 1;
	welcher = 0;
	while (!welcher) {
		div(ggt1,ggt2,faktor,ggt1);
		if (!ggt1[0]) {
			welcher = 2;
			break;
		}
		mult(faktor,invers2,zwischen);
		if (*zwischen > modulexp) {
			*zwischen = modulexp;
			while ((!zwischen[*zwischen]) && (*zwischen))
				--(*zwischen);
		}			
		msub(invers1,zwischen,invers1,modul);
		div(ggt2,ggt1,faktor,ggt2);
		if (!ggt2[0])
			welcher = 1;
		else {
			mult(faktor,invers1,zwischen);
			if (*zwischen > modulexp) {
				*zwischen = modulexp;
				while ((!zwischen[*zwischen]) && (*zwischen))
					--(*zwischen);
			}
			msub(invers2,zwischen,invers2,modul);
		}
	}
	switch (welcher) {
		case 1 : trans(ggt1,ergebnis);
			 trans(invers1,invers);
			 break;
		case 2 : trans(ggt2,ergebnis);
		         trans(invers2,invers);
			 break;
	}
	return(0);
}

MONTINIT(modul,modul_strich,exponent,n_modul_qua)
SHORT modul[],modul_strich[];
SHORT *exponent;
SHORT n_modul_qua[];
/* Eingabe : modul
   Ausgabe : modul_strich,n_modul,exponent mit
   n_modul > modul, n_modul = b^exponent
   modul*modul_strich = -1 mod n_modul
   n_modul_qua = n_modul*n_modul mod modul
   Die Ausgabeparameter duerfen die Eingabeparameter nicht ueberschreiben */

{
	int i;
	SHORT *zeiger,laenge,zwischen[ZWEI_LAENGE],n_modul[ZWEI_LAENGE];
	*exponent = *modul;
	laenge = *exponent + 1;
	if ((*n_modul_qua = (laenge << 1) -1) >= ZWEI_LAENGE)
		overflow("Montinit : overflow");
	*n_modul = laenge;
	zeiger = n_modul + 1;
	for (i=1;i<laenge;i++)
		*zeiger++ = 0;
	*zeiger = 1;
	zeiger = n_modul_qua + 1;
	for (i=1;i<*n_modul_qua;i++)
		*zeiger++ = 0;
	*zeiger = 1;		
	MONTGGT(modul,n_modul,*exponent,zwischen,modul_strich);
	sub(n_modul,modul_strich,modul_strich);
	div(n_modul_qua,modul,n_modul_qua,n_modul_qua);
}	

REDC(operand,ergebnis,modul,mod_strich,exponent)
SHORT operand[],ergebnis[],modul[],mod_strich[],exponent;
{
	SHORT m[ZWEI_LAENGE],t[ZWEI_LAENGE];
	SHORT laenge;
	SHORT i;
	laenge = *operand;
	if (laenge > exponent) {
		*operand = exponent;
		while ((!operand[*operand]) && *operand)
			--(*operand);
	}
	MBPOTMULT(operand,mod_strich,m,exponent);
	*operand = laenge;
	
	mult(m,modul,t);
	add(t,operand,t);
	shift(t,-exponent*16,t);
	if (comp(t,modul) <= 0)
		sub(t,modul,ergebnis);
	else
		trans(t,ergebnis);
}

MONTEXP(operand1,operand2,ergebnis,modul,modul_strich,exponent,n_modul_qua)
SHORT operand1[],operand2[],ergebnis[],modul[],modul_strich[];
SHORT exponent;
SHORT n_modul_qua[];
{
	SHORT erg[ZWEI_LAENGE],potenzen[16][ZWEI_LAENGE];
	SHORT test,vier_bits,laenge;
	SHORT *op2;
	int i,shifts;
	if (!(*modul))
		overflow("mexp : modul == 0");
	if (!(*operand2)) {
		/* d.h. ergebnis = operand1 ^ 0 = 1 */
		ergebnis[0]=1;
		ergebnis[1]=1;
		return;
	} /* auch 0^0 = 1 */

	div(operand1,modul,potenzen[1],potenzen[1]);
		/* potenzen[1] = operand1 mod modul */
	/* falls operand1 >= modul, veringert dieses die Laufzeit
	   zukuenftiger Quadrierungen von potenzen */
	if (!(*potenzen[1])) { /* operand1 = 0 mod modul */
		ergebnis[0]=0;
		return;
	}

	/* ab jetzt rechnen wir mit vernuenftigen Zahlen */
	
	/* Initialisierungen */
	vier_bits = 0;
	mult(potenzen[1],n_modul_qua,potenzen[1]);
	REDC(potenzen[1],potenzen[1],modul,modul_strich,exponent);
	for (i=2;i<16;i++) {
		mult(potenzen[1],potenzen[i-1],potenzen[i]);
		REDC(potenzen[i],potenzen[i],modul,modul_strich,exponent);
	}		

	/* Ueberspringen fuehrender Nullen; initialisierung von erg */
	laenge = *operand2;
	op2 = operand2 + laenge;
	test = *op2;
	for (shifts = BITS-4;!vier_bits;shifts-=4)
		vier_bits = (test >> shifts) & 15;
	trans(potenzen[vier_bits],erg);
	
	for (;shifts >= 0;shifts -= 4) {
		mult(erg,erg,erg);
		REDC(erg,erg,modul,modul_strich,exponent);
		mult(erg,erg,erg);
		REDC(erg,erg,modul,modul_strich,exponent);
		mult(erg,erg,erg);
		REDC(erg,erg,modul,modul_strich,exponent);
		mult(erg,erg,erg);
		REDC(erg,erg,modul,modul_strich,exponent);
		if (vier_bits = (test >> shifts) & 15) {
			mult(potenzen[vier_bits],erg,erg);
			REDC(erg,erg,modul,modul_strich,exponent);
		}
	}		
	
	for (i=1;i < laenge;i++) {
		test = *--op2;
		for (shifts = BITS-4;shifts >= 0;shifts -= 4) {
			mult(erg,erg,erg);
			REDC(erg,erg,modul,modul_strich,exponent);
			mult(erg,erg,erg);
			REDC(erg,erg,modul,modul_strich,exponent);
			mult(erg,erg,erg);
			REDC(erg,erg,modul,modul_strich,exponent);
			mult(erg,erg,erg);
			REDC(erg,erg,modul,modul_strich,exponent);
			if (vier_bits = (test >> shifts) & 15) {
				mult(potenzen[vier_bits],erg,erg);
				REDC(erg,erg,modul,modul_strich,exponent);
			}
		}
	}
	REDC(erg,ergebnis,modul,modul_strich,exponent);
}		

mexp(operand1,operand2,ergebnis,modul)
SHORT operand1[],operand2[],ergebnis[],modul[];
{
	SHORT erg[ZWEI_LAENGE],potenzen[16][ZWEI_LAENGE];
	SHORT test,vier_bits,laenge;
	SHORT *op2;
	int i,shifts;
	if (!(*modul))
		overflow("mexp : modul == 0");
	if (!(*operand2)) {
		/* d.h. ergebnis = operand1 ^ 0 = 1 */
		ergebnis[0]=1;
		ergebnis[1]=1;
		return;
	} /* auch 0^0 = 1 */

	div(operand1,modul,potenzen[1],potenzen[1]);
		/* potenzen[1] = operand1 mod modul */
	/* falls operand1 >= modul, veringert dieses die Laufzeit
	   zukuenftiger Quadrierungen von potenzen */
	if (!(*potenzen[1])) { /* operand1 = 0 mod modul */
		ergebnis[0]=0;
		return;
	}

	/* ab jetzt rechnen wir mit vernuenftigen Zahlen */
	
	/* Initialisierungen */
	vier_bits = 0;
	for (i=2;i<16;i++)
		mmult(potenzen[1],potenzen[i-1],potenzen[i],modul);

	/* Ueberspringen fuehrender Nullen; initialisierung von erg */
	laenge = *operand2;
	op2 = operand2 + laenge;
	test = *op2;
	for (shifts = BITS-4;!vier_bits;shifts-=4)
		vier_bits = (test >> shifts) & 15;
	trans(potenzen[vier_bits],erg);
	
	for (;shifts >= 0;shifts -= 4) {
		mmult(erg,erg,erg,modul);
		mmult(erg,erg,erg,modul);
		mmult(erg,erg,erg,modul);
		mmult(erg,erg,erg,modul);
		if (vier_bits = (test >> shifts) & 15)
			mmult(potenzen[vier_bits],erg,erg,modul);
	}		
	
	for (i=1;i < laenge;i++) {
		test = *--op2;
		for (shifts = BITS-4;shifts >= 0;shifts -= 4) {
			mmult(erg,erg,erg,modul);
			mmult(erg,erg,erg,modul);
			mmult(erg,erg,erg,modul);
			mmult(erg,erg,erg,modul);
			if (vier_bits = (test >> shifts) & 15)
				mmult(potenzen[vier_bits],erg,erg,modul);
		}
	}
	trans(erg,ergebnis);
}		

readue(text,zahl)
char text[];
SHORT zahl[];
/* Ausgabe von text; Einlesen der langen Zahl zahl in Dezimalschreibweise */
{
	SHORT i,a[2],j,z_potenz[2];
	char input[EINGABE_LAENGE];
	z_potenz[0]=1;z_potenz[1]=HOEHE_ZEHN_POTENZ;
	printf(text);
	fflush(stdout);
	gets(input);/* Eingabestring einlesen */
	a[0]=1;a[1]=0;
	zahl[0]=0;
	
	/* Umwandlung von Dezimal in Zahlen zur Basis ZWEI_HOCH_BITS */
	for (i = 0,j = 1;(i < EINGABE_LAENGE) && (input[i] != STRING_ENDE);i++,j++) {
		if ((input[i] >= '0') && (input[i] <= '9'))
			/* d.h. input[i] in {0,1,..,9} */
			a[1] = 10 * a[1] + input[i] - '0';
		else
			overflow("readue : Falsches Zeichen in Eingabestring");
		if (j == ZEHN_POTENZ) {
			mult(zahl,z_potenz,zahl);
			if (a[1]) {
				add(zahl,a,zahl);
				a[1]=0;
                      	}
			j=0;
		}
	}
	/* Nach Verlassen dieser Schleife ist j um 1 hoeher als die tatsaechliche
	   Stellenzahl der Zahl in a[1] */

	if (input[i] != STRING_ENDE)
		overflow("readue : Eingabe zu lang");

	/* a[1] an Zahl anhaengen */
	z_potenz[1]=1;
	for (i=1;i<j;i++)
		z_potenz[1]*=10;
	mult(zahl,z_potenz,zahl);
	if (a[1])
		add(zahl,a,zahl);
}

writeue(text,zahl)
char text[];
SHORT zahl[];
/* Schreibe den String text, und dann die Zahl zahl in Dezimalschreibweise */
{
	unsigned aus[AUS_LAENGE];
	SHORT quot[ZWEI_LAENGE],basis[3],rest[ZWEI_LAENGE];
	int i,n;
	printf(text);
	if (!zahl[0]) {
		/* Zahl = 0 */
		printf("0\n");
		return;
	}
	basis[1]=LOW_AUS_ZEHNPOTENZ;
	basis[2]=HIGH_AUS_ZEHNPOTENZ;
	if (basis[2])
		basis[0]=2;
	else
		basis[0]=1;

	/* Umwandlung von 2^BITS-Basis in 10^AUSGABE_POTENZ-Basis */		
	div(zahl,basis,quot,rest);
	/* Rest wird in den Ausgabestring kopiert; mit quot wird weitergerechnet */
	switch (rest[0]) {
		case 0 : aus[0]=0;
	        	break;
		case 1 : aus[0]=rest[1];
			break;
		case 2 : aus[0] = (rest[2] << BITS) + rest[1];
			break;
	}
	n=0;
	while (quot[0]) { /* solange quot != 0 */
		++n;   /* Zaehler fuer den Ausgabestring */
		if (n == AUS_LAENGE)
			overflow("writeue : zahl zu gross");
		div(quot,basis,quot,rest);
		switch (rest[0]) {
			case 0 : aus[n]=0;
				break;
			case 1 : aus[n]=rest[1];
				break;
			case 2 : aus[n] = (rest[2] << BITS) + rest[1];
				break;
		}
	}
	/* Ausgabe */
	printf("%u",aus[n]);
	for (i=n-1;i>=0;i--)
		printf(AUS_FORMAT,aus[i]);
	printf("\n");
}

wurzel(operand,ergebnis)
int operand[],ergebnis[];
{
/*	int eins[LAENGE];
	int erg[LAENGE],zwei[LAENGE];
	int rest[LAENGE],quo[LAENGE],a[LAENGE],b[LAENGE];
	int d[LAENGE],e[LAENGE],f[LAENGE],g[LAENGE],m[LAENGE];
	zuweis(1,eins);
	zuweis(2,zwei);	
	trans(operand,erg);
	zuweis(0,m);

	while (comp(erg,eins)==-1) {
		shift(erg,-1,erg);
		add(m,eins,m);
	};
	shift(m,-1,m);
	mexp(zwei,m,erg,operand);

	trans(erg,a);
	zuweis(0,b);

	while (comp(a,b) != 0) {
		trans(a,b);
		div(operand,a,quo,erg);
		add(a,quo,erg);
		shift(erg,-1,a);
		trans(f,g);
		trans(e,f);
		trans(a,e);
		if (comp(e,g)==0)
			trans(b,a);
	};

	trans(a,ergebnis);     */

	SHORT a[LAENGE],h[LAENGE],w[LAENGE];
	a[0] = 1;a[1] = 2;
	shift(operand,-2,h);
	while (*h) {
		shift(a,1,a);
		shift(h,-2,h);
		}	
	do {
		trans(a,w);
		div(operand,w,a,h);
		add(w,a,a);
		shift(a,-1,a);
	}
	while (comp(a,w) == 1 );
 	trans(w,ergebnis);

}

overflow(text)
char text[];
{
	printf("Fehler in Prozedur ");
	printf(text);
	printf("\n");
	exit(1);
}

#ifdef STAT
STATISTIK()
{
	printf("\nS T A T I S T I K\n\n");
	printf("%10d Additionen\n",ANZ_ADD);
	printf("%10d Subtraktionen\n",ANZ_SUB);
	printf("%10d Multiplikationen\n",ANZ_MULT);
	printf("%10d Shift-Operationen\n",ANZ_SHIFT);
	printf("%10d Divisionen\n",ANZ_DIV);
	printf("%10d Vergleiche\n",ANZ_COMP);
	printf("%10d Kopieen\n",ANZ_TRANS);
}
#endif


