char * datetag ()
  { return ( 
" Tue Sep 22 13:59:02 1998 "
           ); } 
