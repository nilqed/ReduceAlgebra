/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         bpsheap.c
% Description:  Code to dynamically set up bps and heap structures
% Author:       RAM, HP/FSD
% Created:      9-Mar-84
% Modified:
% Mode:         Text
% Package:
%
% (c) Copyright 1987, University of Utah, all rights reserved.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
% VM 370 memory model: try to allocate almost all of avaiable
% memory; C will assign from the top of address space downwards
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

#include <stdio.h>

#define MIN_HEAPSIZE    1000000  
#define BPSSIZE        2800000 
#define BASE_ADDRESS   1000000

int     alreadysetbpsandheap;
int     max_image_size;
int     obreakvalue;
int     bpsupperbound;
int     oldbps;
int     memhigh;

extern int  alreadysetbpsandheap;
extern int  lastbps;
extern int  nextbps;
extern int  bpslowerbound;
extern int  _infbitlength_;

extern int  heaplowerbound;
extern int  heapupperbound;
extern int  heaplast;
extern int  heaptrapbound;

extern int  oheaplowerbound;
extern int  oheapupperbound;
extern int  oheaplast;
extern int  oheaptrapbound;

  /* from os-hooks */
extern int bpssize,heapsize;
extern char * image,* kerneldir;


static power(x, n)
     int x, n;
{
  int i, p;

  p = 1;
  for (i = 1; i <= n; ++i)
    p = p * x;
  return(p);
}

setbpsandheap(argc,argv)
     int argc;
     char *argv[];
{
  int    i;
  int current_size_in_bytes;
  int total;
  char * membase; int memsize,memoffs;

  /*   if (image!=NULL) image_hdr();  open later for memory layout   */

  /* ensure valid values */
  bpssize = BPSSIZE;

  /*  current top address */
  current_size_in_bytes = (int)malloc(4); 
  max_image_size = power(2, _infbitlength_); 

  if ( current_size_in_bytes >= max_image_size) 
 {
    printf(
"*** Current size too big for PSL pointers\n");
    printf(
"*** Please reduce memory size below %d.\n\n",max_image_size);
    exit(-1);
  }

        /* allocate total memory */
  memsize= current_size_in_bytes-BASE_ADDRESS;
  membase = (char*)malloc(memsize);

  i = memsize;
  memsize = memsize - (BASE_ADDRESS-(int)membase);
  heapsize = memsize-bpssize;
  heapsize =(heapsize / 8) * 8;  /* ensure full words */
  bpssize =(bpssize / 4) * 4;

  if(heapsize<MIN_HEAPSIZE || BASE_ADDRESS<(int)membase
                           || (int)membase <= 0 )
   { printf("**** allocated memory not usable for LISP \n");
     printf("current upper memory limit is %x\n",current_size_in_bytes);
     printf("%d bytes requested\n",i);
     printf("allocated base is %x\n",membase);
     printf("%d bytes for BPS, base is %x\n",bpssize,BASE_ADDRESS);
     printf("%d bytes remaining for heap\n",heapsize);
     exit(-1);
   };

  printf("heap size: %d LISP items\n", heapsize/8);

  if (image!=NULL) image_hdr();

         /* bps pointers */
  bpslowerbound = BASE_ADDRESS;
  nextbps=bpslowerbound;
  bpsupperbound  = bpslowerbound+bpssize;
  lastbps = bpsupperbound;
  
         /* heap pointers */
  heaplowerbound = lastbps+4;
  heapupperbound        = heaplowerbound + heapsize/2;
  heaplast              = heaplowerbound;
  heaptrapbound         = heapupperbound -120;

  oheaplowerbound    = heapupperbound;
  oheapupperbound     = oheaplowerbound + heapsize/2;
  oheaplast           = oheaplowerbound;
  oheaptrapbound      = oheapupperbound -120;

  memhigh             = oheaptrapbound+4;
  obreakvalue = 0;

  if (image!=NULL) image_body();

}

allocatemorebps()
{
  int increment,x;
  char * base;
  increment= BPSSIZE/2;
  x = memhigh + increment;
  x = x % 0x7ffffff;
  increment= x - memhigh;
  increment= (increment >> 2) << 2;
  if(increment<50000)
    {printf("current model does not allow more BPS\n");
     return(-1);};
  base=(char*)malloc(increment);
  if(base==NULL)
    {printf("Operating System refuses more memory for BPS\n");
     return(-1);}
  bpslowerbound=(int) base;
  bpsupperbound=bpslowerbound+increment;
  memhigh = memhigh + increment;
  return(increment);
}


/* Tag( alterheapsize )
 */
alterheapsize(increment)
int increment;
{
}
