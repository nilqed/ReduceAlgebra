/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         PXK:UNIX-IO.C
% Description:  Unix PSL FileDescriptors are implemented as stdio streams
%                 ("FILE *".)
% Author:       Russell D. Fish
% Created:      Thu Feb 16 1984
% Modified:     17-Jul-84 22:49:12 (RAM)
% Mode:         Text
% Package:
% Status:       Experimental (Do Not Distribute)
%
% Copyright (c) 1984 Hewlett-Packard Company, all rights reserved.
% Copyright (c) 1984 University of Utah
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/
 
#include <stdio.h>
 
  /* from os-hooks */
extern char * image,* kerneldir;
 
/* Initialize some PSL external variables with FileDescriptors for SysClearIO.
 */
extern FILE * ustdin, * ustdout, * ustderr, * utty;
 
/* Import NULL and EOF constants for error returns from stdio fns.  */
 
extern int ueof;
extern void * unull;
 
/*-------------------------------------------------------------*/
/*   convention:
/*      ascii = e2a [ ebcdic ]
/*      ebcdic= a2e [ ascii  ]
/*-------------------------------------------------------------*/
 
char ascii[]=" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";
 
char a2e[255]; char e2a[255];
 
make_code()
     {
      if(' '==(char)0x40) make_ebcdic(); else make_ascii();
     }
 
make_ascii()
   {
    int i;
    for(i=0;i<256;i++) {e2a[i]=(char)i ;a2e[i]=(char)i;};
   }
 
make_ebcdic()
   {int i,j; char c; char * a;
    for(i=0;i<256;i++) {e2a[i]=' ';a2e[i]=(char)0x20;};
    a=ascii; i=32;
    while((c = *a++)!='\0')
    {j=(int)c;
     /* now is i=ASCII code, j=EBCDIC code */
     e2a[j]=(char)i; a2e[i]=(char)j;
     /* printf("ebcdic %x = ascii %x \n",j,i); */
     i++;
    };
       /* linefeed */
    a2e[10]='\n'; e2a[(int)'\n']=(char)10;
      /* tabulator */
    a2e[9] =5   ; e2a[5]        =(char)9;
       /* EOF */
    a2e[4]=(char)(EOF&255); e2a[EOF&255]=(char)4;
       /* string terminator */
    a2e[0]=e2a[0]='\0';
   }
 
uinitio()
{
    make_code();
    ustdin = stdin;
    ustdout = stdout;
    ustderr = stderr;
    unull = NULL;
    ueof = EOF;
}
 
uputc(c)
char c;
{ fputc(a2e[(unsigned int)c], stdout); }
 
char ufgetc(fp)
    FILE*fp;
    { return(e2a[(unsigned int)fgetc(fp)]);}
 
ufputc(c,fp)
    char c; FILE*fp;
    { fputc(a2e[(unsigned int)c], fp); }
 
uputs(str)
char *str;
{
    char estr[255]; int i;
    if (e2a[1]==0) make_code();
    for(i=0;i<256&&str[i]!='\0';i++)
         estr[i]=a2e[(unsigned int)str[i]];
    estr[i]='\0';
    fputs(estr, stdout);
}
 
 
char * ufgets(str,count,fp)
    char*str;
    int count;
    FILE*fp;
 
    {int i; char*s ; char * val; char*t;
     val = fgets(str,count,fp);
     if (val == (char *) NULL) return(val) ;
     s=t=str;
     while(*t++ = e2a[(unsigned int)*s++]);
     return(str);
    }
 
 
ufread(buf,size,count,fp)
     char*buf;
     int count,size;
     FILE*fp;
 
    {int i,r,l; char*s; char*t;
     r=fread(buf,size,count,fp);
     l=r*size;
 
     if(r != count) { r++; buf[l]=(char) 4; }
 
     for(i=0;i<l;i++) buf[i]=e2a[(unsigned int)buf[i]];
     return(r);
    }
 
ufwrite(buf,size,count,fp)
     char*buf;
     int count,size;
     FILE*fp;
 
    {int i,r,l; char*s; char*t;
     l=size*count;
         /* buffer is overwritten here */
     for(i=0;i<l;i++) buf[i]=a2e[(unsigned int)buf[i]];
     r=fwrite(buf,size,count,fp);
     return(r);
    }
 
uputn(n)
int n;
{
    fprintf(stdout, "%x ", n);
}
 
/* Tag( unixcleario ) */
ucleario()
{
    kerneldir=NULL;
    uinitio();
}
 
putw(w, stream)
     FILE *stream;
   {
     fwrite(&w,4,1,stream);
   }
 
unsigned getw(stream)
     FILE *stream;
    { unsigned w;
      fread(&w,4,1,stream);
      return(w);
    }
 
 
char collect[255], copy[255];  /* Made global so it won't be overwritten
				  Used to be local to expand_file_name */
char upper(c)
   char c;
   {
     if ('a' <= c && c <= 'z') return ('A' + (c-'a'));
     return(c);
   }
 
/* Tag( expand_file_name )
 */
char *expand_file_name(fname)
char *fname;
{
  int i;
  char *c, *s;
  char x;
  static char efname[255];
      /*convert fname to ebcdic*/
  c = efname; s = fname;
  while (*c++ =       a2e[(unsigned int)*s++] );
    s = efname; c = efname;
    if (kerneldir!=NULL)
        { while (*s && *s != '.')
                {if (*s != '-') *c++ = *s++;  else s++;};
          *c++ = ' '; *c++ = 'b';
        *c++ = ' '; *c++ =  *kerneldir  ;
        }
       else
          while (*c++ = *s++);
  *c =  '\0';
   /*  printf("fnexpand:  <%s>\n",efname); */
  return (efname);
}
 
/* Tag( unixopen )
 */
uopen(filename, type)
     char *filename, type[];
{
 FILE*fptr; char * tp; char c1,c2;
  c1=a2e[(unsigned int)type[0]];
  c2=a2e[(unsigned int)type[1]];
  if (c2!='b')
     {if(c1=='r') tp="r"; else tp="w";}
    else
     {if(c1=='r') /* tp="rb,blksize=1024,lrecl=4096,recfm=V"; */
                 tp="rb";
      else tp="wb";}
  fptr =       fopen(expand_file_name(filename), tp);
  if (!fptr) {perror(expand_file_name(filename)); }
  return( (int) fptr);
}
 
cfread(ptr,m,s,fil)
   char * ptr;
   int m,s;
   FILE * fil;
   {int l1,l2,i;
    l2=fread(ptr,m,s,fil);
    l1=m*l2;
    for(i=0;i<l1;i++) ptr[i] = e2a[(unsigned int)ptr[i]];
    return(l2);
   }
 
cfwrite(ptr,m,s,fil)
   char * ptr;
   int m,s;
   FILE * fil;
   {int l1,l2,i;
    for(i=0;i<l1;i++) ptr[i] = a2e[(unsigned int)ptr[i]];
    l2=fwrite(ptr,m,s,fil);
    return(l2);
   }
 
/* Tag( unixcd )
 */
ucd(filename)
     char *filename;
{
}
 
/* Tag( external_system )
 */
e_system(command)
     char *command;
{
}
 
/* Tag( external_exit )
 */
e_exit(status)
     int status;
{
  exit(status);
}
 
char *static_argv[20];  /* static place to hold argv so it doesn't get gc'd */
 
void * copy_argv(argc,argv)    /* copy argv into static space. */
int argc;
char *argv[];
{
  int i;
 
  for (i=0; i < argc; i++)
     static_argv[i]=argv[i];
 
  return(static_argv);
}
 
sleep(i)
     int i;
     {}
 
int  umcod (strin,strout)
    char*strin; char* strout ;
 
    { while(*strout++ = a2e[(unsigned int)*strin++]);
    }
int  rueckcod (strin,strout)
    char*strin; char* strout ;
 
    { while(*strout++ = e2a[(unsigned int)*strin++]);
    }
 
