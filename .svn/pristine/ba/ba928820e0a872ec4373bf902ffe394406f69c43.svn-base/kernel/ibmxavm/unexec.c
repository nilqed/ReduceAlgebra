/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         PXK:UNEXEC.C
% Description:  Unix PSL writing and loading of an image file
%                
% Author:       Herbert Melenk 
% Created:      Feb 27 1991    
% Modified:     
% Mode:         C   
% Package:      
% Status:       Experimental (Do Not Distribute)
%
% Copyright (c) 1991 Konrad-Zuse-Zentrum, all rights reserved.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

#include <stdio.h>
#define MAGIC     4711
#define HASHTABLE 0
#define SYMVAL    1
#define SYMPRP    2
#define SYMNAM    3
#define SYMFNC    4
#define BPS       10
#define BPSTABLE  110
#define BPS2      11
#define HEAP      20
#define HEAPTABLE 120

  /* from os-hooks */
extern char * image,* kerneldir;
 
   /* layout of the dumped system */
struct imghdr{
   int magic;
      /* memory size */
   int bpssize;
   int heapsize;
     /* kernel pointer */
   int kernlo;
   int kernhi;
      /* bps pointer */
   int bpslowerbound;
   int nextbps;
   int lastbps;
   int bpsupperbound;
      /* heap pointer */
   int heaplowerbound;
   int heaplast;
   int heapupperbound;
   int heaptrapbound;
      /* kernel structures */
   int symval;
   int symnam;
   int symprp;
   int symfnc;
   int maxsymb;
      /* additional system variables */
   int  oheaplowerbound;
   int  oheapupperbound;
   int  oheaplast;
   int  oheaptrapbound;

     } hdr,sys;
 
   /* layout of the living system */
 

extern int  oldbps;   /* bpslowerbound read from image */

extern int  lastbps;
extern int  nextbps;
extern int  bpslowerbound;
extern int  _infbitlength_;

extern int  heaplowerbound;
extern int  heapupperbound;
extern int  heaplast;
extern int  heaptrapbound;
extern int  oheaplowerbound;
extern int  oheapupperbound;
extern int  oheaplast;
extern int  oheaptrapbound;

FILE *imagefile;
/* FILE *notfile; 
*/
 
extern int bpssize,heapsize;
extern char * image, * kerneldir;
extern int bpsupperbound;
extern unsigned hashtable[];
extern unsigned symfnc[];
extern unsigned symval[];
extern unsigned symprp[];
extern unsigned symnam[];
extern int firstker[];
extern int lastker[];

extern char* expand_file_name();

#define HASHTABLESIZE 36028
 
/*---------------------------------------------------------*/
/*                DUMPLISP part                            */
/*---------------------------------------------------------*/

struct tafel {int maxsymb;
             int bps_tl;
             int * bps_table;
             int heap_tl;
             int * heap_table;
            };

unexec( n_name, tbl )
     char *n_name;
     struct tafel *tbl;
{
    char * new_name;
       /* translage file name to system conventions , open */
    kerneldir = NULL;
    if (bpslowerbound >= heapupperbound)
       {printf("cannot write image when bps was enlarged\n");
        return(-1);};
    new_name=expand_file_name(n_name);
    if ( (imagefile = fopen( new_name, "wb" )) == NULL )
    {   int l;
        perror( new_name );
        return -1;
    };
 
       /* set up header */

    hdr.magic = MAGIC;
    hdr.bpssize = bpssize;
    hdr.heapsize = heapsize;
    hdr.kernlo = (int)&firstker[0];
    hdr.kernhi = (int)&lastker[0];
    hdr.bpslowerbound = bpslowerbound;
    hdr.nextbps = nextbps;
    hdr.lastbps = lastbps;
    hdr.bpsupperbound = bpsupperbound;
    hdr.heaplowerbound = heaplowerbound;
    hdr.heaplast = heaplast;
    hdr.heaptrapbound = heaptrapbound;
    hdr.heapupperbound = heapupperbound;
    hdr.symval = (unsigned)&symval[0];
    hdr.symnam = (unsigned)&symnam[0];
    hdr.symprp = (unsigned)&symprp[0];
    hdr.symfnc = (unsigned)&symfnc[0];
    hdr.maxsymb = tbl->maxsymb;
    fwrite(&hdr.magic,sizeof(hdr),1,imagefile);
 
        /* write structures to file */

    img_wb(HASHTABLE,hashtable,HASHTABLESIZE)||
    img_wb(SYMVAL,hdr.symval,tbl->maxsymb<<2)  ||
    img_wb(SYMPRP,hdr.symprp,tbl->maxsymb<<2)  ||
    img_wb(SYMNAM,hdr.symnam,tbl->maxsymb<<2)  ||
    img_wb(SYMFNC,hdr.symfnc,tbl->maxsymb<<2)  ||
    img_wb(BPS,bpslowerbound,nextbps-bpslowerbound)  ||
    img_wb(BPS2,lastbps,bpsupperbound-lastbps)   ||
    img_wb(HEAP,heaplowerbound,heaplast-heaplowerbound)   ||
    fclose(imagefile);
    return(0);
  }

    /* write a single block to the image file */

img_wb(n,ptr,l)
   int n,l; char * ptr;
   {int j;
    fwrite(&n,4,1,imagefile);
    fwrite(&l,4,1,imagefile);
    j=fwrite(ptr,1,l,imagefile);
    if(j!=l) 
       {printf("error writing block %d\n",n); return(1);}
             else return(0);
  }
    

/*-----------------------------------------------------------*/
/*                RESTORE part                               */
/*-----------------------------------------------------------*/

/*  divided in 2parts: 
    read header first,
    then establish data areas
    and finally read the data
*/

unsigned char * table_base;
int table_lth;


    /* read the header of the image file */

image_hdr()

   { 
     int i;
     printf(
"PSL/370 (Konrad-Zuse-Zentrum Berlin) loading %s\n",image);
     imagefile=fopen(image,"rb");
     /*notfile=fopen("not","w");  */
     if (imagefile==NULL) 
        {printf("**** image file >%s< cannot be opened for input\n",image);
         exit(-1);};

     if(1!=fread(&hdr.magic,sizeof(hdr),1,imagefile)||
        hdr.magic != MAGIC) img_error("wrong magic",hdr.magic);
 
     if( (int)&lastker[0] - (int)&firstker[0] 
            != hdr.kernhi-hdr.kernlo
                || bpssize!=hdr.bpssize)
            img_error( 
"**** image file not compatible with actual kernel",0);
 
       /* adjust memory structure */

     if(heapsize<hdr.heapsize) 
             img_error(
"**** image requires minimum heap of size",hdr.heapsize);
     oldbps = hdr.bpslowerbound;
    }
 
    /* process the body of the image file */

image_body()

    {
       int i;
         /* save some items of the current data structure */
       
       sys.symval = (unsigned)&symval[0];
       sys.symnam = (unsigned)&symnam[0];
       sys.symprp = (unsigned)&symprp[0];
       sys.symfnc = (unsigned)&symfnc[0];

       sys.bpslowerbound = bpslowerbound;
       sys.bpsupperbound =  bpsupperbound;
       sys.lastbps = bpslowerbound 
                   + hdr.lastbps-hdr.bpslowerbound;
       sys.nextbps = bpslowerbound 
                   + hdr.nextbps-hdr.bpslowerbound;

       sys.heaplowerbound = heaplowerbound;
       sys.heapupperbound = heapupperbound;
       sys.heaplast = heaplowerbound 
                   + hdr.heaplast-hdr.heaplowerbound;
       sys.heaptrapbound = heaptrapbound;

       sys.oheaplowerbound = oheaplowerbound;
       sys.oheapupperbound = oheapupperbound;
       sys.oheaplast = oheaplast;
       sys.oheaptrapbound = oheaptrapbound;
       i=img_rb(HASHTABLE,hashtable);
       i=img_rb(SYMVAL,sys.symval); imge_rly(symval,SYMVAL,i);
       i=img_rb(SYMPRP,sys.symprp); imge_rly(symprp,SYMPRP,i);
       i=img_rb(SYMNAM,sys.symnam); imge_rly(symnam,SYMNAM,i);
       i=img_rb(SYMFNC,sys.symfnc); imge_rly(symfnc,SYMFNC,i);
       i=img_rb(BPS,sys.bpslowerbound); 
         imge_rlb(sys.bpslowerbound,BPSTABLE,i);
       i=img_rb(BPS2,sys.lastbps);
       i=img_rb(HEAP,sys.heaplowerbound);
 
         /* restore some high heap pointers */
       heaptrapbound = sys.heaptrapbound;
       heapupperbound = sys.heapupperbound;
       oheaplowerbound = sys.oheaplowerbound;
       oheapupperbound = sys.oheapupperbound;
       oheaplast =       sys.oheaplast;
       oheaptrapbound = sys.oheaptrapbound;
         /* restore bps pointers */
       bpslowerbound  = sys.bpslowerbound;
       bpsupperbound  = sys.bpsupperbound;
       lastbps        = sys.lastbps;
       nextbps        = sys.nextbps;
       /* printf("Soweit so gut!\n"); */
       fclose(imagefile);
/*       fclose(notfile);*/
     } 
 
    /* read a single block from file */

img_rb(n,ptr)
    int n; char*ptr;

    {int l,j;
     fread(&j,4,1,imagefile);
     /* printf(" reading %x %x\n",j,n); */
     if (j!=n) img_error("missing structure",n);
     fread(&l,4,1,imagefile);
     j=fread(ptr,1,l,imagefile);
     /* printf(" read: %x %x\n",j,l); */
     if (j!=l) img_error("missing data for structure",n);
     return(l);
    }

    
    /* relocate a homoveneous word vector SYM*** */

imge_rly(ptr,n,l)
    unsigned ptr[];
    int n,l;

    {
     int i; unsigned itm,tg,inf;
/* fprintf(notfile,"============ fix  block ==== %d =====\n",n);  */
     l=l/4;
     for(i=0;i<l;i++)
      { 
        itm=ptr[i]; tg=itm>>27;
        if(0<=tg && tg<=15)
        {inf = itm & 0x7ffffff; 
         ptr[i]=tg<<27 | reloc(inf);
         /* notdruck(&ptr[i],inf,ptr[i]); */
        }
      }
    }
        
    /* relocate bps */

imge_rlb(bptr,n,l)
    unsigned char bptr[];
    int n,l;
    {
     int i,d; unsigned itm,tg,inf,rinf,prev;
     unsigned * ptr;
     d = 4;

     for(i=0;i<l;i=i+d)
      { ptr = (unsigned *)(bptr+i);
        itm = *ptr; 
        tg = itm>>27;
        inf = itm & 0x7ffffff; 
        if (tg==0)
         { rinf=relocb(inf,prev);
           if(inf != rinf)
             {  *ptr=tg<<27 | rinf;
             }
         };
         prev = itm;
      }
    }

/*
 notdruck(wo,von,nach)
   int wo,von,nach;
   {fprintf(notfile,"%x: %x ==> %x\n",wo,von,nach);}
*/
 

relocb(j,prev)
     int j,prev;

    {
      int k;

      if(j & 3) return (j);  /* odd address */

      k=j-(hdr.maxsymb<<2);
      if(hdr.symval <= j && k <= hdr.symval 
                         && (prev<<2) == j-hdr.symval) 
          return(sys.symval + j - hdr.symval);
      if(hdr.symfnc <= j && k <= hdr.symfnc
                         && (prev<<2) == j-hdr.symfnc) 
          return(sys.symfnc + j - hdr.symfnc);
      return(j);
    }


    /* relocate one item */

reloc(j)
     int j;

    {
      int k;
      if(hdr.kernlo <= j && j < hdr.bpslowerbound)
          return((long)&firstker[0] + j - hdr.kernlo);
      k=j-(hdr.maxsymb<<2);
      if(hdr.bpslowerbound <= j && j <= hdr.nextbps)
          return(sys.bpslowerbound + j - hdr.bpslowerbound);
      if(hdr.lastbps <= j && j <= hdr.bpsupperbound)
          return(sys.lastbps + j - hdr.lastbps);
      if(hdr.heaplowerbound <= j && j <= hdr.heaplast)
          return(sys.heaplowerbound + j - hdr.heaplowerbound);
      if(hdr.symval <= j && k <= hdr.symval)
          return(sys.symval + j - hdr.symval);
      if(hdr.symprp <= j && k <= hdr.symprp)
          return(sys.symprp + j - hdr.symprp);
      if(hdr.symnam <= j && k <= hdr.symnam)
          return(sys.symnam + j - hdr.symnam);
      if(hdr.symfnc <= j && k <= hdr.symfnc)
          return(sys.symfnc + j - hdr.symfnc);
      return(j);
    }

img_error(s,n)
    char * s; 
    int n;

    {
     printf(
"**** error >%s:%d<during processing of image file\n",s,n);
     exit(-1);
    }
     
