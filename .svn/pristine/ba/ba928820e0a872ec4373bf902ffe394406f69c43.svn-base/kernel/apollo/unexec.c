/*	UNEXAPOLLO -- COFF File UNEXEC for GNU Emacs on Apollo (SR10.1)	     */
/*	UNEXAPOLLO -- Freeze File UNEXEC for GNU Emacs on Apollo (SR9.7)     */
/*									     */
/*	Copyright (C) 1988 by Leonard N. Zubkoff, All Rights Reserved	     */
/*									     */
/*	This software is provided free and without any warranty.	     */
/*	Permission to copy for any purpose is hereby granted so		     */
/*	long as this copyright notice remains intact.			     */
/*									     */
/*	Revision:	28-Feb-89 10:44:56				     */


#define begin	    {
#define end	    }
#define then
#define do
#define hidden	    static
#define visible
#define procedure   void


/* #include "config.h" */
#include <fcntl.h>

#define APOLLO_SR10

#ifdef APOLLO_SR10		/* For Domain/OS SR10.1 */


#include <a.out.h>
#include <sys/file.h>
#include <apollo/base.h>
#include <apollo/ios.h>
#include <apollo/type_uids.h>

int error(char *str)
  begin
    printf("Unexec Error: %s\n",str);
    return -1;
  end

visible procedure unexec(char *new_name,
			 char *old_name,
			 unsigned data_start,
			 unsigned bss_start)
    begin
	struct filehdr FileHeader;
	struct aouthdr DomainHeader;
	struct scnhdr *Section, *Sections, *SectionsLimit;
	struct scnhdr *DataSection, *RwdiSection;
	char TargetFileName[256], SourceFileName[256];
	struct reloc RelocEntry;
	unsigned long DataSize, SourceFileOffsetPastRwdi;
	unsigned char Buffer[4096];
	long Delta, ByteCount, i;
	ios_$id_t TargetFile, SourceFile;
	status_$t Status;

	strcpy(TargetFileName, expand_file_name(new_name));
	if (old_name)
	  strcpy(SourceFileName, expand_file_name(old_name));
	/* Open the Source File. */
	if ((SourceFile = open(SourceFileName,O_RDONLY)) < 0) then
	    error("cannot open source file for input");
	/* Read the File Header. */
	if (read(SourceFile,&FileHeader,sizeof(FileHeader))
		!= sizeof(FileHeader)) then
	    error("cannot read file header");

	/* Read the Domain Header. */
	if (read(SourceFile,&DomainHeader,sizeof(DomainHeader))
		!= sizeof(DomainHeader)) then
	    error("cannot read domain header");
	/* Read the Section Headers. */
	Sections = (struct scnhdr *) malloc(FileHeader.f_nscns
					    *sizeof(struct scnhdr));
	if (Sections == (struct scnhdr *) 0) then
	    error("cannot allocate section header storage");
	SectionsLimit = Sections+FileHeader.f_nscns;
	if (read(SourceFile,Sections,FileHeader.f_nscns*sizeof(struct scnhdr))
		!= FileHeader.f_nscns*sizeof(struct scnhdr)) then
	    error("cannot read section headers");
	/* Compute the new Size of the Data Section. */
	DataSize = sbrk(0)-DomainHeader.data_start;
	/* Find and Deallocate the .rwdi Section Information. */
	for (RwdiSection=Sections;
	     RwdiSection != SectionsLimit; RwdiSection++) do
		if (strcmp(RwdiSection->s_name,".rwdi") == 0) then
		    begin
			Delta = DataSize-DomainHeader.dsize
					-RwdiSection->s_size;
			RwdiSection->s_paddr = 0;
			RwdiSection->s_vaddr = 0;
			RwdiSection->s_scnptr = 0;
			RwdiSection->s_size = 0;
			SourceFileOffsetPastRwdi = (RwdiSection+1)->s_scnptr;
			break;
		    end;
	/* Skip over the Text Section Headers. */
	for (Section=Sections;
	     (Section->s_flags & STYP_TEXT) != 0; Section++) do ;
	/* Increment the Relocation Pointers in Data Section Headers. */
	for (; Section != SectionsLimit; Section++) do
	    if ((Section->s_flags & STYP_DATA) != 0) then
		begin
		    DataSection = Section;
		    DataSection->s_relptr += Delta;
		end;
	/* Increment the Size of the Last Data Section. */
	DataSection->s_size += DataSize-DomainHeader.dsize;
	/* Update the File Header and Domain Header. */
	FileHeader.f_symptr += Delta;
	DomainHeader.dsize = DataSize;
	DomainHeader.bsize = 0;
	DomainHeader.o_sri += Delta;
	DomainHeader.o_inlib += Delta;

 	/* Skip over subsequent Bss Section Headers. */
 	for (Section=DataSection+1;
 	     (Section->s_flags & STYP_BSS) != 0; Section++) do ;
 	/* Update the remaining Section Headers. */
 	for (; Section != SectionsLimit; Section++) do
	    begin
		if (Section->s_paddr != 0) then
		    Section->s_paddr += Delta;
		if (Section->s_vaddr != 0) then
		    Section->s_vaddr += Delta;
		if (Section->s_scnptr != 0) then
		    Section->s_scnptr += Delta;
	    end;
	/* Open the Target File. */
	ios_$create(TargetFileName,strlen(TargetFileName),coff_$uid,
		    ios_$recreate_mode,ios_$write_opt,&TargetFile,&Status);
	if (Status.all != status_$ok) then
	    error("cannot open target file for output");
	/* Write the File Header. */
	if (write(TargetFile,&FileHeader,sizeof(FileHeader))
		!= sizeof(FileHeader)) then
	    error("cannot write file header");
	/* Write the Domain Header. */
	if (write(TargetFile,&DomainHeader,sizeof(DomainHeader))
		!= sizeof(DomainHeader)) then
	    error("cannot write domain header");
	/* Write the Section Headers. */
	if (write(TargetFile,Sections,FileHeader.f_nscns*sizeof(struct scnhdr))
		!= FileHeader.f_nscns*sizeof(struct scnhdr)) then
	    error("cannot write section headers");
	/* Copy the Allocated Sections. */
	for (Section=Sections; Section != DataSection; Section++) do
	    if (Section->s_scnptr != 0) then
		CopyData(TargetFile,SourceFile,Section->s_size);
	/* Write the Expanded Data Segment. */
	if (write(TargetFile,DataSection->s_vaddr,
		  DataSection->s_size) != DataSection->s_size) then
	    error("cannot write new data section");
	/* Skip over the Last Data Section and Copy until the .rwdi Section. */
	if (lseek(SourceFile,DataSection->s_scnptr
			     +DataSection->s_size,L_SET) == -1) then
	    error("cannot seek past data section");
	for (Section=DataSection+1; Section != RwdiSection; Section++) do
	    if (Section->s_scnptr != 0) then
		CopyData(TargetFile,SourceFile,Section->s_size);
	/* Skip over the .rwdi Section and Copy Remainder of Source File. */
	if (lseek(SourceFile,SourceFileOffsetPastRwdi,L_SET) == -1) then
	    error("cannot seek past .rwdi section");
	while ((ByteCount = read(SourceFile,Buffer,sizeof(Buffer))) > 0) do
	    if (write(TargetFile,Buffer,ByteCount) != ByteCount) then
		error("cannot write data");

	/* Unrelocate .data references to Global Symbols. */
	for (i=0; i<DataSection->s_nreloc; i++) do
	    begin
		if (lseek(SourceFile,DataSection->s_relptr
				     +i*sizeof(struct reloc)-Delta,
			  L_SET) == -1) then
		    error("cannot seek to relocation info");
		if (read(SourceFile,&RelocEntry,sizeof(RelocEntry))
			!= sizeof(RelocEntry)) then
		    error("cannot read reloc entry");
		if (lseek(SourceFile,RelocEntry.r_vaddr-DataSection->s_vaddr
				     +DataSection->s_scnptr,L_SET) == -1) then
		    error("cannot seek to data element");
		if (lseek(TargetFile,RelocEntry.r_vaddr-DataSection->s_vaddr
				     +DataSection->s_scnptr,L_SET) == -1) then
		    error("cannot seek to data element");
		if (read(SourceFile,Buffer,4) != 4) then
		    error("cannot read data element");
		if (write(TargetFile,Buffer,4) != 4) then
		    error("cannot write data element");
	    end;
	if (close(SourceFile) == -1) then
	    error("cannot close source file");
	if (close(TargetFile) == -1) then
	    error("cannot close target file");
    end


hidden CopyData(int TargetFile,
		int SourceFile,
		long TotalByteCount)
    begin
	unsigned char Buffer[4096];
	long ByteCount;
	while (TotalByteCount > 0) do
	    begin
		if (TotalByteCount > sizeof(Buffer)) then
		    ByteCount = sizeof(Buffer);
		else ByteCount = TotalByteCount;
		if (read(SourceFile,Buffer,ByteCount) != ByteCount) then
		    error("cannot read data");
		if (write(TargetFile,Buffer,ByteCount) != ByteCount) then
		    error("cannot write data");
		TotalByteCount -= ByteCount;
	    end;
    end

#else				/* For Domain/OS SR9.7 */

/* Freeze File Header that describes the saved data. */

struct freeze_file_header
    begin
	char *start_of_data;
	char *end_of_data;
	char *start_of_bss;
	char *end_of_bss;
    end;


/* Read the data and bss spaces from the freeze file. */

visible int mapin_data(FileName)
	char *FileName;
    begin
	extern char *sbrk(), *_malloc_base;
	extern int data_start, my_edata;
	struct freeze_file_header FreezeHeader;
	int FileDescriptor;
	FileDescriptor = open(FileName,O_RDONLY);
	if (FileDescriptor < 0) then
	    begin
		printf("Cannot open freeze file; running bare Emacs...\n");
		return 0;
	    end;
	if (read(FileDescriptor,&FreezeHeader,
		 sizeof(FreezeHeader)) < 0) then
	    begin
		printf("Cannot read header from freeze file;");
		printf(" running bare Emacs...\n");
		return 0;
	    end;
	if (FreezeHeader.start_of_data != (char *) &data_start) then
	    begin
		printf("Start of data space has moved from %X to %X;",
		       FreezeHeader.start_of_data,&data_start);
		printf(" running bare Emacs...\n");
		return 0;
	    end;
	if (FreezeHeader.end_of_data != (char *) &my_edata) then
	    begin
		printf("End of data space has moved from %X to %X;",
		       FreezeHeader.end_of_data,(char *) &my_edata);
		printf(" running bare Emacs...\n");
		return 0;
	    end;
	_malloc_base = sbrk(0);
	if (FreezeHeader.start_of_bss != _malloc_base) then
	    begin
		printf("Start of bss space has moved from %X to %X;",
		       FreezeHeader.start_of_bss,_malloc_base);
		printf(" running bare Emacs...\n");
		return 0;
	    end;

	if (brk(FreezeHeader.end_of_bss) < 0) then
	    begin
		printf("Cannot set brk to %X;",FreezeHeader.end_of_bss);
		printf(" running bare Emacs...\n");
		return 0;
	    end;
	if (read(FileDescriptor,FreezeHeader.start_of_data,
		 FreezeHeader.end_of_data
		 -FreezeHeader.start_of_data) < 0) then
	    begin
		printf("Cannot read data space from freeze file;");
		printf(" running bare Emacs...\n");
		return 0;
	    end;
	if (read(FileDescriptor,FreezeHeader.start_of_bss,
		 FreezeHeader.end_of_bss
		 -FreezeHeader.start_of_bss) < 0) then
	    begin
		printf("Cannot read bss space from freeze file;");
		printf(" running bare Emacs...\n");
		return 0;
	    end;
	close(FileDescriptor);
	return 1;
    end

/* Write the data and bss spaces to the freeze file. */

visible int mapout_data(FileName)
	char *FileName;
    begin
	extern char *sbrk(), *_malloc_base;
	extern int data_start, my_edata;
	struct freeze_file_header FreezeHeader;
	int FileDescriptor;
	FreezeHeader.start_of_data = (char *) &data_start;
	FreezeHeader.end_of_data = (char *) &my_edata;
	FreezeHeader.start_of_bss = _malloc_base;
	FreezeHeader.end_of_bss = sbrk(0);
	FileDescriptor = open(FileName,O_WRONLY|O_CREAT|O_TRUNC,0666);
	if (FileDescriptor < 0) then
	    begin
		printf("emacs: cannot open freeze file %s\n",FileName);
		return 0;
	    end;
	if (write(FileDescriptor,&FreezeHeader,
		  sizeof(FreezeHeader)) < 0) then
	    begin
		printf("emacs: cannot write header to freeze file %s\n",
		       FileName);
		return 0;
	    end;
	if (write(FileDescriptor,FreezeHeader.start_of_data,
		  FreezeHeader.end_of_data
		  -FreezeHeader.start_of_data) < 0) then
	    begin
		printf("emacs: cannot write data space to freeze file %s\n",
		       FileName);
		return 0;
	    end;
	if (write(FileDescriptor,FreezeHeader.start_of_bss,
		  FreezeHeader.end_of_bss
		  -FreezeHeader.start_of_bss) < 0) then
	    begin
		printf("emacs: cannot write bss space to freeze file %s\n",
		       FileName);
		return 0;
	    end;
	close(FileDescriptor);
	return 1;
    end


#endif
