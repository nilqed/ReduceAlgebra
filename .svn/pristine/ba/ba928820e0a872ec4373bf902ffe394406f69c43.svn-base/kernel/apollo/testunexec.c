/* tryit.c - Test unexec.
 *
 * Compile as a.out .
 * "a.out" will save a new-a.out, which should print "Stuff = 12345" and exit.
 * "a.out -" will save a new-a.out without symbol table.
 * "a.out 100 200" will save a new a.out with the text and data boundaries
 *	moved by 100 and 200 respectively.  It will not find the same
 *	stuff on startup and should be killed with ^C.
 * "a.out - 100 200" will combine the above options.
 */
#include "stdio.h"
#include "signal.h"

#ifdef DSIZE
    char dummy[DSIZE] = 0;
#endif

int * stuff;
int oldbreakvalue;

extern etext, environ, edata, end;

main( argc, argv )
int argc;
char *argv[];
{
    char * orig_file = "a.out";

    if ( stuff != 0 )
    {
	printf( "Stuff at 0x%x: %d\n", stuff, *stuff );
    	exit( 0 );
    }
    stuff = (int *) malloc( sizeof(int) );
    printf( "Stuff addr: 0x%x\n", stuff );
    *stuff = 12345;

#   ifdef DSIZE
    printf( "DSIZE: 0x%x\n", DSIZE );
#   endif
    
    if ( argc > 1 && strcmp( argv[1], "-" ) == 0 )
    {
    	orig_file = 0;
    	argc--; argv++;
    }

    printf( "Current sbrk location = %d\n", sbrk(0));
    printf( "\ncontinue on input: "); getchar();
    /* kill(0,SIGSTOP); */
    if ( argc > 2 )    /* Try increasing setting sizes if any args given. */
	unexec( "new-a.out", "a.out",
		 &environ + atoi( argv[1] ), &edata + atoi( argv[2] ) );
    else
	unexec( "new-a.out", orig_file, 0, 0 );	/* Defaults if no args. */

}

#include <pwd.h>
struct passwd *getpwuid();
struct passwd *getpwnam();
char *getenv();
/* Tag( expand_file_name )
 */
char *expand_file_name(fname)
char *fname;
{
  register char *c, *t, *e, *s, save;
  char collect[255], copy[255];
  struct passwd *p;
  register int tilde;
  c = copy;
  s = fname;
  while (*c++ = *s++);
  s = copy;
  c = collect;
  *c = '\0';
  while (*s)
    {
      if ((tilde = (*s == '~')) || (*s == '$'))
        {
	  for (e = ++s; (*e != '/' && *e != '\0' && *e != '$'); e++)
	    ;
          t = 0;                        /* default initialization */
          if (e == s)
            {
	      if (tilde) t = ((getpwuid(getuid())) -> pw_dir);
	    }
          else
            {
	      save = *e;
              *e = '\0';
              if (tilde)
                {
		  if (p = getpwnam(s))  t = (p -> pw_dir);
		}
              else
                t = getenv(s);
              *e = save;
              s = e;
            }
          if (t)
	    while (*c++ = *t++)
	      ;
          else
	    return(fname);   /* name not found, just return original fname */
          c--;
        }
    for (; (*s != '\0' && *s != '$'); *c++ = *s++)
      ;
      *c = '\0';
  }
  return (collect);
}

extern int errno;
