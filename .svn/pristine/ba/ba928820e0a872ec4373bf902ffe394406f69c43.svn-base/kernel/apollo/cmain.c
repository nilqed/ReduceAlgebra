/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         cmain.c
% Description:  C main routine for Apollo systems
% Author:       Michael Hucka
% Created:      10-Apr-87
%
% (c) Copyright 1986, University of Utah.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

#include <strings.h>

main (argc, argv)
int    argc;
char **argv;
{
    char map_file_name[256];

    if (strcmp(argv[1], "-map") == 0) {
	if (argv[2] == (char *)0) {
	    printf("-map option must be followed by the map file's name.\n");
	    exit(1);
	}
	strcpy (map_file_name, argv[2]); /* Name of dump file. */
	if (! mapin_data(map_file_name)) {	 /* Map it all in. */
	    printf("Mapping in of dump file failed.\n");
	    exit(1);
	} else
	    apollo_restart(argc, argv);
    } else {			/* Not running from map file */
	apollo_main(argc, argv);
    }    
} /* end of main */

