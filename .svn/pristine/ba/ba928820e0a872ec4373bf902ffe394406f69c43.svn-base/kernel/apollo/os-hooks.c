/******************************************************************************
*
* File:         $PXK/OS-HOOKS.C
* Description:  OS specific startup and cleanup hooks.
* Author:       RAM, HP/FSD
* Created:      9-Mar-84
* Modified:	15-Jul-85 10:10:51 (RAM)
* Mode:         Text
* Package:      
* Status:       Experimental (Do Not Distribute)
*
* (c) Copyright 1984, Hewlett-Packard Company, all rights reserved.
*
******************************************************************************
* Revisions:
*
* 21-Sep-86 (Leigh Stoller)
*  Removed calls to the io-map functions. None of this was needed for the Sun.
*  Removed the 68020_advise function.
* 07-Jul-86 (Leigh Stoller)
*  Removed Calls to echooff and echoon since they are not needed for the top
*   loop, only for Nmode. Who knows why HP was calling them in the first place.
* 30-Apr-86 (Leigh Stoller)
* Copied this file from gator kernel directory and changed calls to terminal-
*  state to echooff and echoon, which are contained in echo.c
*
******************************************************************************
*/

#include <signal.h>

/* Tag( os_startup_hook )
 */
os_startup_hook(argc, argv)
int argc;
char *argv[];
{
  int exitlisp();

  setupbpsandheap(argc, argv); /* Allocate bps and heap areas. */

  /* signal(SIGKILL, exitlisp); */
}

/* Tag( os_cleanup_hook )
 */
os_cleanup_hook()
{

}

exitlisp()
{
   exit(1);
}
