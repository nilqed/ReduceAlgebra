
#ifdef CAN_FREEZE

extern char * _malloc_base;
extern int my_edata;

/* Structure to write into first block of map file.
 */

struct map_data
{
  char * sdata;			/* Start of data area */
  char * edata;			/* End of data area */
  char * smalloc;		/* Start of malloc area */
  char * emalloc;		/* End of malloc area */
};

static int write_data ();

/* Maps in the data and alloc area from the map file.
 */

int
mapin_data (name)
     char * name;
{
  int fd;
  struct map_data map_data;
  char * sbrk ();
  
  _malloc_base = sbrk(0);

  /* Open map file.
   */
  if ((fd = open (name, O_RDONLY)) < 0)
    {
      printf ("Map file not available, running bare Emacs....\n");
      return 0;			/* Map file not available */
    }

  /* Read the header data */
  if (read (fd, &map_data, sizeof (map_data)) != sizeof (map_data))
    {
      printf ("Map file not correct format, running bare Emacs....\n");
      return 0;			/* Map file not available */
    }

  if (map_data.sdata != start_of_data ())
    {
      printf ("Start of data area has moved: cannot map in data.\n");
      return 0;
    }
  if (map_data.edata != (char *) &my_edata)
    {
      printf ("End of data area has moved: cannot map in data.\n");
      return 0;
    }
  /* Extend virtual address space to end of previous malloc area.
   */
  if (brk (map_data.emalloc))
    {
      printf ("Couldn't set brk.\n");
      return 0;
    }

  /* Open the file for mapping now.
   */
  if (read (fd, map_data.sdata, 1+map_data.edata-map_data.sdata) < 0)
    {
      printf ("Couldn't read data section.\n");
      exit (1);
    }

  /* Check mapping.
   */
  if (_malloc_base != map_data.smalloc)
    {
      printf ("Data area mapping invalid.\n");
      exit (1);
    }
  /* Map malloc area.
   */
  if (read (fd, map_data.smalloc, 1+map_data.emalloc-map_data.smalloc) < 0)
      exit (1);

  close (fd);

  return 1;
}

/* Writes the data and alloc area to the map file.
 */

mapout_data (into)
     char * into;
{
  int fd;
  struct map_data map_data;
  char * sbrk ();
  
  map_data.sdata = start_of_data ();
  map_data.edata = (char *) &my_edata;
  map_data.smalloc = _malloc_base;
  map_data.emalloc = sbrk (0) - 1;
  /* Create map file.
   */
  fd = open (into, O_WRONLY | O_CREAT, 0666);
  write (fd, &map_data, sizeof (map_data));
  write (fd, map_data.sdata, 1+map_data.edata-map_data.sdata);
  write (fd, map_data.smalloc, 1+map_data.emalloc-map_data.smalloc);
  close (fd);
  return 1;
}

#endif /* CAN_FREEZE */
