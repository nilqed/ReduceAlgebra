/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         bpsheap.c
% Description:  Code to dynamically set up bps and heap structures
% Author:       RAM, HP/FSD
% Created:      9-Mar-84
% Modified:     
% Mode:         Text
% Package:      
%
% (c) Copyright 1987, University of Utah, all rights reserved.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
% 11-Aug-88 (Julian Padget)
%  Added initialization of BPSLOWERBOUND in setupbps().
% 07-Apr-87 (Harold Carr & Leigh Stoller)
%  Put in error checking to ensure that the memory pointers will fit in
%   info field of the lisp item.
% 21-Dec-86 (Leigh Stoller)
%  Added allocatemorebps function, called from try-other-bps-spaces in
%   allocators.sl. 
% 18-Dec-86 (Leigh Stoller)
%  Changed to newer model. Bps is now defined in bps.c so that unexec can
%  alter the text/data boundry. Took out code that allowed command line
%  modification of bpssize. (Now set in the Makefile). Added setupbps()
%  that initialzes NEXTBPS and LASTBPS.
% 20-Sep-86 (Leigh Stoller)
%  Removed assembler alias statements because they are not portable. Instead,
%  a sed script will be used to convert the _variables of C to VARIABLES of
%  PSL.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

/* Use 1 if using compacting collector ($pxnk/compact-gc.sl).
   Use 2 if using copying collector ($pnk/copying-gc.sl).
   Be sure to update $pxnk/load-psl.sl to include correct collector. */

#define NUMBEROFHEAPS  1        

#define MINSIZE        3000000  /* Default total in number of bytes. */
#define MALLOCSIZE     4096     /* Default size for OS support functions. */
#define EXTRABPSSIZE   100000   /* Minimum amount to increase bps by. */
#define MINIMUMHEAPADD 20000    /* Minimum amount to increase heap by */


#ifndef BPSSIZE
#define BPSSIZE	      800000    /* Default bps size in number of bytes */
#endif

int     alreadysetupbpsandheap;
int     max_image_size;
int 	oldbreakvalue;

extern int  alreadysetupbpsandheap;
extern char bps[];
extern int  LASTBPS;
extern int  NEXTBPS;
extern int  BPSLOWERBOUND;
extern int  _INFBITLENGTH_;

extern int  HEAPLOWERBOUND;
extern int  HEAPUPPERBOUND;
extern int  HEAPLAST;
extern int  HEAPTRAPBOUND;

#if (NUMBEROFHEAPS == 1)
extern int  GCARRAYLOWERBOUND;
#endif

#if (NUMBEROFHEAPS == 2)
extern int  OLDHEAPLOWERBOUND;
extern int  OLDHEAPUPPERBOUND;
extern int  OLDHEAPLAST;
extern int  OLDHEAPTRAPBOUND;
#endif

/* Write this ourselves to keep from including half the math library */
static power(x, n)
     int x, n;
{
  int i, p;

  p = 1;
  for (i = 1; i <= n; ++i)
    p = p * x;
  return(p);
}

setupbpsandheap(argc,argv)
     int argc;
     char *argv[];
{
  int    i, total, bpssize, heapsize, mallocsize;
  int    current_size_in_bytes, heapsize_in_bytes;
  double bpspercent, heappercent;
  char   *argp, *scanptr, *scanformat;

  if (alreadysetupbpsandheap)   /* If this session was dumplisped ... */
    { 
      return 0;
    }

  total		= MINSIZE;
  mallocsize	= MALLOCSIZE;
  
  for (i=1; i<argc-1; i++)
    {
      argp = argv[i];
      if (*argp++ == '-')
        {
          scanformat = "";
          switch (*argp++) {
            case 't': scanptr = (char *)&total;
                      switch (*argp) {
		        case 'x': scanformat = "%x";
			          break;
                        case 'd': scanformat = "%d";
                                  break;
		      }
                      break;
            case 'm': scanptr = (char *)&mallocsize;
                      switch (*argp) {
                        case 'x': scanformat = "%x";
                                  break;
                        case 'd': scanformat = "%d";
                                  break;
                      }
                      break;
          }
          if (*scanformat != 0)
            sscanf(argv[i+1],scanformat,scanptr);
        }
    }   /* end of for loop -- arg vector searched */

  /* insure valid values */
  if (total == 0)
    total = MINSIZE;

  if (mallocsize <= 0)
    mallocsize = MALLOCSIZE;

  /* Reserve some space for C's usr of io buffers, etc. By mallocing then
     freeing, the memory is sbrk'ed onto the image, but available for future
     calls to malloc, which will not need to call sbrk again. */
  free(malloc(mallocsize));	

  bpssize = BPSSIZE;

  heapsize_in_bytes = total - bpssize;

  /* On systems in which the image does not start at address 0, this won't
     really allocate the full maximum, but close enough. */
  current_size_in_bytes = (int) sbrk(0);
  max_image_size = power(2, _INFBITLENGTH_); /* 1 more than allowable size */
  
  if ((heapsize_in_bytes + current_size_in_bytes) >= max_image_size) {
    heapsize_in_bytes = max_image_size - current_size_in_bytes;
    total = heapsize_in_bytes + bpssize;
    printf("Size requested will result in pointer values larger than\n");
    printf(" PSL items can handle. Will allocate maximum size instead.\n\n");
  }

#if (NUMBEROFHEAPS == 2)
  heapsize =(heapsize_in_bytes / 4) * 2;  /* insure full words */
#else
  heapsize =(heapsize_in_bytes / 4) * 4;  /* insure full words */
#endif

  heappercent = ((float) (total - bpssize) / total) * 100.0;
  bpspercent  = ((float) bpssize / total) * 100.0;

  printf("Setting heap limit as follows:\n");
  printf("Total heap & bps space = %d (%X), bps = %.2f, heap = %.2f\n",
          total, total, bpspercent, heappercent);

  setupbps();
  getheap(heapsize);

  printf("bpssize = %d (%X), heapsize = %d (%X)\nTotal image size = %d (%X)\n",
          bpssize, bpssize,
          heapsize, heapsize,
          (int) sbrk(0), (int) sbrk(0));

  alreadysetupbpsandheap = 1;
}


/* The current procedure is to convert the starting address of the char
   array defined in bps.c to an address and store it in NEXTBPS. A check
   is made to make sure that NEXTBPS falls on an even word boundry.
 */
setupbps()
{
  NEXTBPS  =  ((int)bps + 3) & ~3;		/* Up to a multiple of 4. */
  BPSLOWERBOUND = NEXTBPS;
  LASTBPS  =  ((int)bps + BPSSIZE) & ~3;	/* Down to a multiple of 4. */
}  


/* Allocate alternate bps space. Note: The use of sbrk(), and the fact that
   NEXTBPS is now greater than HEAPLAST means that unexec should be not be
   tried after this routine is called. The image would be huge.
 */
allocatemorebps()
{
  int current_size_in_bytes;
  int old_NEXTBPS = NEXTBPS;
  
  current_size_in_bytes = sbrk(0);

  if ((current_size_in_bytes + EXTRABPSSIZE) >= max_image_size)
    return(0);

  if (((int)sbrk(0)) % 2)      /* force to even word boundary*/
     NEXTBPS = (int)sbrk(1);
 
  NEXTBPS = (int)sbrk(EXTRABPSSIZE);   /* allocate extra BPS */
  if (NEXTBPS == -1) {
    NEXTBPS = old_NEXTBPS;
    return(0);
  }
  LASTBPS = NEXTBPS + EXTRABPSSIZE;

  return(EXTRABPSSIZE);   /* This will be a paramter later */
}
 
  
/* tag( getheap )
 */
getheap(heapsize)
     int heapsize;
{

#if (NUMBEROFHEAPS == 1)
  int gcarraysize;

  gcarraysize = (int)(((heapsize / 9) / 4) * 4);
  heapsize -= gcarraysize;
#endif

  HEAPLOWERBOUND        = (int)sbrk(heapsize);  /* allocate first heap */;
  if (HEAPLOWERBOUND == -1) {
    perror("GETHEAP");
    exit(-1);
  }
  HEAPUPPERBOUND        = HEAPLOWERBOUND + heapsize;
  HEAPLAST              = HEAPLOWERBOUND;
  HEAPTRAPBOUND         = HEAPUPPERBOUND;

#if (NUMBEROFHEAPS == 1)
  GCARRAYLOWERBOUND     = (int)sbrk(gcarraysize);       /* allocate gcarray */
  if (GCARRAYLOWERBOUND == -1) {
    perror("GETHEAP");
    exit(-1);
  }
#endif

#if (NUMBEROFHEAPS == 2)
  OLDHEAPLOWERBOUND     = (int)sbrk(heapsize);  /* allocate second heap */
  if (OLDHEAPLOWERBOUND == -1) {
    perror("GETHEAP");
    exit(-1);
  }
  OLDHEAPUPPERBOUND     = OLDHEAPLOWERBOUND + heapsize;
  OLDHEAPLAST           = OLDHEAPLOWERBOUND;
  OLDHEAPTRAPBOUND      = OLDHEAPUPPERBOUND;
#endif
  oldbreakvalue = (int)sbrk(0);
}

/* Tag( alterheapsize )
 */
alterheapsize(increment)
int increment;
{
/*
  alters the size of the heap by the specified increment.  Returns
  the increment if successful, otherwise returns 0.  May fail if
  the sbrk is unsuccessful or if the user tries to cut the heap back
  to nothing or the current break value does not match the old value.
  The latter case occurs when a malloc or sbrk has allocated space for
  some other software, in which case we cannot allocate any more space
  contiguously.

  Modifies both the heap and gcarray size.
  NOTE: a garbage collection should probably be performed before this
	routine is called.
  NOTE: only implemented for the one heap version on the 68000.
*/

  int heapsize;
  int current_size_in_bytes;
  
#if (NUMBEROFHEAPS == 1)
  int gcarraysize, newbreakvalue;

  if ((int) sbrk(0) != oldbreakvalue)  /* Non contiguous memory */
      return(0);

  newbreakvalue = oldbreakvalue + increment;

  /* don't let the user cut his heap back to nothing, taking into account
     space for the gcarray. */
  if ((increment < 0) &&
      ((newbreakvalue - HEAPLOWERBOUND) <
       (((HEAPLAST + MINIMUMHEAPADD - HEAPLOWERBOUND) * 9) / 8)))
    return(0);

  current_size_in_bytes = sbrk(0);

  if ((current_size_in_bytes + increment) >= max_image_size)
    return(0);

  if ((int)sbrk(increment) == -1) 	/* the sbrk failed. */
     return(0);

  newbreakvalue = (int) sbrk(0);
  heapsize = (((newbreakvalue - HEAPLOWERBOUND) / 4) * 4);

  gcarraysize = (((heapsize / 9) / 4) * 4);
  heapsize = heapsize - gcarraysize;

  HEAPUPPERBOUND = HEAPLOWERBOUND + heapsize;
  HEAPTRAPBOUND	 = HEAPUPPERBOUND;

  GCARRAYLOWERBOUND = HEAPUPPERBOUND; /* allocate gcarray */

  oldbreakvalue	= newbreakvalue;
  return(increment);
#else
  return(0);
#endif

}
