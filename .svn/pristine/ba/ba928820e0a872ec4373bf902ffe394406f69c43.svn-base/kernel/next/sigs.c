/* 
 * sigs.c - External routines to deal with signals
 * 
 * Author:	Leigh Stoller
 * 		Computer Science Dept.
 * 		University of Utah
 * Date:	18-Aug-1986
 *
 *           Modified by Chris Burdorf (2/17/89) 
 *           renamed sigset to psl_sigset for sun os 4.
 */

#include <signal.h>

/* Tag( psl_sigset )
 */
psl_sigset( sig, action )
void (*action)();
int sig;
{
  if (signal(sig, SIG_IGN) != SIG_IGN)
    signal(sig, action);

}

/* Tag( sigrelse )
 */
sigrelse(sig, action)
void (*action)();
int sig;
{
  /* For bsd */
  sigsetmask( sigblock(0) & ~ 1<<sig );	 /* Unblock the signal. */

  /* For system V */
  /*  signal(sig, action); */
}
