char * datetag ()
  { return ( 
" Wed Mar 11 17:52:38 1992 "
           ); } 
