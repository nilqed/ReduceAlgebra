/* 
 * unexec.c - Convert a running program into an a.out file.
 * 
 * Author:	Spencer W. Thomas
 * 		Computer Science Dept.
 * 		University of Utah
 * Date:	Tue Mar  2 1982
 * Copyright (c) 1982 Spencer W. Thomas
 *
 * Synopsis:
 *	unexec( new_name, a_name, data_start, bss_start )
 *	char *new_name, *a_name;
 *	unsigned data_start, bss_start;
 *
 * Takes a snapshot of the program and makes an a.out format file in the
 * file named by the string argument new_name.
 * If a_name is non-NULL, the symbol table will be taken from the given file.
 * 
 * The boundaries within the a.out file may be adjusted with the data_start 
 * and bss_start arguments.  Either or both may be given as 0 for defaults.
 * 
 * Data_start gives the boundary between the text segment and the data
 * segment of the program.  The text segment can contain shared, read-only
 * program code and literal data, while the data segment is always unshared
 * and unprotected.  Data_start gives the lowest unprotected address.  The
 * default when 0 is given leaves the number of protected pages the same as
 * it was before.
 * 
 * Bss_start indicates how much of the data segment is to be saved in the
 * a.out file and restored when the program is executed.  It gives the lowest
 * unsaved address, and is rounded up to a page boundary.  The default when 0
 * is given assumes that the entire data segment is to be stored, including
 * the previous data and bss as well as any additional storage allocated with
 * break (2).
 * 
 * Machine dependencies:  
 * 
 * Since the granularity of write-protection is on 1k page boundaries on
 * the VAX, a given data_start value which is not on a page boundary is
 * rounded down to the beginning of the page it is on.  
 * 
 * The Sun is an extreme case of the same situation.  The text and data
 * segments each start on 32k boundaries, so a data_start value will be
 * rounded down to the next lower 32k.  There is a gap  of unreadable pages
 * between the text segment and the data segment which is plugged by blocks
 * of zero bytes in the a.out file produced by unexec.
 * 
 * The dependency on access to the process u structure in the original Vax
 * version was lifted by using the "magic" symbols etext and edata (defined
 * by ld(1) if referenced) and assuming ZMAGIC output files, which may not
 * be valid everywhere.
 * 
 * If you make improvements I'd like to get them too.
 * harpo!utah-cs!thomas, thomas@Utah-20
 *
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef NO_ZWRITE
    /* "zwrite" saves disk space by seeking over zero blocks.  There are
     * currently megabytes of space in the middle of a PSL executable.
     * Revert to the usual write/close fns if zwrite is configured out.
     */
#   define zwrite write
#   define zclose close
#endif not ZWRITE

#include <a.out.h>
/* SEGSIZ, if defined in a.out.h, indicates a segmented memeory
 * management scheme like the Sun-1.
 */
#ifdef SEGSIZ
#  define DAT_RND(addr) ( (addr) & ~(SEGSIZ-1) ) /* Down to seg boundary. */
#  define SDATA(x) N_DATADDR(x)		/* First seg bdry above text. */
#else
#  define DAT_RND(addr) ( (addr) & ~(PAGSIZ-1) ) /* Down to page boundary. */
#  define SDATA(x) ( STEXT + x.a_text )	/* Page bdry at end of text. */
#endif
#ifndef PAGSIZ
#   define PAGSIZ 1024			/* Default page size. */
#endif

#ifdef N_TXTADDR			/* Address of start of text seg. */
#  define STEXT N_TXTADDR(hdr)		/* On Suns. */
#else
#   define STEXT 0
#endif

/* Default a.out magic number (executable file format) to use if no a.out 
 * file given.  [Beware for PSL, if supporting oload check that "ld -A"
 * produces the same magic numbers or fix make_hdr() below.]
 */
#define DEF_MAGIC ZMAGIC

extern char etext, edata;		/* Magically defined by ld. */
/* Round text end up to page boundary. */
#define ETEXT (  ( (unsigned)&etext + (PAGSIZ-1) ) & ~(PAGSIZ-1)  )
#define EDATA (unsigned)&edata

#ifdef PDP11		/* this is ridiculous, it isn't needed there... */
#define	N_BADMAG(x) ((x.a_magic != A_MAGIC1) && (x.a_magic != A_MAGIC2) &&\
		     (x.a_magic != A_MAGIC3) && (x.a_magic != A_MAGIC4) &&\
		     (x.a_magic != A_MAGIC5) && (x.a_magic != A_MAGIC6) )
#define N_TXTOFF(hdr)	(sizeof hdr)
#define	OMAGIC	A_MAGIC1	/* Magic number of Writeable text file */
#endif

#define BLOCKSIZE 10240

static struct exec hdr, ohdr, shdr;

/* ****************************************************************
 * unexec
 *
 * driving logic.
 */
unexec( n_name, o_name, data_start, bss_start )
char *n_name, *o_name;
unsigned data_start, bss_start;
{
    FILE *newf;
    int new, a_out = -1;
    char new_name[256], a_name[256];

    /* Expand both filenames now. Place in seperate static arrays so that
       mallocs are not needed at runtime. Messes up the unexec by
       changing the oldbreakvalue.
     */
    strcpy(new_name, expand_file_name(n_name));
    if (o_name)
      strcpy(a_name, expand_file_name(o_name));

#ifdef TESTING
    /* This probably should not be here, but since it is a problem caused
       by the unexec, we will install the fix here. Simply, bound_domains
       is a static variable in the yellow pages network code that must be
       reset before we unexec. If not, the new image comes up with a bogus
       value that puts PCLS into an infinite loop trying to execute
       psl:read-init-file. This is a SUN related problem. The routine
       being called is in $pxk/yp/yp_bind.c, our own version of the library.
     */

    clear_bound_domains();
    fprintf(stderr, "Clearing bound_domains.\n");
#endif    
    
    if ( a_name && (a_out = open( a_name, 0 )) < 0 )
    {
	perror( a_name );
	return -1;
    }
    if ( (newf = fopen( new_name, "w" )) == NULL )
    {
	perror( new_name );
	return -1;
    }
    fclose(newf);
    new = open( new_name, 1);	    /* This fd will be written with zwrite. */
    zinit();	/* Make sure zwrite forgets any old disk table information. */

    if (make_hdr( new, a_out, data_start, bss_start ) < 0 ||
	copy_text_and_data( new ) < 0 ||
	copy_sym( new, a_out ) < 0)
    {
	zclose( new );
	/* unlink( new_name );	    	/* Failed, unlink new a.out */
	return -1;	
    }

    zclose( new );
    if ( a_out >= 0 )
	close( a_out );
    mark_x( new_name );
    return 0;
}

/* ****************************************************************
 * make_hdr
 *
 * Make the header in the new a.out from the header in core.
 * Modify the text and data sizes.
 */
static int
make_hdr( new, a_out, data_start, bss_start )
int new, a_out;
unsigned data_start, bss_start;
{
    unsigned sbrk(), max_addr = sbrk(0);	/* End of allocated space. */

    /* Get symbol table info from header of a.out file if given one. */
    if ( a_out >= 0 )
    {
	if ( read( a_out, &hdr, sizeof hdr ) != sizeof hdr )
	{
	    perror( "Couldn't read header from a.out file" );
	    return -1;
	}

	if N_BADMAG( hdr )
	{
	    fprintf( stderr, "a.out file doesn't have legal magic number\n" );
	    return -1;
	}
    
	/* Save hdr as it was read in, to find symbol table in a.out file. */
	shdr = hdr;
    }
    else
    {
	hdr.a_magic = DEF_MAGIC;	/* Don't know the REAL magic #. */
	hdr.a_entry = STEXT;		/* Assume entry at start of text. */
	hdr.a_syms = 0;			/* No a.out, so no symbol info. */
    }
printf("entry point = %lx\n", hdr.a_entry);
    /* Construct header from default assumptions.
     * (hdr.a_magic, hdr.a_entry and hdr.a_syms are set above.)
     */
    hdr.a_text = ETEXT - STEXT;		/* Size of program text. */
    hdr.a_data = EDATA - SDATA(hdr);	/* Data between text and bss. */
    hdr.a_bss = max_addr - EDATA;	/* Remainder is bss. */
    hdr.a_trsize = 0;
    hdr.a_drsize = 0;

    /* Save hdr before adjustments, for msgs. */
    ohdr = hdr;

    /* Adjust data/bss boundary. */
    if ( bss_start != 0 )
    {
	bss_start = (bss_start+PAGSIZ-1) & ~(PAGSIZ-1);/* Up to page bdry. */
	if ( bss_start > max_addr )
	{
	    fprintf( stderr,
		"unexec: Bss_start( 0x%x ) is past end of program.\n",
		bss_start );
	    return -1;
	}

	hdr.a_data = bss_start - SDATA(hdr);  /* Data between text and bss. */
	hdr.a_bss =  max_addr - bss_start;	/* Remainder is bss. */
    }
    else			/* Default - All data is inited now! */
    {
	hdr.a_data = max_addr - SDATA(hdr);
	hdr.a_bss = 0;
	bss_start = max_addr;		/* At end. */
    }

    /* Adjust text/data boundary. */
    if ( data_start != 0 )
    {
	data_start = DAT_RND( data_start ); /* Down to page (segment) bdry. */
	if ( data_start != SDATA(ohdr) )      /* Really changed bdry? */
	    hdr.a_text = data_start - STEXT;  /* New size of text segment. */
	hdr.a_data = bss_start - SDATA(hdr);  /* Data between text and bss. */
    }
    else
    {
	data_start = SDATA(hdr);
    }

    /* Chatty... */
#ifndef SEGSIZ		/* No funny gap business. */
    if ( ohdr.a_text == hdr.a_text )
	printf( "Text/Data boundary is 0x%x\n", SDATA(hdr) );
    else
	printf( "Text/Data boundary was 0x%x, is now 0x%x\n",
	    SDATA(ohdr), SDATA(hdr) );
#else		/* Text top and data bottom have a gap between them. */
    if ( ohdr.a_text == hdr.a_text )
	printf( "Text end is 0x%x, data start is 0x%x\n", ETEXT, SDATA(hdr) );
    else
	printf( "Text/Data gap was 0x%x-0x%x, boundary is now 0x%x\n",
	    ETEXT, SDATA(ohdr), SDATA(hdr) );
#endif
    printf( "Data/Bss boundary was 0x%x, is now 0x%x\n",
	SDATA(ohdr) + ohdr.a_data, SDATA(hdr) + hdr.a_data );
    if ( data_start > bss_start )	/* Can't have negative data size. */
    {
	fprintf( stderr,
	    "unexec: data_start(0x%x) can't be above bss_start(0x%x).\n",
	    data_start, bss_start );
	return -1;
    }
    if ( STEXT != 0 )
	printf( "Text segment size was 0x%x, is now 0x%x\n",
	    ohdr.a_text, hdr.a_text );
    printf( "Data segment size (excluding bss) was 0x%x, is now 0x%x\n",
	ohdr.a_data, hdr.a_data );

    if ( zwrite( new, &hdr, sizeof hdr ) != sizeof hdr )
    {
	perror( "Couldn't write header to new a.out file" );
	return -1;
    }
    return 0;
}

/* ****************************************************************
 * copy_text_and_data
 *
 * Copy the text and data segments from memory to the new a.out
 */
static int
copy_text_and_data( new )
int new;
{
    int sz;

/* Sun storage manglement leaves a gap between the text and data segments. */
#ifdef SEGSIZ
    /* Original text segment immediately follows exec hdr on the Sun. */
    sz = ohdr.a_text - sizeof(struct exec); /* Don't wipe out header struct. */
    if ( zwrite( new, STEXT + sizeof(struct exec), sz ) != sz )
    {
	perror( "Write failure in text segment" );
	return -1;
    }
    if ( SDATA(ohdr) != SDATA(hdr) )
    {
    	/* Top of text seg moved, fill the gap with zeros. */
	zlseek( new, SDATA(ohdr) - ETEXT, 1 );	/* Seek over it. */
    }

    /* Now remainder of text seg that was data, and data segment. */
    sz = ( SDATA(hdr)-SDATA(ohdr) ) + hdr.a_data;
    if ( zwrite( new, SDATA(ohdr), sz ) != sz )
    {
	perror( "Write failure in data segment" );
	return -1;
    }
#else			/* Text segment and data segment are contiguous. */
    zlseek( new, (long)N_TXTOFF(hdr), 0 );
    if ( zwrite( new, STEXT, hdr.a_text+hdr.a_data ) != hdr.a_text+hdr.a_data )
    {
	perror( "Write failure in text/data segments" );
	return -1;
    }
#endif
    return 0;
}

/* ****************************************************************
 * copy_sym
 *
 * Copy the relocation information and symbol table from the a.out to the new
 */
static int
copy_sym( new, a_out )
int new, a_out;
{
    char block[BLOCKSIZE];
    int n;

    if ( a_out < 0 )
	return 0;

    /* Position a.out to symtab and copy the rest of the file. */
    lseek( a_out, (long)N_SYMOFF(shdr), 0 );
    while ( (n = read( a_out, block, BLOCKSIZE )) > 0 )
    {
	if ( zwrite( new, block, n ) != n )
	{
	    perror( "Error writing symbol table to new a.out" );
	    fprintf( stderr, "new a.out should be ok otherwise\n" );
	    return 0;
	}
    }
    if ( n < 0 )
    {
	perror( "Error reading symbol table from a.out,\n" );
	fprintf( stderr, "new a.out should be ok otherwise\n" );
    }
    return 0;
}

/* ****************************************************************
 * mark_x
 *
 * After succesfully building the new a.out, mark it executable
 */
static
mark_x( name )
char *name;
{
    struct stat sbuf;
    int um;

    um = umask( 777 );
    umask( um );
    if ( stat( name, &sbuf ) == -1 )
    {
	perror ( "Can't stat new a.out" );
	fprintf( stderr, "Setting protection to %o\n", 0777 & ~um );
	sbuf.st_mode = 0777;
    }
    sbuf.st_mode |= 0111 & ~um;
    if ( chmod( name, sbuf.st_mode ) == -1 )
	perror( "Couldn't change mode of new a.out to executable" );

}

#ifndef NO_ZWRITE
#ifndef lint
static char RCSid[] = "$Header: zwrite.c,v 1.5 85/10/06 23:08:27 lepreau Exp $";
#endif
/*
 * zwrite(): like write(2), but creates holes in files if possible.
 * If a write() fails zwrite returns -1 instead of the number of
 * bytes written-- what do you think about this?
 *
 * zlseek(): is like lseek(2), but keeps track of seeks on a file being
 * written by zwrite.
 * 
 * zclose() should be called instead of close() if fd's are to be re-used
 * or if you might have zeroes at the end of the file.  And you should
 * check that zclose returns 0, also!
 *
 * Current `vax' code assumes st_blksize (filesys blksize) is <= 64K;
 * non-vax code not yet tested.
 *
 * Donn Seeley and Jay Lepreau, Univ of Utah, April 1985.
 */

/*** #include <sys/types.h> *** Already included by unexec. ***/
/*** #include <sys/stat.h> *** Already included by unexec. ***/
#include <sys/file.h>

#define min(a,b)	((a) < (b) ? (a) : (b))
typedef int boolean;
#define TRUE 1
#define FALSE 0

struct dtab {
	int blksize;
	off_t offset;
	boolean last_seek;		/* Last op was a seek. */
};

static struct dtab (*bp)[];
static int dtabsize;

/* Unexec has to forget old disktab info, since PSL unexecs repeatedly. */
zinit()
{
    dtabsize = 0;
}

int
zwrite(fd, buf, len)
	int fd;
	register char *buf;		/* known to be r11 below */
	int len;
{
	register int count;		/* known to be r10 below */
	register int notzero;		/* known to be r9 below */
	int savelen = len;
	int obsize, need;
	off_t loc;
	struct stat statb;

	if (dtabsize == 0) {
		register int i;
		extern char *malloc();

		dtabsize = getdtablesize();
		bp = (struct dtab (*)[]) malloc((unsigned) (dtabsize * sizeof(struct dtab)));
		if (bp == 0)
			return write(fd, buf, len);
		for (i = 0; i < dtabsize; i++) {
			(*bp)[i].blksize = -1;
			(*bp)[i].offset = 0;
			(*bp)[i].last_seek = FALSE;
		}
	}
	/* get output blocksize if we don't have it already */
	if ((*bp)[fd].blksize < 0) {
		if (fstat(fd, &statb) < 0 ||
		   (statb.st_mode & S_IFMT) == S_IFSOCK ||
		   (statb.st_mode & S_IFMT) == 0)	/* avoid kernel bug */
			(*bp)[fd].blksize = 0;	/* remember we are screwed */
		else
			(*bp)[fd].blksize = statb.st_blksize;
	}
	if ((obsize = (*bp)[fd].blksize) == 0)
		return write(fd, buf, len);

	while (len > 0) {
		/* How much do we need to fill out to a block boundary? */
		need = obsize - (*bp)[fd].offset % obsize;
		count = min( len, need ? need : obsize );
			
		/* Are there any non-zero chars in this block? */
		notzero = 0;
#ifdef vax
		asm("	skpc	$0,r10,(r11)");
		asm("	beql	1f");		/* all zeroes */
		asm("	incl	r9");		/* notzero++ */
		asm("1:");
#else
		{
		register char *p;
		char *endbuf;
		
		p = buf;
		endbuf = buf + count;
		while (p < endbuf)
			if (*p++) {
				notzero++;
				break;
			}
		}
#endif
		if (notzero) {
			if (write(fd, buf, count) != count)
				return -1;
			(*bp)[fd].last_seek = FALSE;
			(*bp)[fd].offset += count;
		}
		else {
			if ((loc = lseek(fd, (off_t) count, L_INCR)) < 0)
				return -1;
			(*bp)[fd].last_seek = TRUE;
			(*bp)[fd].offset = loc;
		}
		len -= count;
		buf += count;
	}
	return savelen;
}

int
zlseek( fd, offset, whence )
int fd, offset, whence;
{
	int loc;

	loc = lseek( fd, offset, whence );

	(*bp)[fd].last_seek = TRUE;
	(*bp)[fd].offset = loc;

	return loc;
}

zclose(fd)
{
	int rc = 0;

	if (bp) {
		/* Can't just seek at end and expect to get anything! */
		if ((*bp)[fd].last_seek) {
			if (lseek(fd, (off_t) -1, L_INCR) < 0) 
				rc = -1;
			else if (write(fd, "", 1) != 1)
				rc = -1;
		}
		(*bp)[fd].blksize = -1;
		(*bp)[fd].offset = 0;
		(*bp)[fd].last_seek = FALSE;
	}
	if (close(fd) < 0)
		return -1;
	else
		return rc;
}
#endif ZWRITE
