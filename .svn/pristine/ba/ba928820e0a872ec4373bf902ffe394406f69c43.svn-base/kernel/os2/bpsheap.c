/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         bpsheap.c
% Description:  Code to dynamically set up bps and heap structures
% Author:       RAM, HP/FSD
% Created:      9-Mar-84
% Modified:
% Mode:         Text
% Package:
%
% (c) Copyright 1987, University of Utah, all rights reserved.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

#include <stdio.h>

/* Use 1 if using compacting collector ($pxnk/compact-gc.sl).
   Use 2 if using copying collector ($pnk/copying-gc.sl).
   Be sure to update $pxnk/load-psl.sl to include correct collector. */

#define NUMBEROFHEAPS 1

#define MINSIZE        5000000  /* Default total in number of bytes. */
#define MALLOCSIZE     500000   /* Default size for OS support functions. */
#define EXTRABPSSIZE   300000   /* Minimum amount to increase bps by. */
#define MINIMUMHEAPADD 20000    /* Minimum amount to increase heap by */


#ifndef BPSSIZE
#define BPSSIZE         1600000    /* Default bps size in number of bytes */
#endif

char *  imagefile ;
int     max_image_size;
int     oldbreakvalue;

int     bpssize;

extern int  alreadysetupbpsandheap;
extern int  mainstartinitialize;
extern int  HASHTABLE;
extern char  bps[];
extern char *  SYMNAM;
extern int  lastbps;
extern int  nextbps;
extern int  bpslowerbound;
extern int  _infbitlength_;

extern int  heaplowerbound;
extern int  heapupperbound;
extern int  heaplast;
extern int  heaptrapbound;

extern int  oldheaplowerbound;
extern int  oldheapupperbound;
extern int  oldheaplast;
extern int  oldheaptrapbound;

extern FILE * scriptin, * scriptout;
extern int scriptmode;
extern int win_mode;

char * envname = (char*)NULL;

char * external_getenv(char *);    

/* Write this ourselves to keep from including half the math library */
static power(x, n)
     int x, n;
{
  int i, p;

  p = 1;
  for (i = 1; i <= n; ++i)
    p = p * x;
  return(p);
}

setupbpsandheap(argc,argv)
     int argc;
     char *argv[];
{ int ohl,ohtb,ohlb,ohub,hl,htb,hlb,hub;
  int memset = 0; int feder = 200000;
  FILE * imago;
  char * scriptinfile = NULL, * scriptoutfile = NULL;
  int headerword [8];
  int    i, total,  heapsize, mallocsize;
  int    current_size_in_bytes, heapsize_in_bytes;
  double bpspercent, heappercent;
  char   *argp, *scanptr, *scanformat;
  int ii1,ii2,ii3,ii4,ii5,ii6,ii7,ii8,ii9,ii10,ii11;

  total        = MINSIZE;
  mallocsize    = MALLOCSIZE;

  for (i=1; i<argc; i++)
    {
      argp = argv[i];
      /* printf("par %d: %s\n",i,argp);  */
      if (*argp++ == '-')
	{
	  scanformat = "";
	  switch (*argp++) {
	    case 't': scanptr = (char *)&total;
		      memset = 1;
		      switch (*argp) {
		case 'x': scanformat = "%x";
		      break;
			case 'd': scanformat = "%d";
				  break;
	      }
		      break;
	    case 'm': scanptr = (char *)&mallocsize;
		      switch (*argp) {
			case 'x': scanformat = "%x";
				  break;
			case 'd': scanformat = "%d";
				  break;
		      }
		      break;
	   case 'f': if(i+1<argc) imagefile = argv[i+1]; break;
	   case 'i': if(i+1<argc) scriptinfile = argv[i+1]; break;
	   case 'o': if(i+1<argc) scriptoutfile = argv[i+1]; scriptmode=0; break;
	   case 'd': if(i+1<argc) scriptoutfile = argv[i+1]; scriptmode=1; break;
	   case 'w': win_mode = 1; break;
	   case 'g': scanptr = (char *)&feder;
		     scanformat = "%d"; break;
	   case 'e': if(i+1<argv) envname = argv[i+1]; break;
	  }
	  if (*scanformat != 0)
	   { 
	    if(*argv[i+1] == '%')  /* unexpanded environemnt variable */
	    { char * c;
	      argv[i+1]++;
	      c = argv[i+1];
	      while(*c && c!='%') c++; *c=0;
	      argv[i+1] = external_getenv(argv[i+1]);
	    }
	    if(argv[i+1]) sscanf(argv[i+1],scanformat,scanptr);
	   }
	}
    }   /* end of for loop -- arg vector searched */

  if(scriptinfile)
    { 
      scriptin = fopen(scriptinfile,"r");
      if(scriptinfile == NULL)
      { 
	printf("cannot open input file >%s<\n",scriptinfile);
	exit(-1);
      }
    }

  if(scriptoutfile)
    { 
      scriptout = fopen(scriptoutfile,"w");
      if(scriptoutfile == NULL)
      { 
	printf("cannot open output file >%s<\n",scriptoutfile);
	exit(-1);
      }
    }

  /* insure valid values */
  if (total == 0)
    total = MINSIZE;

  if (mallocsize <= 0)
    mallocsize = MALLOCSIZE;

  /* Reserve some space for C's usr of io buffers, etc. By mallocing then
     freeing, the memory is sbrk'ed onto the image, but available for future
     calls to malloc, which will not need to call sbrk again. */

 
  external_user_homedir_string(); /* This is done by read-init-file */

  bpssize = BPSSIZE;

  for (i=0;i<bpssize;i++) bps[i]=15;    /* illegal opcode */

  heapsize_in_bytes = total - bpssize;

  /* On systems in which the image does not start at address 0, this won't
     really allocate the full maximum, but close enough. */
  current_size_in_bytes = malloc(4);
  max_image_size = power(2, _infbitlength_); /* 1 more than allowable size */

  if ((heapsize_in_bytes + current_size_in_bytes) >= max_image_size) {
    heapsize_in_bytes = max_image_size - current_size_in_bytes;
    total = heapsize_in_bytes + bpssize;
    printf("Size requested will result in pointer values larger than\n");
    printf(" PSL items can handle. Will allocate maximum size instead.\n\n");
  }

  heapsize =(heapsize_in_bytes / 4) * 4;  /* insure full words */

  heappercent = ((float) (total - bpssize) / total) * 100.0;
  bpspercent  = ((float) bpssize / total) * 100.0;

  if (imagefile == NULL)
  { printf("Setting heap limit as follows:\n");
    printf("Total heap & bps space = %d (%X), bps = %.2f, heap = %.2f\n",
	  total, total, bpspercent, heappercent);
  }

  setupbps();
  getheap(heapsize,feder);

  if (imagefile == NULL)
  printf("bpssize = %d (%X), heapsize = %d (%X)\n",
	  bpssize, bpssize,
	  heapsize, heapsize);

   if (imagefile != NULL) {
	ohl = oldheaplowerbound; ohub = oldheapupperbound;
	ohl =  oldheaplast; ohtb = oldheaptrapbound;
	hlb = heaplowerbound; hub = heapupperbound;
	hl =  heaplast; htb = heaptrapbound;
    /* save the new values around restore of the old ones */

     { 
       char tempname[200]; 
       char *s1; char*s2;
       s2 = tempname;
       if (envname)
       { 
	 s1 = (char*) getenv(envname);
	 if(!s1) {
		  printf("variable %s not set\n",envname);
		  exit(-1);
		 }
	 while(*s1) *s2++ = *s1++; 
	 *s2++  = '\\';
       }

       s1 = imagefile;
       while(*s1) *s2++ = *s1++;
       *s2 = 0;
     
       printf("Loading image file :%s \n",tempname); 
       imago = fopen (tempname,"rb");
       if (imago == NULL) { perror ("error"); exit (-1); }
     }  
       fread (headerword,4,8,imago);

      if (strcmp(headerword,datetag()))
		{ printf(" Cannot start the image with this bpsl \n");
		  exit (-19); }

       fread (headerword,4,7,imago);
       i = fread (SYMNAM,1,headerword[0],imago);
  
       /* printf (" heaplowerbound = %x (new) %x (file)\n", heaplowerbound,
			headerword[6]); */
	if(   
	       /* headerword[6] > heaplowerbound + feder/2 ||  */
	   
	   headerword[6] < heaplowerbound - feder/2) 
	{
		printf (" Cant relocate the image"); 
		printf (" heaplowerbound = %x (new) %x (file)\n", 
			  heaplowerbound, headerword[6]); 
		exit (-3); 
	}
       feder = heaplowerbound - headerword[6];
       { int l1,l2,l3,l4;
	     l1 = fread ((char*)headerword[6],1,headerword[1],imago);
	     l2 = fread ((char*)HASHTABLE,1,headerword[2],imago);
	     l3 = fread ((char*)bpslowerbound,1,headerword[3],imago);
	     l4 = fread ((char*)headerword[4],1,headerword[5],imago);
	     if(l1 != headerword[1] || l2 != headerword[2] ||
		l3 != headerword[3] || l4 != headerword[5])
	       {printf("*** Image file damaged %x %x %x %x\n",l1,l2,l3,l4);
		exit(3);
	       };
       }
       mainstartinitialize = 1;
       fclose (imago);
       if (memset) {
	oldheaplowerbound = ohl; oldheapupperbound = ohub;
	oldheaplast = ohl; oldheaptrapbound = ohtb;
	heaplowerbound = hlb; heapupperbound = hub;
	heaptrapbound = htb;}
       return (4711);
     }
return (0);

}
/* The current procedure is to convert the starting address of the char
   array defined in bps.c to an address and store it in nextbps. A check
   is made to make sure that nextbps falls on an even word boundry.
 */
setupbps()
{
  nextbps  =  ((int)bps + 3) & ~3;        /* Up to a multiple of 4. */
  bpslowerbound = nextbps;
  lastbps  =  ((int)bps + BPSSIZE) & ~3;    /* Down to a multiple of 4. */
}


/* Allocate alternate bps space. Note: The use of sbrk(), and the fact that
   nextbps is now greater than heaplast means that unexec should be not be
   tried after this routine is called. The image would be huge.
 */
allocatemorebps()
{
  return(-1);   /* This will be a paramter later */
}


/* tag( getheap )
 */
getheap(int heapsize,int feder)
{
  int s,i; char * c;
  
  s = heapsize+feder;
  heaplowerbound        = (int)malloc(s); 
  
  if (heaplowerbound <= 0) 
  {
    perror("GETHEAP");
    exit(-1);
  }
  heapupperbound       += feder /2;
  heapupperbound        = heaplowerbound + heapsize;
  heaplast              = heaplowerbound;
  heaptrapbound         = heapupperbound -120;


  oldheaplowerbound     = 0;
  oldheapupperbound     = 0;
  oldheaplast           = 0;
  oldheaptrapbound      = 0;
  oldbreakvalue = (int)sbrk(0);
}

/* Tag( alterheapsize )
 */
alterheapsize(increment)
int increment;
{
  return(-1);

}

unexec()
{
  return(bpssize);
}

