/*
 * file-status.c - PSL Packaging for the Unix "stat" system call.
 *
 * Author:    Russell D. Fish
 *         Computer Science Dept.
 *         University of Utah
 * Date:    Wed Nov 23 1983
 */
 
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
 
 
/* Tag( get_file_status )
 */
int                     /* Returns "stat" value, 0 == success. */
get_file_status( int file_name_string, int info_block, int do_strings )
{
}
 
 
