char * datetag ()
  { return(
"Wed 21-10-1992 11:27:49"
   ) ; }

