/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         bpsheap.c
% Description:  Code to dynamically set up bps and heap structures
% Author:       RAM, HP/FSD
% Created:      9-Mar-84
% Modified:     
% Mode:         Text
% Package:      
%
% (c) Copyright 1987, University of Utah, all rights reserved.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
% 11-Aug-88 (Julian Padget)
%  Added initialization of BPSLOWERBOUND in setupbps().
% 07-Apr-87 (Harold Carr & Leigh Stoller)
%  Put in error checking to ensure that the memory pointers will fit in
%   info field of the lisp item.
% 21-Dec-86 (Leigh Stoller)
%  Added allocatemorebps function, called from try-other-bps-spaces in
%   allocators.sl. 
% 18-Dec-86 (Leigh Stoller)
%  Changed to newer model. Bps is now defined in bps.c so that unexec can
%  alter the text/data boundry. Took out code that allowed command line
%  modification of bpssize. (Now set in the Makefile). Added setupbps()
%  that initialzes NEXTBPS and LASTBPS.
% 20-Sep-86 (Leigh Stoller)
%  Removed assembler alias statements because they are not portable. Instead,
%  a sed script will be used to convert the _variables of C to VARIABLES of
%  PSL.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

#include <stdio.h>

/* Use 1 if using compacting collector ($pxnk/compact-gc.sl).
   Use 2 if using copying collector ($pnk/copying-gc.sl).
   Be sure to update $pxnk/load-psl.sl to include correct collector. */

#define NUMBEROFHEAPS 2         

#define MINSIZE        6000000  /* Default total in number of bytes. */
#define MALLOCSIZE     54096     /* Default size for OS support functions. */
#define EXTRABPSSIZE   100000   /* Minimum amount to increase bps by. */
#define MINIMUMHEAPADD 20000    /* Minimum amount to increase heap by */


#ifndef BPSSIZE
#define BPSSIZE	      800000    /* Default bps size in number of bytes */
#endif

int     alreadysetupbpsandheap;
char *  imagefile ;
int     max_image_size;
int 	oldbreakvalue;

extern int  HASHTABLE;
extern char bps[];
extern int  LASTBPS;
extern int  NEXTBPS;
extern int  BPSLOWERBOUND;
extern int  _INFBITLENGTH_;

extern int  HEAPLOWERBOUND;
extern int  HEAPUPPERBOUND;
extern int  HEAPLAST;
extern int  HEAPTRAPBOUND;

extern int  OLDHEAPLOWERBOUND;
extern int  OLDHEAPUPPERBOUND;
extern int  OLDHEAPLAST;
extern int  OLDHEAPTRAPBOUND;

extern int  SYMVAL;

/* Write this ourselves to keep from including half the math library */
static power(x, n)
     int x, n;
{
  int i, p;

  p = 1;
  for (i = 1; i <= n; ++i)
    p = p * x;
  return(p);
}

setupbpsandheap(argc,argv)
     int argc;
     char *argv[];
{ int ohl,ohtb,ohlb,ohub,hl,htb,hlb,hub;
  int memset = 0; int feder = 200000;
  FILE * imago;
  int headerword [8];
  int    i, total, bpssize, heapsize, mallocsize;
  int    current_size_in_bytes, heapsize_in_bytes;
  double bpspercent, heappercent;
  char   *argp, *scanptr, *scanformat;

  if (alreadysetupbpsandheap)   /* If this session was dumplisped ... */
    { printf("return of cahceflush %x %x is :%d \n",
	4* (BPSLOWERBOUND & -4096) ,
        BPSSIZE+4096,
	cacheflush (4* (BPSLOWERBOUND & -4096) ,
        BPSSIZE+4096,3));
      return 0;
    }

  total		= MINSIZE;
  mallocsize	= MALLOCSIZE;
  
  for (i=1; i<argc-1; i++)
    {
      argp = argv[i];
      if (*argp++ == '-')
        {
          scanformat = "";
          switch (*argp++) {
            case 't': scanptr = (char *)&total;
                      switch (*argp) {
		        case 'x': scanformat = "%x";
			          break;
                        case 'd': scanformat = "%d";
                                  break;
		      }
                      break;
            case 'm': scanptr = (char *)&mallocsize;
                      switch (*argp) {
                        case 'x': scanformat = "%x";
                                  break;
                        case 'd': scanformat = "%d";
                                  break;
                      }
                      break;
           case 'f': imagefile = argv[i+1]; break;
           case 'g': scanptr = (char *)&feder;
                     scanformat = "%d"; break;
          }
          if (*scanformat != 0)
            sscanf(argv[i+1],scanformat,scanptr);
        }
    }   /* end of for loop -- arg vector searched */

  /* insure valid values */
  if (total == 0)
    total = MINSIZE;

  if (mallocsize <= 0)
    mallocsize = MALLOCSIZE;

  /* Reserve some space for C's usr of io buffers, etc. By mallocing then
     freeing, the memory is sbrk'ed onto the image, but available for future
     calls to malloc, which will not need to call sbrk again. */
  free(malloc(mallocsize));	

  bpssize = BPSSIZE;

  heapsize_in_bytes = total - bpssize;

  /* On systems in which the image does not start at address 0, this won't
     really allocate the full maximum, but close enough. */
  current_size_in_bytes = ((int) sbrk(0) >> 2);
  max_image_size = power(2, _INFBITLENGTH_); /* 1 more than allowable size */
  
  if ((heapsize_in_bytes + current_size_in_bytes) >= max_image_size) {
    heapsize_in_bytes = max_image_size - current_size_in_bytes;
    total = heapsize_in_bytes + bpssize;
    printf("Size requested will result in pointer values larger than\n");
    printf(" PSL items can handle. Will allocate maximum size instead.\n\n");
  }

#if (NUMBEROFHEAPS == 2)
  heapsize =(heapsize_in_bytes / 4) * 2;  /* insure full words */
#else
  heapsize =(heapsize_in_bytes / 4) * 4;  /* insure full words */
#endif

  heappercent = ((float) (total - bpssize) / total) * 100.0;
  bpspercent  = ((float) bpssize / total) * 100.0;

  if (imagefile == NULL)
  { printf("Setting heap limit as follows:\n");
    printf("Total heap & bps space = %d (%X), bps = %.2f, heap = %.2f\n",
          total, total, bpspercent, heappercent);
  }

  setupbps();
  getheap(heapsize);

  if (imagefile == NULL) printf(
     "bpssize = %d (%X), heapsize = %d (%X)\nTotal image size = %d (%X)\n",
        bpssize, bpssize, heapsize, heapsize,
        ((int) sbrk(0 >>2)), ((int) sbrk(0)>>2));

   if (imagefile != NULL) {
        ohl = OLDHEAPLOWERBOUND; ohub = OLDHEAPUPPERBOUND;
        ohl = OLDHEAPLAST;    ohtb = OLDHEAPTRAPBOUND;
        hlb = HEAPLOWERBOUND; hub = HEAPUPPERBOUND;
        hl  = HEAPLAST;       htb = HEAPTRAPBOUND;
    /* save the new values around restore of the old ones */

       printf("Loading image file: %s \n",imagefile);
       imago = fopen (imagefile,"r");
       if (imago == NULL) { perror ("error"); exit (-1); }
       fread ((void *) headerword,4,8,imago);

       if (strcmp(headerword,datetag()))
                { printf(" Cannot start the image with this bpsl \n");
                  exit (-19); }

       fread ((void *) headerword,4,7,imago);
       fread ((void *) &SYMVAL,1,headerword[0],imago);
       /* printf (" HEAPLOWERBOUND = %x (new) %x (file)\n" HEAPLOWERBOUND,
                        headerword[6]); */
        if(headerword[6] > HEAPLOWERBOUND + feder/2) {
                printf (" Cant relocate the image"); exit (-3); }
        if(headerword[6] < HEAPLOWERBOUND - feder/2) {
                printf (" Cant relocate the image"); exit (-3); }
       feder = HEAPLOWERBOUND - headerword[6];
       fread ((void *) (4 * headerword[6]),1,4 * headerword[1],imago);
       fread ((void *) &HASHTABLE,1,headerword[2],imago);
       fread ((void *) (4 * BPSLOWERBOUND),1,4 * headerword[3],imago);
       fread ((void *) ( 4 *headerword[4]),1,4 * headerword[5],imago);
       fclose (imago);
       if (memset) {
           OLDHEAPLOWERBOUND = ohl -feder;
           OLDHEAPUPPERBOUND = ohub -feder;
           OLDHEAPLAST  =  ohl -feder;
           OLDHEAPTRAPBOUND = ohtb -feder;
           HEAPUPPERBOUND = hub -feder;
           HEAPTRAPBOUND = htb -feder; }
       return (4711);
     }

}


/* The current procedure is to convert the starting address of the char
   array defined in bps.c to an address and store it in NEXTBPS. A check
   is made to make sure that NEXTBPS falls on an even word boundry.
 */
setupbps()
{
  NEXTBPS  =  ((int)bps >>2);		/* Up to a multiple of 4. */
  BPSLOWERBOUND = NEXTBPS;
  LASTBPS  =  ((int)bps + BPSSIZE)  >>2;	/* Down to a multiple of 4. */
}  


/* Allocate alternate bps space. Note: The use of sbrk(), and the fact that
   NEXTBPS is now greater than HEAPLAST means that unexec should be not be
   tried after this routine is called. The image would be huge.
 */
allocatemorebps()
{
  int current_size_in_bytes;
  int old_NEXTBPS = NEXTBPS;
  
  current_size_in_bytes = ((int) sbrk(0) >>2);

  if ((current_size_in_bytes + EXTRABPSSIZE) >= max_image_size)
    return(0);

/*  if (((int)sbrk(0)) % 2)      /* force to even word boundary
     NEXTBPS = (int)sbrk(1);
 
*/
  NEXTBPS = (int)sbrk(EXTRABPSSIZE);   /* allocate extra BPS */
  if (NEXTBPS == -1) {
    NEXTBPS = old_NEXTBPS;
    return(0);
  }
  LASTBPS = NEXTBPS + EXTRABPSSIZE >>2;

  return(EXTRABPSSIZE);   /* This will be a paramter later */
}
 
  
/* tag( getheap )
 */
getheap(heapsize)
     int heapsize;
{

#if (NUMBEROFHEAPS == 1)
  int gcarraysize;

  gcarraysize = (int)(((heapsize / 9) / 4) * 4);
  heapsize -= gcarraysize;
 
  HEAPLOWERBOUND        = (int)sbrk(heapsize);  /* allocate first heap */;
#else

  HEAPLOWERBOUND        = (int)sbrk(2 * heapsize);  /* allocate first heap */;
  HEAPLOWERBOUND        = HEAPLOWERBOUND >>2;
#endif
  if (HEAPLOWERBOUND == -1) {
    perror("GETHEAP");
    exit(-1);
  }
  HEAPUPPERBOUND        = HEAPLOWERBOUND + (heapsize >>2);
  HEAPLAST              = HEAPLOWERBOUND;
  HEAPTRAPBOUND         = HEAPUPPERBOUND -30;

#if (NUMBEROFHEAPS == 1)
  gcarraylowerbound     = (int)sbrk(gcarraysize);       /* allocate gcarray */
  if (gcarraylowerbound == -1) {
    perror("GETHEAP");
    exit(-1);
  }
#endif

#if (NUMBEROFHEAPS == 2)

  OLDHEAPLOWERBOUND	= HEAPUPPERBOUND;
  OLDHEAPUPPERBOUND     = OLDHEAPLOWERBOUND + (heapsize >>2);
  OLDHEAPLAST           = OLDHEAPLOWERBOUND;
  OLDHEAPTRAPBOUND      = OLDHEAPUPPERBOUND -30;
#endif
  oldbreakvalue = (int)sbrk(0);
}

/* Tag( alterheapsize )
 */
alterheapsize(increment)
int increment;
{
/*
  alters the size of the heap by the specified increment.  Returns
  the increment if successful, otherwise returns 0.  May fail if
  the sbrk is unsuccessful or if the user tries to cut the heap back
  to nothing or the current break value does not match the old value.
  The latter case occurs when a malloc or sbrk has allocated space for
  some other software, in which case we cannot allocate any more space
  contiguously.

  Modifies both the heap and gcarray size.
  NOTE: a garbage collection should probably be performed before this
	routine is called.
  NOTE: only implemented for the one heap version on the 68000.
*/

  int heapsize;
  int current_size_in_bytes;
  
#if (NUMBEROFHEAPS == 1)
  int gcarraysize, newbreakvalue;

  if ((int) sbrk(0) != oldbreakvalue)  /* Non contiguous memory */
      return(0);

  newbreakvalue = oldbreakvalue + increment;

  /* don't let the user cut his heap back to nothing, taking into account
     space for the gcarray. */
  if ((increment < 0) &&
      ((newbreakvalue - HEAPLOWERBOUND) <
       (((HEAPLAST + MINIMUMHEAPADD - HEAPLOWERBOUND) * 9) / 8)))
    return(0);

  current_size_in_bytes = sbrk(0);

  if ((current_size_in_bytes +  increment) >= max_image_size)
    return(0);

  if ((int)sbrk(increment) == -1) 	/* the sbrk failed. */
     return(0);

  newbreakvalue = (int) sbrk(0);
  heapsize = (((newbreakvalue - HEAPLOWERBOUND) / 4) * 4);

  gcarraysize = (((heapsize / 9) / 4) * 4);
  heapsize = heapsize - gcarraysize;

  HEAPUPPERBOUND = HEAPLOWERBOUND + heapsize;
  HEAPTRAPBOUND	 = HEAPUPPERBOUND;

  gcarraylowerbound = HEAPUPPERBOUND; /* allocate gcarray */

  oldbreakvalue	= newbreakvalue;
  return(increment);
#else
  /* assumes the current heap is the 'lower' one */
  int newbreakvalue;
 
  if ((int) sbrk(0) != oldbreakvalue)  /* Non contiguous memory */
      return(0);
 
  current_size_in_bytes = sbrk(0);
 
  if ((current_size_in_bytes + 8* increment) >= (max_image_size << 2))
    return(-1);
 
  if ((int)sbrk(8 * increment) == -1)       /* the sbrk failed. */
     return(-2);
 
  newbreakvalue = (int) sbrk(0);
  increment= (increment / 4) * 4;
 
  HEAPUPPERBOUND	= HEAPUPPERBOUND + increment ;
  HEAPTRAPBOUND 	= HEAPUPPERBOUND - 30;
  OLDHEAPLOWERBOUND     = OLDHEAPLOWERBOUND + increment;
  OLDHEAPUPPERBOUND     = OLDHEAPUPPERBOUND + 2* increment ;
  OLDHEAPLAST           = OLDHEAPLOWERBOUND;
  OLDHEAPTRAPBOUND      = OLDHEAPUPPERBOUND -30;

 
  oldbreakvalue = newbreakvalue;
  return(increment);
#endif

}
unexec ()
  { return (BPSSIZE/4); }

