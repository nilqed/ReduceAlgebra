char * datetag ()
  { return ( 
" Thu Oct 5 18:31:20 1995 "
           ); } 
