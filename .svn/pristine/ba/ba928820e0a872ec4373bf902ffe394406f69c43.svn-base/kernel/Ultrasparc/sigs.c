/* 
 * sigs.c - External routines to deal with signals
 * 
 * Author:	Leigh Stoller
 * 		Computer Science Dept.
 * 		University of Utah
 * Date:	18-Aug-1986
 * 
 */

#include <signal.h>

/* Tag( psl_sigset )
 */
/* psl_sigset( sig, action ) renamed
void (*action)();
int sig;
{
  if (signal(sig, SIG_IGN) != SIG_IGN)
    signal(sig, action);

}
*/
psl_sigset (sig,action)
void (*action)();
int sig;
{
  if (signal(sig, SIG_IGN) != SIG_IGN)
    signal(sig, action);
  }


/* Tag( sigrelse )
 */
sigrelse(sig, action)
void (*action)();
int sig;
{
  /* For bsd */

  /* For system V */
  /*  signal(sig, action); */
}
