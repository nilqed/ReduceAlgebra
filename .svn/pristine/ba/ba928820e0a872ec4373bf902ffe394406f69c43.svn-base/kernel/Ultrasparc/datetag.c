char * datetag ()
  { return ( 
" Thu Aug 19 13:46:26 DST "
           ); } 
