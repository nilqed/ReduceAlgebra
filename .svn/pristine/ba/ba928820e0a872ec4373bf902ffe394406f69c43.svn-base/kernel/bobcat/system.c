/* 
 * system.c -   A more efficient version of the system function.
 * 
 * Author:	Leigh Stoller
 * 		Computer Science Dept.
 * 		University of Utah
 * Date:	31-Aug-1987
 * 
 */

/* This code comes from Berkeley Unix 4.3 sources. It is a rather important
   addition, since it uses vfork instead of fork, and allows a user to use
   system efficiently. Otherwise, system would try to swap in many megabytes
   of swap just to run the shell. The copyright notice that follows is
   to let people know that this code really is not our own.

   Copyright (c) 1980 Regents of the University of California. All rights 
   reserved.
 */

#include	<signal.h>

system(s)
char *s;
{
	int status, pid, w;
	register int (*istat)(), (*qstat)();

	if ((pid = vfork()) == 0) {
		execl("/bin/sh", "sh", "-c", s, 0);
		_exit(127);
	}
	istat = signal(SIGINT, SIG_IGN);
	qstat = signal(SIGQUIT, SIG_IGN);
	while ((w = wait(&status)) != pid && w != -1)
		;
	if (w == -1)
		status = -1;
	signal(SIGINT, istat);
	signal(SIGQUIT, qstat);
	return(status);
}

ccachectl ()
 { return (0);}

