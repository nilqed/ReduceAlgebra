/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         PXCC:ECHO.C
% Description:  Handle raw/cooked terminal I/O, get homedir info
% Author:       
% Created:      9-Mar-84
% Modified:     10-Dec-84 (Bill Williams)
% Mode:         Text
% Package:      
% Status:       Experimental (Do Not Distribute)
%
% (c) Copyright 1984, Hewlett-Packard Company, all rights reserved.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
% 10-Dec-84 (Bill Williams)
%  Changed to be compatable with both 2.0 and 2.1 w.r.t. #include files
%  tty.h and stdio.h by incorporating only needed declarations from stdio.
%  This enabled not including stdio.h.
%  Also Cleaned up by deleting lines that were commented out from history.
%  corrected line in procedure "echoff" by deleting oring of TAB3.
% 7-Nov-84 (Dave Bristor)
%  Changed call to ptrace in read_user_structure to use nlist (because ptrace,
%  with argument 10, is (1) not documented, (2) gator specific).
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

#include <sys/param.h>
#include <sys/dir.h>
#include <sys/signal.h>    /* LBS MOD */
#include <termio.h>        /* LBS MOD */
#include <sys/user.h>  
#include <sys/tty.h>
#include <pwd.h>
#include <stdio.h>
#include <fcntl.h>

extern int errno;

#define INPUT 0
#define E_ACCESS_KMEM 3

int 
        kmem,           /* file id for /dev/kmem for reading user struct*/
	userstructaddr,
	ttystructaddr,
        echo_modes_saved;
struct termio 
        echo_raw_termio,
        echo_save_termio;

/* Tag( Echooff )
 * Go into raw mode
 */
echooff()
{ 
  if (! echo_modes_saved)
    {
      echo_modes_saved++;
      ioctl(INPUT,TCGETA,&echo_save_termio);
      echo_raw_termio = echo_save_termio;
      echo_raw_termio.c_lflag &= ~(ICANON | ECHO );
	/* Terminal interrupt on <cntl-_>, enters breakloop. */
      echo_raw_termio.c_cc[0] = '_'-64;
      echo_raw_termio.c_cc[VQUIT] = -1; /* no quit char while echo off */

      echo_raw_termio.c_cc[VMIN] = 1;   /* read at least one character */
      echo_raw_termio.c_cc[VTIME] = 0;  /* timeout in seconds/10, 0=infinite*/

      echo_raw_termio.c_iflag &= ~IXON; 
      echo_raw_termio.c_iflag |= IXOFF; 
      echo_raw_termio.c_iflag &= ~ICRNL; 
    }
  ioctl(INPUT,TCSETA,&echo_raw_termio);
  fflush(stdout);
}
	
/* Tag( Echoon )
 * Go to cooked mode
 */
echoon()
{ 
  ioctl(INPUT,TCSETA,&echo_save_termio);
  fflush(stdout);
}

/* Tag( external_charsininputbuffer )
 */
external_charsininputbuffer(fp)
FILE *fp;
{
  int numqchars;

  numqchars = charsinttydriver();
  if (numqchars < 0) {
    printf("Error in charsininputbuffer\n");
  }
  return (
          fp->_cnt +            /* chars already in buffer */
          numqchars             /* chars waiting in tty driver */
          );
}

/* Tag( charsinttydriver )
 * this routine simulates ioctl(0,FIONREAD,&cnt) on VAX Berkeley version
 */
charsinttydriver()
{
  extern int kmem;
  extern int userstructaddr;
  extern int ttystructaddr;
  struct short_tty 
         { struct clist t_rawq;
           struct clist t_canq;
  } mytty;
  
  lseek(kmem,ttystructaddr,0);
  if (read(kmem,&mytty,sizeof(struct short_tty)) < 0)
	return E_ACCESS_KMEM;

  return (mytty.t_rawq.c_cc + mytty.t_canq.c_cc);
}

/* Tag( flushstdoutputbuffer )
 */
flushstdoutputbuffer()
{
  fflush(stdout);
}

int             getuid();
struct passwd   *getpwuid(), *getpwnam();

char *external_user_homedir_string()
{
  struct passwd *ptr;
  
  if ((ptr = getpwuid(getuid())) != NULL)
    return(ptr->pw_dir);
  else {
    fprintf(stderr, "Error in external_user_homedir_string()\n");
    return ("");
  }
}

char *external_anyuser_homedir_string(username)
char *username;
{
  struct passwd *ptr;
  if (ptr = getpwnam(username))
    return(ptr -> pw_dir);
  else 
    return "";
}

/* Tag( is_tty_ready )
 */
is_tty_ready()
{
	int oldflags, result, c;

	oldflags = fcntl(INPUT,F_GETFL,oldflags);
	if (oldflags == -1)
		return (-1);

	if ((fcntl(INPUT,F_SETFL,oldflags | O_NDELAY) == -1)
		&& (errno != 22)) { 
		errno=0;
		return (-2);
		}

	c = fgetc(stdin);
	if (c == EOF)
	{	clearerr(stdin);
		result = 0;
	}
	else
	{	ungetc(c,stdin);
		result = 1;
	}

	if ((fcntl(INPUT,F_SETFL,oldflags) == -1)
		&& (errno != 22)) {
		errno=0;
		result = -3;
		}

	return(result);
}
