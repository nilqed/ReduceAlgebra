/*
*******************************************************************************
*
* File:         unexec.c
* SCCS:		@(#) $clb/pslroot/kernel/hpux/non-lisp/hpux200/unexec.c 3.4@(#) 3/10/86 17:21:19
* Description:  Support for dumplisp
* Author:       RAM, HP/FSD
* Created:	31-Jan-85
* Modified:	10-Mar-86 12:12:51 (RAM)
* Mode:         Text
* Package:      
* Status:       Experimental (Do Not Distribute)
*
* (c) Copyright 1984, Hewlett-Packard Company, all rights reserved.
*
********************************************************************************
*
* Revisions:
*
* 28-Oct-91 (Winfried Neun)
* small (name) changes to reflect changes in HP-UX 7.x -> 8.0
* 10-Mar-86 12:12:17 (RAM)
*  Remove dependence on kernel structure (user).
* 17-Oct-85 16:43:01 (RAM)
*  Removed call to expand_file_name.
* 9-Aug-85 13:36:17 (RAM)
*  Modified to handle "demand load" format files.
*
********************************************************************************
*/

#ifdef NO_ZWRITE
    /* "zwrite" saves disk space by seeking over zero blocks.  There are
     * currently megabytes of space in the middle of a PSL executable.
     * Revert to the usual file writing fns if zwrite is configured out.
     */
#   define zwrite write
#   define zclose close
#   define zlseek lseek
#endif not ZWRITE

#include <fcntl.h>
#include <a.out.h>

#define DAT_RND(addr) ((addr) & ~(EXEC_PAGESIZE-1)) /* Down to page boundary.*/

#define STEXT(hdr)	((hdr)->a_magic.file_type == DEMAND_MAGIC ? \
			 EXEC_ALIGN(sizeof(hdr)) : sizeof(hdr))

#define SDATA(hdr) 	(sizeof(hdr) + (hdr)->a_text)

#define HEADER_OFFSET(hdr)	0
#define SYMBUFFERSIZE		0x2000	/* Size of buffer for copying symbol 
                                           table from old a.out file to new. */

/* Possible return values for unexec() and their meanings :             */
#define NO_ERROR                0       /* No error.                    */
#define ANY_ERROR               -1      /* Any error.                   */
#define E_CREATE_NEW_FILE       1       /* Failed to create new file.   */
#define E_OPEN_OLD_FILE         2       /* Failed to open old file.     */
#define E_ACCESS_KMEM           3       /* Failed to read user structure 
                                           from /dev/kmem.              */
#define E_READ_OLD_HEADER       4       /* Failed to read old header.   */
#define E_WRITE_HEADER          5       /* Failed to write header.      */
#define E_WRITE_TEXT            6       /* Failed to write text.        */
#define E_WRITE_DATA            7       /* Failed to write data.        */
#define E_COPY_SYMS             8       /* Failed to copy symbol table. */
#define E_BAD_MAGIC_NUMBER      9       /* Old file had bad magic number.*/
#define E_BAD_NEW_CLOSE         10      /* Failed to close the new file.*/

extern char etext;

extern oldbreakvalue;	/*end of data space after last sbrk, from bpsheap.c */

static long tsegstart;       /* Start address of text segment.      */
static long dsegstart;       /* Start address of data segment.      */

/* Tag( unexec )
 */
unexec(n_name,o_name,dstart,bstart)
char *n_name, *o_name, *dstart, *bstart;

/* Create an a.out format file from current process image.  
   N_name is the name of the new a.out format file to create.
   o_name is the name of an a.out format file from which to extract symbol table
   information to put in the new a.out file.  If this is null (0), no attempt
   to copy the symbol table is made.
   Dstart is used to determine the end of the text segment in un-shared text
   programs.
   Bstart is used to determine the end of the initialized data segment. 
*/

{
	int new_file, a_file, result;
	struct exec new_hdr, a_hdr;
	char new_name[256], a_name[256];

#	ifndef NO_ZWRITE
	zinit();
#	endif

	/* Expand both filenames now. Place in seperate static arrays so that
	   mallocs are not needed at runtime. Messes up the unexec by
	   changing the oldbreakvalue.
	 */
	strcpy(new_name, expand_file_name(n_name));
	if (o_name)
	  strcpy(a_name, expand_file_name(o_name));

	/*
	** Call setup_new_header.
	** If no error then call write_new_file.
	** Save result.
	*/

	result = setup_new_header(&new_hdr,&a_hdr,&a_file,a_name,dstart,bstart);

	if (result == 0)
		result = (write_new_file(new_name,&new_file,&new_hdr,a_file,&a_hdr));

	/*
	** Close any open files.
	** Return the appropriate (saved above) result.
	*/

	if (a_file >= 0)
		close(a_file);
	if (new_file >= 0)
		zclose(new_file);

	return(result);
}

setup_new_header(new_hdr,old_hdr,old_file,old_name,dstart,bstart)
struct exec *new_hdr;   /* The new a.out header to be setup.            */
struct exec *old_hdr;   /* The a.out header of the old file.            */
int *old_file;          /* The file descriptor of the old a.out file.   */
char *old_name;         /* The name of the old a.out file.              */
long dstart, bstart;    /* Really addresses, but easier to use as longs.*/
{

	struct user *us;      /* pointer to user structure. */

	/* 
	** If no name supplied then
	** don't worry about opening it. 
	*/

	if (*old_name == 0)
		*old_file = -1;

	else if ((*old_file = open(old_name,O_RDONLY)) < 0)
		return(E_OPEN_OLD_FILE);

	else {
		/* 
		** Read a.out header
		*/

		if (read_with_checks(*old_file, HEADER_OFFSET(*old_hdr),
			old_hdr, sizeof(struct exec)))
			return(E_READ_OLD_HEADER);

		/*
		** Check magic number
		*/

		if (N_BADMAG(*old_hdr))
			return(E_BAD_MAGIC_NUMBER);
	}

	/* 
	** Create a new a.out header.
	** Use some defaults if can't find old file, or no old file given.
	** The defaults may easily be wrong, so the resulting file will not
	** be valid, but if you have to guess, what else can you do?
	** For that matter, the name given for the old file may not actually
	** be the old file, in which case there are more chances for error.
	*/

	new_hdr->a_magic.system_id	= HP9000S200_ID;
	new_hdr->a_magic.file_type	= DEMAND_MAGIC;
	new_hdr->a_stamp		= 0;
	new_hdr->a_highwater		= 0;
	new_hdr->a_miscinfo             = 0;
	new_hdr->a_text			= 0;
	new_hdr->a_data			= 0;
	new_hdr->a_bss			= 0;
	new_hdr->a_trsize		= 0;
	new_hdr->a_drsize		= 0;
	new_hdr->a_pasint		= 0;
	new_hdr->a_lesyms		= 0;
	new_hdr->a_spared  		= 0;
	new_hdr->a_entry		= 0;
	new_hdr->a_spares		= 0;
	new_hdr->a_supsym		= 0;
	new_hdr->a_drelocs		= 0;
	new_hdr->a_extension		= 0;

	/*
	** If old_file was opened then take the magic number and the
	** symbol table information from the old_hdr.
	*/

	if (*old_file >= 0) {
		new_hdr->a_magic = old_hdr->a_magic;
		new_hdr->a_lesyms = old_hdr->a_lesyms;
		}

	/*
	** Adjust text and data.
	**/

	tsegstart = 0;		/* Assumption!! */

	switch(new_hdr->a_magic.file_type) {
	case EXEC_MAGIC:	dsegstart = new_hdr->a_text = (int) &etext;
				new_hdr->a_data = (int) sbrk(0) - dsegstart;
				break;
	case SHARE_MAGIC:	new_hdr->a_text = (int) &etext;
				dsegstart = (((int) &etext + 4095) & ~4095);
				/* Rounding of dsegstart is an assumption!! */
				new_hdr->a_data = (int) sbrk(0) - dsegstart;
				printf("File type is shared text.\n");
				break;
	case DEMAND_MAGIC:	dsegstart = (((int) &etext + 4095) & ~4095);
				/* Rounding of dsegstart is an assumption!! */
				new_hdr->a_text = dsegstart;
				new_hdr->a_data =
				(((int) sbrk(0) + 4095) & ~4095) - dsegstart;
				printf("File type is demand paged.\n");
				break;
	}

	/* Alter the new a.out header to reflect the new data start
	** and bss start.
	*/

	if (bstart && ((int) sbrk(0) == oldbreakvalue)
		   && (bstart > dsegstart)
		   && (bstart <= oldbreakvalue))
	  {
	    bstart = EXEC_ALIGN(bstart);
	    new_hdr->a_data = bstart - new_hdr->a_text;
	    new_hdr->a_bss = (int) sbrk(0) - bstart;
	  }
	else
	  bstart = (int) sbrk(0);

	if (dstart)
	  {
	    dstart = DAT_RND(dstart);
	    new_hdr->a_text = dstart; 
	    new_hdr->a_data = bstart - SDATA(new_hdr);
	    dsegstart = tsegstart + new_hdr->a_text;
	  }

	return(NO_ERROR);
}

write_new_file(name,file,hdr,old_file,old_hdr)
char *name;                     /* Name of the new a.out format file.   */
int *file;                      /* File descriptor of the new file.     */
struct exec *hdr;               /* A.out header for new file.           */
int old_file;                   /* File descriptor of old file, if any. */
struct exec *old_hdr;           /* A.out header of old file, if any.    */
{
	long old_pos,new_pos;    /* Position and buffer variables for use*/
	int size_left,buf_size;  /* in copying the symbol table from     */
	char buf[SYMBUFFERSIZE]; /* old_file to file.                    */
	long txt_offset;
	long data_offset;

	/*
	** Create the new file with rwx modes.
	*/

	if ((*file = creat(name,0777)) < 0)
		return(E_CREATE_NEW_FILE);

	/*
	** Write an a.out header to the 
	** new a.out format file.
	*/

	printf("Writing a.out header of size %lx\n", sizeof(struct exec));
	if (write_with_checks(*file, 0, hdr, sizeof(struct exec)))
		return(E_WRITE_HEADER);


	/*
	** Write a text segment to the
	** new a.out format file.
	*/

	if (hdr->a_text > 0) {
	  txt_offset = TEXT_OFFSET(*hdr);
	  data_offset = DATA_OFFSET(*hdr);
	  
	  printf("Writing Text segment of size %lx at start %lx\n",
		 hdr->a_text, (unsigned long) tsegstart);
	  if (write_with_checks(*file, txt_offset, tsegstart ,hdr->a_text))
	    return(E_WRITE_TEXT);
	}

	/*
	** Write a data segment to the 
	** new a.out format file.
	*/
	if (hdr->a_data > 0) {
	  printf("Writing Data segment of size %lx at start %lx\n",
		 hdr->a_data, (unsigned long) dsegstart);
	  if (write_with_checks(*file, data_offset, dsegstart, hdr->a_data))
			return(E_WRITE_DATA);
	}

	/*
	** Copy symbols from old a.out file
	** (if any) to the new a.out file.
	*/

	if (hdr->a_lesyms > 0) {
		old_pos = LESYM_OFFSET(*old_hdr);
		new_pos = LESYM_OFFSET(*hdr);
		size_left = hdr->a_lesyms;
		buf_size = SYMBUFFERSIZE;
		while (size_left > 0) {
			if (size_left < SYMBUFFERSIZE)
				buf_size = size_left;
			if (read_with_checks(old_file,old_pos,buf,buf_size))
				return(E_COPY_SYMS);
			if (write_with_checks(*file,new_pos,buf,buf_size))
				return(E_COPY_SYMS);
			old_pos = old_pos + buf_size;
			new_pos = new_pos + buf_size;
			size_left = size_left - buf_size;
		}
	}

	/* 
	** Close the new file.
	*/

	if (zclose(*file)) 
		return(E_BAD_NEW_CLOSE);
	else
		return(NO_ERROR);
}

/*
** Seek to pos in file and write size bytes into buf.
** Return 0 if OK, -1 on errors.
*/

write_with_checks(file,pos,buf,size)
int file;
long pos;
char *buf;
long size;
{
	if (zlseek(file,pos,0) < 0)
		return(ANY_ERROR);

	if (zwrite(file,buf,size) != size)
		return(ANY_ERROR);

	return(NO_ERROR);
}

/*
** Seek to pos in file and read size bytes into buf.
** Return 0 if OK, -1 on errors.
*/

read_with_checks(file,pos,buf,size)
int file;
long pos;
char *buf;
long size;
{
	if (lseek(file,pos,0) < 0)
		return(ANY_ERROR);

	if (read(file,buf,size) != size)
		return(ANY_ERROR);

	return(NO_ERROR);
}

#ifndef NO_ZWRITE
#ifndef lint
static char RCSid[] = "$Header: zwrite.c,v 1.5 85/10/06 23:08:27 lepreau Exp $";
#endif
/*
 * zwrite(): like write(2), but creates holes in files if possible.
 * If a write() fails zwrite returns -1 instead of the number of
 * bytes written-- what do you think about this?
 *
 * zlseek(): is like lseek(2), but keeps track of seeks on a file being
 * written by zwrite.
 * 
 * zclose() should be called instead of close() if fd's are to be re-used
 * or if you might have zeroes at the end of the file.  And you should
 * check that zclose returns 0, also!
 *
 * Current `vax' code assumes st_blksize (filesys blksize) is <= 64K;
 * non-vax code not yet tested.
 *
 * Donn Seeley and Jay Lepreau, Univ of Utah, April 1985.
 */

#include <sys/types.h>
#include <sys/param.h>
#include <sys/file.h>

#define min(a,b)	((a) < (b) ? (a) : (b))
typedef int boolean;
#define TRUE 1
#define FALSE 0

struct dtab {
	off_t offset;
	boolean last_seek;		/* Last op was a seek. */
};

static struct dtab dtable[NOFILE] = 0;

/* Unexec has to forget old disktab info, since PSL unexecs repeatedly. */
zinit()
{
	int i;
	for ( i = 0; i < NOFILE; i++ )
	{
		dtable[i].offset = 0;
		dtable[i].last_seek = FALSE;
	}
}

int
zwrite(fd, buf, len)
	int fd;
	register char *buf;		/* known to be r11 on vaxes below */
	int len;
{
	register int count;		/* known to be r10 on vaxes below */
	register int notzero;		/* known to be r9 on vaxes below */
	int savelen = len;
	int need;
#	define obsize 512		/* Iris has fixed blocksize. */
	off_t loc;

	while (len > 0) {
		/* How much do we need to fill out to a block boundary? */
		need = obsize - dtable[fd].offset % obsize;
		count = min( len, need ? need : obsize );
			
		/* Are there any non-zero chars in this block? */
		notzero = 0;
#ifdef vax
		asm("	skpc	$0,r10,(r11)");
		asm("	beql	1f");		/* all zeroes */
		asm("	incl	r9");		/* notzero++ */
		asm("1:");
#else
		{
		register char *p;
		char *endbuf;
		
		p = buf;
		endbuf = buf + count;
		while (p < endbuf)
			if (*p++) {
				notzero++;
				break;
			}
		}
#endif
		if (notzero) {
			if (write(fd, buf, count) != count)
				return -1;
			dtable[fd].last_seek = FALSE;
			dtable[fd].offset += count;
		}
		else {
			if ((loc = lseek(fd, (off_t) count, 1)) < 0)
				return -1;
			dtable[fd].last_seek = TRUE;
			dtable[fd].offset = loc;
		}
		len -= count;
		buf += count;
	}
	return savelen;
}
  

int
zlseek( fd, offset, whence )
int fd, offset, whence;
{
	int loc;

	loc = lseek( fd, offset, whence );

	dtable[fd].last_seek = TRUE;
	dtable[fd].offset = loc;

	return loc;
}

zclose(fd)
{
	int rc = 0;

	/* Can't just seek at end and expect to get anything! */
	if (dtable[fd].last_seek) {
		if (lseek(fd, (off_t) -1, 1) < 0) 
			rc = -1;
		else if (write(fd, "", 1) != 1)
			rc = -1;
	}
	dtable[fd].offset = 0;
	dtable[fd].last_seek = FALSE;

	if (close(fd) < 0)
		return -1;
	else
		return rc;
}
#endif ZWRITE
