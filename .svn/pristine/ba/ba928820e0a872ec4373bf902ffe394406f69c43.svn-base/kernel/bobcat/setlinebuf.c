/*
*******************************************************************************
*
* File:         setlinebuf.c
* Description:  Contains the setlinebuf function
* Author:       Leigh Stoller
* Created:      31-Mar-87
* Modified:     
* Package:      
*
* (c) Copyright 1987, University of Utah, all rights reserved.
*
*******************************************************************************
*
* Revisions:
*
* 31-Mar-87 (Leigh Stoller)
*  Copied from Vax $pxk directory and modified for use on SYS V.
*
*******************************************************************************
*/

#include	<stdio.h>

/*
 * set line buffering for either stdout or stderr
 */
setlinebuf(iop)
	register struct _iobuf *iop;
{
	static char _sebuf[BUFSIZ];
	extern char _sobuf[];
	       char *p;

	if ((int) iop != (int) stdout &&
	    (int) iop != (int) stderr)
		return;

	if ((int) iop == (int) stderr)
	  p = _sebuf;
	else
	  p = _sobuf;
	
	fflush(iop);
	setbuf(iop, NULL);
	setbuf(iop, p);
	setvbuf(iop, p, _IOLBF, BUFSIZ);
}
