
/******************************************************************************
*
* File:         os-hooks.c
* Description:  OS specific startup and cleanup hooks.
* Author:       RAM, HP/FSD
* Created:      9-Mar-84
* Modified:	15-Jul-85 10:10:51 (RAM)
* Mode:         Text
* Package:      
* Status:       Experimental (Do Not Distribute)
*
* (c) Copyright 1984, Hewlett-Packard Company, all rights reserved.
*
******************************************************************************
* Revisions:
*
* 27-Apr-87 (Leigh Stoller)
   Removed io-cards calls since they did not seem to have any effect.
* 31-Mar-87 (Leigh Stoller)
*  Added calls to setlinebuf in os_startup_hook.
* 07-Jul-86 (Leigh Stoller)
*  Removed Calls to echooff and echoon since they are not needed for the top
*   loop, only for Nmode. Who knows why HP was calling them in the first place.
* 30-Apr-86 (Leigh Stoller)
* Copied this file from gator kernel directory and changed calls to terminal-
*  state to echooff and echoon, which are contained in echo.c
* 15-Jul-85 10:09:36 (RAM)
*  Added assembly code for m68020_advise.
* 10-Jul-85 23:09:24 (RAM)
*  Removed call to UNIXINITIO.
* 01-May-85 13:32:55 (Ellen Bierman)
*  Removed call to setup_shells. Moved to Nmode.
* 29-Apr-85 17:17:05 (Ellen Bierman)
*  Replaced call to in_pipes with one to setup_shells; added calls to fix
*  terminal setup and restore problems.  Removed nmodekeys and undokeys.
* 03-Mar-85 10:00:00 (Ellen Bierman)
*  Changed in_pipes to pass argv and argc (for new shell access).
* 15-Nov-84 16:30:00 (RAM)
*  Commented out nmode-keys and undokeys for Windex.
* 02-Nov-84 12:27:21 (RAM)
*  Changed os_startup_hook to call remap_in_all_cards instead of external_mapit.
*  Made os_cleanup_hook call map_out_all_cards.
* 21-Jul-84 20:52:06 (RAM)
*  Added call to undokeys in os_cleanup_hook.
* 29-Jun-84 15:39:44 (RAM)
*  Included argc and argv as parameters.  Things worked before, but it wasn't
*  clean.
* 29-Jun-84 14:12:00 (RAM)
*  Added call to in_pipes for communication with parent process 
*  to call "system".  (Call was in setupbpsandheap, for some reason.)
*
*******************************************************************************
*/

#include <stdio.h>

os_startup_hook(argc, argv)
     int argc;
     char *argv[];
{
  /* Force line buffering in stdout and stderr so output is not bunched. */
  setlinebuf(stdout);
  setlinebuf(stderr);

  setupbpsandheap(argc, argv); /* Allocate bps and heap areas. */

}

os_cleanup_hook()
{

}

/* int m68020_advise(type)
   system call 167
   takes one argument:
     0 -- multiply map segments to effectively ignore upper 4 bits
          of addresses except in stack segment
     1 -- purge instruction cache
     2 -- purge data cache
*/
asm("		      global _m68020_advise"); 	  /* int m68020_advise(type) */
asm("_m68020_advise:  rts"); /*mov.l &167,%d0");	          /* decimal 167 */
asm(" 		      trap &0");		  /* system call */
asm("		      bcc.b _m68020_advise_ok");  /* return if no error */
asm("		      jmp __cerror");
asm("_m68020_advise_ok:	rts");
