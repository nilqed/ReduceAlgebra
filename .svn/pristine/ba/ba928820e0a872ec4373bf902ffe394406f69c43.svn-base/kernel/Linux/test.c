int hugo = 0;
int otto [10];
int klaus[10]={1};

