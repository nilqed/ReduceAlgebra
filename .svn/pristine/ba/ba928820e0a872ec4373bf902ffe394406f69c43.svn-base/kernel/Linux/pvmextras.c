pppvm_spawn(vv)
int * vv;

{ pvm_spawn(vv[0],vv[1],vv[2],vv[3],vv[4],vv[5],vv[6]);}
