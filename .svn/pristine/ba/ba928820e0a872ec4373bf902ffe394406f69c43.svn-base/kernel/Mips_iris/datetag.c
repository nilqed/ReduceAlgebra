char * datetag ()
  { return ( 
" Tue Jul 9 13:58:08 1996 "
           ); } 
