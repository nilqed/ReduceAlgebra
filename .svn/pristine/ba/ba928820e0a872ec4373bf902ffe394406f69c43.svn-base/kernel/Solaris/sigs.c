/* 
 * sigs.c - External routines to deal with signals
 * 
 * Author:	Leigh Stoller
 * 		Computer Science Dept.
 * 		University of Utah
 * Date:	18-Aug-1986
 * 
 */

#include <signal.h>

/* Tag( psl_sigset )
 */
/* psl_sigset( sig, action ) renamed
void (*action)();
int sig;
{
  if (signal(sig, SIG_IGN) != SIG_IGN)
    signal(sig, action);

}
*/
psl_sigset (sig,action)
void (*action)();
int sig;
{
  struct sigvec vec;
  struct sigvec ovec;
 
  vec.sv_handler = action;
  vec.sv_flags   = SV_INTERRUPT;
  vec.sv_mask    = 0;
  sigvec (sig,&vec,&ovec);
  if(ovec.sv_handler == SIG_IGN) sigvec(sig,&ovec,&vec);
  }


/* Tag( sigrelse )
 */
sigrelse(sig, action)
void (*action)();
int sig;
{
  /* For bsd */
  sigsetmask( sigblock(0) & ~ 1<<sig );	 /* Unblock the signal. */

  /* For system V */
  /*  signal(sig, action); */
}
