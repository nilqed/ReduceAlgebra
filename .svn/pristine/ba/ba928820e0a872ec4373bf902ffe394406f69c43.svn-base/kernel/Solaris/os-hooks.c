/******************************************************************************
*
* File:         os-hooks.c
* Description:  OS specific startup and cleanup hooks.
* Author:       RAM, HP/FSD
* Created:      9-Mar-84
* Modified:	15-Jul-85 10:10:51 (RAM)
* Mode:         Text
* Package:      
* Status:       Experimental (Do Not Distribute)
*
* (c) Copyright 1984, Hewlett-Packard Company, all rights reserved.
*
******************************************************************************
* Revisions:
*
* 03-Dec-90 (James Davenport)
*  Added a version of system that uses vfork, since SUNos now uses fork
*  which insists on reserving vast amounts of swap
* 20-Nov-90 (Winfried Neun)
*  fixed exit-with-status mechanism to return the proper status
* 21-Jul-89 (Winfried Neun)
*  Removed init_malloc_param call for dynamic heap expansion model.
* 21-Sep-86 (Leigh Stoller)
*  Removed calls to the io-map functions. None of this was needed for the Sun.
*  Removed the 68020_advise function.
* 07-Jul-86 (Leigh Stoller)
*  Removed Calls to echooff and echoon since they are not needed for the top
*   loop, only for Nmode. Who knows why HP was calling them in the first place.
* 30-Apr-86 (Leigh Stoller)
* Copied this file from gator kernel directory and changed calls to terminal-
*  state to echooff and echoon, which are contained in echo.c
*
*   June 1988,    yamamoto added init-malloc-param() for SUN4 PORT.   
*   June 1988,    yamamoto added _iob[] initializer for SUN4 PORT.   
*   July 19, 1988 yamamoto added _dtabsize initializer for SUN4 PORT.
******************************************************************************
*/
#include <stdio.h>
#include <setjmp.h>

jmp_buf mainenv;

int returval=0;

main(argc,argv,envp)
int argc;
char *argv[];
char *envp[];
{
  int val;
  
  val=setjmp(mainenv);		/* set non-local return point for exit	*/

  if (val == 0)
     psl_main(argc,argv,envp);

exit(returval);

}
  

os_startup_hook(argc, argv)
     int argc;
     char *argv[];
{

  setupbpsandheap(argc, argv);	/* Allocate bps and heap areas. */


}

os_cleanup_hook(retv)
{
returval = retv;
/*longjmp(mainenv,1); */
}

/*	This part is completely SUN4 OS dependent.	*/

/*      First, the new version of system */

#include        <signal.h>

system(s)
char *s;
{
        int status, pid, w;
        void (*istat)(), (*qstat)();

        if ((pid = vfork()) == 0) {
                execl("/bin/sh", "sh", "-c", s, 0);
                _exit(127);
        }
        if (pid == -1)
           return(-1);
        istat = signal(SIGINT, SIG_IGN);
        qstat = signal(SIGQUIT, SIG_IGN);
        while ((w = wait(&status)) != pid && w != -1)
                ;
        if (w == -1)
                status = -1;
        signal(SIGINT, istat);
        signal(SIGQUIT, qstat);
        return(status);
}


/*
 *	Some static area must be initialized on hot start.
 *	There may be other area to be initialized but we have no idea
 *	to know them.
 *
 *	_dtabsize ----_end
 */


extern char *end;
/*
 *	 Size of dtabsize is 0x34c bytes.
 */
clear_dtabsize()
{
 int i;
 bzero((int)(&end)-0x34c, 0x34c);
 }

