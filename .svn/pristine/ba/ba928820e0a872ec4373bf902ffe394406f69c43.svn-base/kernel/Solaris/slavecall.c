/*

  A VERY simple interface to REDUCE

  derived  from the XR interface by Chris Cannam

  Winfried Neun   ZIB

*/

#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define XR_tidy { if (!quietMode) \
		    fprintf(stderr,"XR: Tidying up and leaving.\n"); \
	          fflush(stderr); red_kill(); }

#include <signal.h>

#ifndef PATH_MAX
#define PATH_MAX 512
#endif

/* Exportable variables */

int           reduceProcessID;
int           myProcessID;
int           MeToReduce[2],             /* Sockets for communication    */
              ReduceToMe[2],             /* with Reduce; obtained from   */
              ReduceErrs[2];             /* socketpair(), so check your  */
				         /* implementation!              */
int       waitingToInterleave;       /* if input is in middle of str */
int       quietMode     = 0;

extern int errno;


/* red_warn() Send warning message to stderr, and continue.
*/

void red_warn(msg)
  char *msg;
{
  fprintf(stderr,"\nXR: %s\n",msg);
  fflush(stderr);
}


char *EnsureFilename(ofn)
  char *ofn;
{
  int         i;
  char       *rev;
  char       *nfn;

  nfn = (char *)malloc(strlen(ofn) + 200);

  for (i = 0; ofn[i]; ++i)
    if (!strncmp(ofn + i, "$reduce", 7)) {
      if (i > 0) strncpy(nfn, ofn, i);
      if ((rev = (char *) getenv("reduce")) == (char *) NULL)
	printf("Couldn't get value of environment variable $reduce\n");
      strcpy(nfn + i, rev);
      strcpy(nfn + i + strlen(rev), ofn + i + 7);
      return nfn;
    }

  strcpy(nfn, ofn);

   return nfn;
}

extern char * static_argv[];
extern char ** environ;

int slavecall (op,stri,ch1,ch2)
  int    op;
  char * stri;
  int ch1 , ch2;
{
  char        *redFullName;
  char        red_full_name [PATH_MAX];
  char        red_image_name [PATH_MAX];
  char 	      * newargv [10];

  int          i;
  int          pid;
  int          ppid = getpid();
  int          plen;
  int          nlen,ii;
  int          tempfd;
  char         ch;

  /* The very first thing to do is to get a new process group.  This is */
  /* because when XReduce exits, it tries to kill the whole group; this */
  /* is rather nasty if it's been started from a window manager or stng */

  /* Let us not care about the return value -- it should only ever fail */
  /* if we're already the process group leader, in which case we don't  */
  /* mind, and if something else happens it's not the end of the world: */
  /* this call shouldn't make any difference to anything else anyway.   */

if (op == 1) {
  (void)setsid();

  if (socketpair(AF_UNIX, SOCK_STREAM, 0, MeToReduce) < 0)
    { perror("XR"); printf("Couldn't open socket to Reduce process"); }
  if (socketpair(AF_UNIX, SOCK_STREAM, 0, ReduceToMe) < 0)
    { perror("XR"); printf("Couldn't open socket from Reduce process"); }
/* if (socketpair(AF_UNIX, SOCK_STREAM, 0, ReduceErrs) < 0)
    { perror("XR"); printf("Couldn't open socket for Reduce process"); }
*/


    if (pid = fork()) {

      if (pid < 0) { perror("XR");
		fprintf(stderr,"XR: Could not fork() Reduce process\n");
		exit(-1); }

      reduceProcessID = pid;
          myProcessID = ppid;

#if !defined (HPUX)
      setlinebuf(stdout);
#endif
/*
      setlinebuf(ReduceToMe[0]);
*/


  sleep (2);
  printf(" Process started\n");
  return(pid);
    } else {
      redFullName = EnsureFilename(stri);
      static_argv[0]= redFullName;

      if ((tempfd = open(redFullName, O_RDONLY)) == -1) 

	{fprintf(stderr,"XR: No Reduce binary \"%s\"\n", redFullName);
	if (!quietMode)
	  fprintf(stderr,"XR: Initialisation file is probably wrong\n");
        }

      else close(tempfd);

      close(MeToReduce[1]  );
      dup2 (MeToReduce[0],0);
      close(ReduceToMe[0]  );
      dup2 (ReduceToMe[1],1);

/*
      close(ReduceErrs[0]  );
      dup2 (ReduceErrs[1],2);
*/

/* fprintf(stderr,"red_full_name %s , red_image_name %s \n",red_full_name,red_image_name); */
      execve(redFullName, static_argv , environ);

      fprintf(stderr, "slavecall: Could not execve()\n");
      perror("slavecall"); 
      fflush(stderr);
      sleep(1);
      exit(-1);
    }
}

if (op == 2) {
	 int ncharread;
	 ncharread = read(ReduceToMe[0],stri,ch1); 
         return(ncharread); }

if (op == 3) { ch1 =write(MeToReduce[1],stri,ch1);
               fflush(stdin); fflush (stdout); return(ch1);}
 }

