char * datetag ()
  { return ( 
" Fri Jul 2 16:05:25 DST 2004   "
           ); } 
