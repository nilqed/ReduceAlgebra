/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         ECHO.C
% Description:  Handle raw/cooked terminal I/O, get homedir info
% Author:       Russ Fish
% Created:      2 March 1982
% Modified:     
% Mode:         Text
% Package:      
% Status:       Experimental (Do Not Distribute)
%
% (c) Copyright 1984, Hewlett-Packard Company, all rights reserved.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
% 21-Sep-86 (Leigh Stoller)
%  Copied from Sun kernel 3.2 directory. Changed a few function names to match
%  3.4 conventions, and deleted a few obsolete functions.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

#include <sgtty.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <pwd.h>


int modes_saved;		/* Flag to indicate initial modes saved. */
struct sgttyb sav_ioctlb, ioctlb;	/* TTY mode descriptor for ioctl. */
int sav_lmodeb, lmodeb;			/* Extended mode bits. */
struct tchars sav_tcharsb, tcharsb;	/* Terminal interrupt chars. */
struct ltchars sav_ltcharsb, ltcharsb;	/* Extended terminal chars. */

/* TAG( EchoOff )
 * Enter charcter-at-a-time mode.
 */
echooff()		/* (Note names lowercased by PSL compiler... */
{
    if ( ! modes_saved )
    {
	modes_saved++;
	ioctl (0, TIOCGETP, &sav_ioctlb); ioctlb = sav_ioctlb;
	ioctl (0, TIOCLGET, &sav_lmodeb); lmodeb = sav_lmodeb;
	ioctl (0, TIOCGETC, &sav_tcharsb); tcharsb = sav_tcharsb;
	ioctl (0, TIOCGLTC, &sav_ltcharsb); ltcharsb = sav_ltcharsb;

	ioctlb.sg_flags &= ~(ECHO | CRMOD | XTABS | ANYP);
	ioctlb.sg_flags |= CBREAK;

	lmodeb |= LLITOUT;

	/* Terminal interrupt on ^^, enters breakloop. */
	tcharsb.t_intrc = '^'-64;
	tcharsb.t_quitc = -1;
	tcharsb.t_startc = -1;
	tcharsb.t_stopc = -1;
	tcharsb.t_eofc = -1;
	tcharsb.t_brkc = -1;

	ltcharsb.t_suspc = -1;
	ltcharsb.t_dsuspc = -1;
	ltcharsb.t_rprntc = -1;
	ltcharsb.t_flushc = -1;
	ltcharsb.t_werasc = -1;
	ltcharsb.t_lnextc = -1;
    }
    ioctl (0, TIOCLSET, &lmodeb);
    ioctl (0, TIOCSETP, &ioctlb);	/* Must come AFTER LSET. (Bug.) */
    ioctl (0, TIOCSETC, &tcharsb);
    ioctl (0, TIOCSLTC, &ltcharsb);
}

/* TAG( EchoOn )
 * Re-enter line I/O mode.
 */
echoon()
{
    ioctl (0, TIOCLSET, &sav_lmodeb);
    ioctl (0, TIOCSETP, &sav_ioctlb);	/* Must come AFTER LSET. (Bug.) */
    ioctl (0, TIOCSETC, &sav_tcharsb);
    ioctl (0, TIOCSLTC, &sav_ltcharsb);

    fflush( stdout );
}


/* TAG( External_CharsInInputBuffer )
 *  Return number of characters in input buffer.
 */
external_charsininputbuffer( fp )
FILE * fp;		/* Ptr to stdio file structure for terminal. */
{
    int CharCnt;
    ioctl (0, FIONREAD, &CharCnt);	/* Chars waiting in tty driver. */
    CharCnt += fp->_cnt;		/* Chars already in buffer. */
    return CharCnt;
}
    
/* TAG( FlushStdOutputBuffer )
 *  Clear out buffer, when in EchoOff mode.
 */
flushstdoutputbuffer()
{
    fflush( stdout );
}

int             getuid();
struct passwd   *getpwuid(), *getpwnam();

char *external_user_homedir_string()
{
  struct passwd *ptr;
  
  if ((ptr = getpwuid(getuid())) != NULL)
    return(ptr->pw_dir);
  else {
    fprintf(stderr, "Error in external_user_homedir_string()\n");
    return ("");
  }
}

char *external_anyuser_homedir_string(username)
char *username;
{
  struct passwd *ptr;
  if (ptr = getpwnam(username))
    return(ptr -> pw_dir);
  else 
    return "";
}

