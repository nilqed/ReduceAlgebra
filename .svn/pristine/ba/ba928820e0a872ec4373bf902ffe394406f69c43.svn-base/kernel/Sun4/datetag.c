char * datetag ()
  { return ( 
" Mon Feb 22 11:28:59 1999 "
           ); } 
