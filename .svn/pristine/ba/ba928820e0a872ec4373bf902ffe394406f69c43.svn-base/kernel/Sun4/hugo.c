#include <stdio.h>
#include <signal.h>
#include <floatingpoint.h>

main ()
{ if (ieee_handler("set", "overflow",SIGFPE_ABORT) != 0)
                    printf("ieee_handler can't set overflow \n");
}
