int hugo = 0;
int otto [10];
int klaus[10]={1};

iimain(x,y,z)
int x,y,z;
{ Tk_Main(x,y,z);
  return (0);
}

