char * datetag ()
  { return ( 
" Wed Sep 22 11:54:41 1999 "
           ); } 
