/* 
 * sigs.c - External routines to deal with signals
 * 
 * Author:	Leigh Stoller
 * 		Computer Science Dept.
 * 		University of Utah
 * Date:	18-Aug-1986
 * 
 */

#include <stdio.h>
#include <signal.h>

/* Tag( psl_sigset )
 */
void (*action1)();
int *sigbuffer;

psl_sigset( sig, action,sigbu )
void (*action)();
int sig;
int * sigbu;

{ int sighand();
  action1 = action;
  sigbuffer = sigbu;
  if (signal(sig, SIG_IGN) != SIG_IGN)
     signal (sig,sighand);

}

/* Tag( sigrelse )
 */
sigrelse(sig, action)
void (*action)();
int sig;
{
  /* For bsd */
  /*sigsetmask( sigblock(0) & ~ 1<<sig );	 Unblock the signal. */

  /* For system V */
  signal(sig, action);
}

int sighand(num,subcode,scp)

int num , subcode;
struct sigcontext * scp;

{ int i = 0;
  int inhibit;
  /* old style

  printf (" Ein Signal: %d %d %x \n\n", num , subcode, scp);

  printf (" Context: \n\n");
  printf (" sp - arg3  %x %x %x %x %x %x %x %x\n",
    scp->sc_sp,scp->sc_ret1, scp->sc_ret0,scp->sc_dp,
    scp->sc_arg0,scp->sc_arg1,scp->sc_arg2,scp->sc_arg3);
  printf (" rp - pcoq_tail :%x %x %x %x %x %x %x %x\n",
    scp->sc_rp,scp->sc_sar, scp->sc_ipsw,scp->sc_psw,
    scp->sc_pcsq_head,scp->sc_pcoq_head,scp->sc_pcsq_tail,
    scp->sc_pcoq_tail);
  printf (" gr1 - gr8 :%x %x %x %x %x %x %x %x\n",
    scp->sc_gr1,scp->sc_gr2,scp->sc_gr3,scp->sc_gr4,
    scp->sc_gr5,scp->sc_gr6,scp->sc_gr7,scp->sc_gr8);
  printf (" gr9 - gr16:%x %x %x %x %x %x %x %x\n",
    scp->sc_gr9,scp->sc_gr10,scp->sc_gr11,scp->sc_gr12,
    scp->sc_gr13,scp->sc_gr14,scp->sc_gr15,scp->sc_gr16);
  printf (" gr17 -gr24:%x %x %x %x %x %x %x %x\n",
    scp->sc_gr17,scp->sc_gr18,scp->sc_gr19,scp->sc_gr20,
    scp->sc_gr21,scp->sc_gr22,scp->sc_gr23,scp->sc_gr24);
  printf (" gr25 - sr4:%x %x %x %x %x %x %x %x\n",
    scp->sc_gr25,scp->sc_gr26,scp->sc_gr27,scp->sc_gr28,
    scp->sc_gr29,scp->sc_gr30,scp->sc_gr31,scp->sc_sr4);
  /* */
  inhibit = sigbuffer [0];

  sigbuffer[i++]=num; sigbuffer[i++]=subcode; sigbuffer[i++]=scp;
  sigbuffer[i++]=scp->sc_sp; sigbuffer[i++]=scp->sc_ret1;
  sigbuffer[i++]=scp->sc_ret0; sigbuffer[i++]=scp->sc_dp;
  sigbuffer[i++]=scp->sc_arg0; sigbuffer[i++]=scp->sc_arg1;
  sigbuffer[i++]=scp->sc_arg2; sigbuffer[i++]=scp->sc_arg3;
  sigbuffer[i++]=scp->sc_rp; sigbuffer[i++]=scp->sc_sar;
  sigbuffer[i++]=scp->sc_ipsw; sigbuffer[i++]=scp->sc_psw;
  sigbuffer[i++]=scp->sc_pcsq_head; sigbuffer[i++]=scp->sc_pcoq_head;
  sigbuffer[i++]=scp->sc_pcsq_tail; sigbuffer[i++]=scp->sc_pcoq_tail;
  sigbuffer[i++]=scp->sc_gr1; sigbuffer[i++]=scp->sc_gr2;
  sigbuffer[i++]=scp->sc_gr3; sigbuffer[i++]=scp->sc_gr4;
  sigbuffer[i++]=scp->sc_gr5; sigbuffer[i++]=scp->sc_gr6;
  sigbuffer[i++]=scp->sc_gr7; sigbuffer[i++]=scp->sc_gr8;
  sigbuffer[i++]=scp->sc_gr9; sigbuffer[i++]=scp->sc_gr10;
  sigbuffer[i++]=scp->sc_gr11; sigbuffer[i++]=scp->sc_gr12;
  sigbuffer[i++]=scp->sc_gr13; sigbuffer[i++]=scp->sc_gr14;
  sigbuffer[i++]=scp->sc_gr15; sigbuffer[i++]=scp->sc_gr16;
  sigbuffer[i++]=scp->sc_gr17; sigbuffer[i++]=scp->sc_gr18;
  sigbuffer[i++]=scp->sc_gr19; sigbuffer[i++]=scp->sc_gr20;
  sigbuffer[i++]=scp->sc_gr21; sigbuffer[i++]=scp->sc_gr22;
  sigbuffer[i++]=scp->sc_gr23; sigbuffer[i++]=scp->sc_gr24;
  sigbuffer[i++]=scp->sc_gr25; sigbuffer[i++]=scp->sc_gr26;
  sigbuffer[i++]=scp->sc_gr27; sigbuffer[i++]=scp->sc_gr28;
  sigbuffer[i++]=scp->sc_gr29; sigbuffer[i++]=scp->sc_gr30;
  sigbuffer[i++]=scp->sc_gr31; sigbuffer[i++]=scp->sc_sr4;

  if (num == 2) if (inhibit){sigbuffer[0] = -1; signal (2,sighand);
                             clearerr(stdin);
                             clearerr(stdout);
                             clearerr(stderr);
				return (0);}
			else sigbuffer[0] = -1;
  if (scp->sc_sr4 == scp->sc_pcsq_tail)
   if (num == 2)  { sigbuffer[0] = -1; signal (2,sighand); return (0); }
   else
   { printf( " *** Error in PSL Kernel, system aborted \n"); exit(-255); }

  scp->sc_pcoq_head = (int) action1 +3 ;
  scp->sc_pcoq_tail = (int) action1 + 7;
}

