
hugolein()
 { return (0);}

/* This may be replaced by something really funny */
