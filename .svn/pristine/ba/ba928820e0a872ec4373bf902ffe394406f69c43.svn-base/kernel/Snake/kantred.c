
#include "kant.h"

hugolein(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13)

int a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13;

{
        block_declarations;

        integer_big     n;
        integer_small   i, l;
        faclst          facs;
        dyn_arr_handle  rem;
        char            str[200];

   switch (a1)
{ case 0: kant_start(); break;

  case 1: integer_lst_factorise (a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13);
};

return (0);

}
order_relation_eval_torsion_subgroup()   
{
   return (0);
}
