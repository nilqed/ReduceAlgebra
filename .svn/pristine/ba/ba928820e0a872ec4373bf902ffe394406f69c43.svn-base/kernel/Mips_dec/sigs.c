/*
 * sigs.c - External routines to deal with signals
 *
 * Author:    Leigh Stoller
 *         Computer Science Dept.
 *         University of Utah
 * Date:    18-Aug-1986
 *
 *           Modified by Chris Burdorf (2/17/89)
 *           renamed sigset to sun3_sigset for sun os 4.
 */
 
#include <sys/time.h>
#include <sys/resource.h>
#include <stdio.h>
#include <signal.h>
 
struct rlimit rlp;
int mysigstack[500];

/* Tag( sigset )
 */
sun3_sigset( sig, action )
void (*action)();
int sig;
{ if (sig == SIGSEGV) setupoverflow(action);
  else if (signal(sig, SIG_IGN) != SIG_IGN)
               signal(sig, action);
 
}
setupoverflow(action)
void (*action)();
{
    /* this sets the stack overflow limit to be less than
       the initial limit by 8000 bytes
     */
    struct sigstack ss;
    struct sigvec sv;
 
    /* set up to catch stack overflows */
    getrlimit(RLIMIT_STACK,&rlp);
 
    /*  we will allocate StackPreserve bytes for overflow purposes */
    rlp.rlim_cur -= 8000;
    setrlimit(RLIMIT_STACK,&rlp);
 
    ss.ss_sp = (char *) &mysigstack[450];
    ss.ss_onstack = 0;
    sigstack(&ss,0);
 
    sv.sv_handler = action;
    sv.sv_mask = 0;
    sv.sv_onstack = 1;
    sigvec(SIGSEGV,&sv,0);
 
}
 
