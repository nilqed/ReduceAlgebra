/*  

       math-fns.c
       Chris Burdorf may 17, 1988
       This file contains math routine links for the sparc architecture.
       
*/

div(x,y)
int x,y;
{return(x/y);}


mul(x,y)
int x,y;
{return(x*y);}


rem(x,y)
int x,y;
{return(x%y);}

bit_table(place,pos)
 char *place;
 int pos;
{
  int offset;
  int fraction;

  offset = pos/4;            /* byte position in bit table for entry */
  fraction=6 -(pos%4)*2;        /* bit position in byte */
  return((place[offset]>>fraction) & 3);   /* pulls out the bittable entry */
  };



put_bit_table(place,pos,value)
char *place;
int pos;
int value;
{

  int offset;
  int fraction;

  offset = pos/4;          /* byte position */
  fraction= 6 - (pos%4)*2;      /* bit position in the byte (bittable is two byte enteries */
  
  place[offset] &= ~(3 << fraction);    /* mask pattern to zero out bittable entery.  Zero out the bittable entry. */
  place[offset] |= (value & 3) << fraction;  /* put in the new bittable value */

  return(value&3);  /* returns the new bittable value */
}

