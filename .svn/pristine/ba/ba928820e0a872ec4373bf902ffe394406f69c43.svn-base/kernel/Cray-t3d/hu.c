#include <stdio.h>
#include <math.h>

main()

{ long double sum = 0.0;
  long double kk;
  int k,mm;
  int kend=150000000;
  int kact=0;
  long double m = 3.0;
 for (mm=11; mm<21;mm ++)
 {  m = mm;
    sum = 0.0;
    for (k=1;k<(kend +1);k++)
    { kk = k;
        sum = sum + powl(logl(kk),m)/kk;
     if ((k/100000) * 100000 == k)
        printf("Das ergebnis ist %d, %d: %.12g \n",mm,k,
                sum - powl(logl((long double) k),(m +1))/(m + 1));
  }}
}
