char * datetag ()
  { return ( 
" Thu Aug 15 15:13:12 1996 "
           ); } 
