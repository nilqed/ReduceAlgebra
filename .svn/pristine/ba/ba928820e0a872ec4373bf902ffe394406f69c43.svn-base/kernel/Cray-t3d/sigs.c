/*
 * sigs.c - External routines to deal with signals
 *
 * Author:      Leigh Stoller
 *              Computer Science Dept.
 *              University of Utah
 * Date:        18-Aug-1986
 *
 */

#include <stdio.h>
#include <signal.h>
#include <mpp/fp.h>

/* Tag( psl_sigset )
 */

extern long SYMVAL[];

int (*psl_handler) ();

int  first_handler (a,b,c)
long a,b;
long * c;

{/*if (c[26] - c[27] == 360024)*/ return (psl_handler(a,b,c));
 if (a !=2)
	{ printf (" %d %d %d signal \n",a,c[26] ,  c[27]);
         printf (" Interrupt in Kernel Mode, Exiting ...\n"); exit (-10); }
 SYMVAL[858] = -17;
 return (0);
}

psl_sigset( sig, action )
void (*action)();
int sig;
{  if(sig == 8) signal(sig, SIG_IGN);
  if (signal(sig, SIG_IGN) != SIG_IGN)
        { /*psl_handler = action;
	  if(sig == 8) ieee_set_fp_control(
		IEEE_TRAP_ENABLE_INV | IEEE_TRAP_ENABLE_DZE |
		IEEE_TRAP_ENABLE_OVF); */
          signal(sig, first_handler);
} }
