#include <stdio.h>
#include <mpp/a.out.h>

main ()

{  int i;
   FILE * hugo;
   mppexec_t kopf;

   hugo = fopen("bpsl","r+b");
   fread(&kopf,sizeof (mppexec_t),1,hugo);
   for (i=0;i<16;i++)
    printf("Das isses: %x %x \n",(kopf.segs[i]).segid,
                                (kopf.segs[i]).flags.prot);
   (kopf.segs[0]).flags.prot = 7;
   rewind(hugo);
   printf("return is %d \n",fwrite(&kopf,sizeof (mppexec_t),1,hugo));
   fclose (hugo);
}
