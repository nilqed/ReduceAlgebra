
/****************************************************************************

****************************************************************************/

#include "windows.h"
#include "helpserv.h"
#include "dde.h"

#define  MAXLIPUFFER        30
#define  MAXLOPUFFER        100    

HANDLE          hInst;
HANDLE          hFile;
HWND            hWnd;  
HWND            hWndClient;
HWND            hWndOK,hWndTopic;
HFONT           hFont; 
HDC             hDC; 
int             textBase=0;
int             cHeight=0;                /* character height  */
int             cWidth=0;
int             wLines,wColumns;          /* window size in chars */
int             wpLines,wpColumns;        /* window size in pixels */
int             caret_x,caret_y;
int             argc;
char           *argv[10];
HANDLE hData, hClipData;                  /* handles to clip data  */
HANDLE hText = NULL;
LPSTR          lpClipData;                 /* pointers to clip data */
DDEDATA FAR   *lpData;
HANDLE         hdef_input=NULL;           /* handle for deferred input */
HCURSOR        hSaveCursor, hHourGlass;

int            act_line,act_show;
int            insert=0;
char          *banner;
int            ctrl=0;

char           itemText[128];
char           sendpuffer[128];
char           atomtext[128];
char           FileName[128];
char           buffo[128];
RECT           text_rect;

int act_x=0, act_y=0;
int i_ptr=0; /* input pointer */
int o_ptr=0; 
int po_ptr=0;


int liptr = MAXLIPUFFER;
int licount = MAXLIPUFFER;
char lpuffer_mem[MAXLOPUFFER+1][100];
char * lpuffer[MAXLOPUFFER+1];
char ipuffer[255];
char lipuffer[MAXLIPUFFER][100];
char aux[80];

char   editBuf[40];
 

/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

    PURPOSE: calls initialization function, processes message loop

****************************************************************************/

LPSTR CmdLine;

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;
HANDLE hPrevInstance;
LPSTR lpCmdLine;
int nCmdShow;
{
    MSG msg;

    CmdLine = lpCmdLine;

    if (hPrevInstance) return(NULL);
     
    crack(CmdLine);
    
    if (!InitApplication(hInstance))
	    return (FALSE);

    if (!InitInstance(hInstance, nCmdShow))
	return (FALSE);

    while (GetMessage(&msg, NULL, NULL, NULL)) 
    {
	TranslateMessage(&msg);
	DispatchMessage(&msg);
    }
    return (msg.wParam);
}


/****************************************************************************

    FUNCTION: InitApplication(HANDLE)

    PURPOSE: Initializes window data and registers window class

****************************************************************************/

BOOL InitApplication(hInstance)
HANDLE hInstance;
{
    WNDCLASS  wc;

    wc.style = CS_DBLCLKS; 
    wc.lpfnWndProc = MainWndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = NULL;  /* LoadIcon(hInstance,"psllwrIcon"); */
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = GetStockObject(WHITE_BRUSH); 
    wc.lpszMenuName =  NULL;
    wc.lpszClassName = "helpWClass";

    return (RegisterClass(&wc));
}


/****************************************************************************

    FUNCTION:  InitInstance(HANDLE, int)

    PURPOSE:  Saves instance handle and creates main window

****************************************************************************/

BOOL InitInstance(hInstance, nCmdShow)
    HANDLE          hInstance;
    int             nCmdShow;
{


    TEXTMETRIC      textmetric;
    int             nLineHeight;
    LPSTR           b1;
    char            aux[20];
    int             i,j;
    RECT            rect;

    hInst = hInstance;
    banner = "REDUCE Help System";

    hWnd = CreateWindow(
    "helpWClass",
    banner,
	WS_OVERLAPPEDWINDOW | WS_VSCROLL,  
	CW_USEDEFAULT,
	CW_USEDEFAULT,
	CW_USEDEFAULT,
	CW_USEDEFAULT,
	NULL,
	NULL,
	hInstance,
	NULL
    );

    if (!hWnd)
	return (FALSE);

    CreateWindow("BUTTON",
	"exit",
	WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	0,1,59,25,
	hWnd,
	IDC_EXIT,
	hInst,NULL);

    CreateWindow("BUTTON",
	"HELP",
	WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
	60,1,59,25,
	hWnd,
	IDOK,
	hInst,NULL);

    CreateWindow("BUTTON",
	"next",
	WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	120,1,59,25,
	hWnd,
	IDC_NEXT,
	hInst,NULL);
    
    CreateWindow("BUTTON",
	"prev",
	WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	180,1,59,25,
	hWnd,
	IDC_PREV,
	hInst,NULL);

    CreateWindow("BUTTON",
	"top",
	WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	240,1,59,25,
	hWnd,
	IDC_TOP,
	hInst,NULL);

    CreateWindow("BUTTON",
	"related",
	WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	300,1,59,25,
	hWnd,
	IDC_REL,
	hInst,NULL);

    CreateWindow("BUTTON",
	"apropos",
	WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	360,1,59,25,
	hWnd,
	IDC_APROPOS,
	hInst,NULL);

    CreateWindow("STATIC",
	"topic:",
	WS_CHILD | WS_VISIBLE,
	0,35,35,20,
	hWnd,
	NULL,
	hInst,NULL);
    
    GetClientRect(hWnd,(LPRECT)&rect);
    
   hWndTopic =
    CreateWindow("EDIT",
	NULL,
	WS_CHILD | WS_VISIBLE | WS_BORDER | ES_UPPERCASE ,
	40,30,rect.right-rect.left -20 -40,25,
	hWnd,
	IDH_TOPIC,
	hInst,NULL);

    textBase = 60;
    text_rect.left = rect.left;
    text_rect.right = rect.right;
    text_rect.top = textBase;
    text_rect.bottom = rect.bottom;


    hWndOK = CreateWindow("STATIC",
	"ok",
	WS_CHILD | WS_VISIBLE | WS_BORDER ,
	0, textBase-2, rect.right-rect.left-20, 2,
	hWnd,
	IDOK,
	hInst,NULL);


    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    hHourGlass = LoadCursor(NULL, IDC_WAIT);

    hDC = GetDC(hWnd);

    goto nofont;

    hFont = CreateFont(
	 8,   /* 10, */
	 0,   /* 8,  */
	 0,
	 0,
	 FW_NORMAL,
	 FALSE,
	 FALSE,
	 FALSE,
	 ANSI_CHARSET,
	 OUT_DEFAULT_PRECIS,
	 CLIP_DEFAULT_PRECIS,
	 DEFAULT_QUALITY,
	 FIXED_PITCH | FF_MODERN,
	 "System" 
	 );
    if (hFont) SelectObject(hDC, hFont);

  nofont:
       /* font geometry */
    GetTextMetrics(hDC, &textmetric);
    i=ReleaseDC(hWnd, hDC);
    nLineHeight = textmetric.tmExternalLeading + textmetric.tmHeight;
    cWidth = textmetric.tmMaxCharWidth;
    cHeight = nLineHeight;
      /* window geometry */
    get_geometry();

    my_prepare();
    return (TRUE);

}

get_geometry()
  {
    RECT rect;
    if(cHeight==0) return(0);
    GetClientRect(hWnd,&rect);
    wpLines = rect.bottom - rect.top - 15 - textBase;
    wLines = wpLines / cHeight;
    wpColumns = rect.right - rect.left - 5;
    wColumns = wpColumns / cWidth;
    wColumns = min(99,wColumns);

    wColumns = 99;
  }

/****************************************************************************

    FUNCTION: MainWndProc(HWND, unsigned, WORD, LONG)


    COMMENTS:


****************************************************************************/


long FAR PASCAL MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;
unsigned message;
WORD wParam;
LONG lParam;
{
    FARPROC lpProcAbout;
    PAINTSTRUCT ps;                  /* paint structure              */
    char HorzOrVertText[12];
    char ScrollTypeText[20];
    RECT rect;
    int i,j,l;
       
    ATOM atomApplication, atomTopic, atomItem;


       switch(message){

	case WM_DDE_INITIATE:
	    /*  my_puts("\nDDE INITIATE\n"); */
	    hWndClient = wParam;
	    atomApplication = LOWORD(lParam);
	    atomTopic = HIWORD(lParam);

		 /* this application addressed? */
	    if (GlobalGetAtomName(atomApplication,itemText,128)
	       && (0==lstrcmp(itemText,"ReduceHelp"))
	       && GlobalGetAtomName(atomTopic,itemText,128)
	       && (0==lstrcmp(itemText,"Help")))
	   {
	    atomApplication = GlobalAddAtom("ReduceHelp");
	    atomTopic = GlobalAddAtom("Help");
	    SendMessage(hWndClient, 
			    WM_DDE_ACK,
			    hWnd,  /* server */
			    MAKELONG(atomApplication,atomTopic));
	    GlobalDeleteAtom(atomApplication);
	    GlobalDeleteAtom(atomTopic);
	   }
	   break;

	case WM_DDE_REQUEST:
	   hWndClient = wParam;
	   atomItem = HIWORD(lParam);
	   GlobalGetAtomName(atomItem,itemText,128);
	   /*  my_puts("item requested:");
	       my_puts(itemText);
	   */

	   if(0==lstrcmp(itemText,"HANDSHAKE"))
		   lstrcpy(sendpuffer,"OK");
	       else
	   if(0==lstrcmp(itemText,"TOPIC"))
	   {
		   editBuf[0] = 40;
		   editBuf[1] = 0;
		   l = SendMessage(hWndTopic,EM_GETLINE,0,
				    (LONG)(LPSTR)editBuf);
		   lstrcpy(sendpuffer,editBuf);
	   }
	     else
	   lstrcpy(sendpuffer,"don't know which item to send");
 
	   if(!(hData = GlobalAlloc(GMEM_MOVEABLE | GMEM_DDESHARE,
		 (long)sizeof(DDEDATA) + strlen(sendpuffer) + 2)))
		 break;
	   if(!(lpData = (DDEDATA FAR *)GlobalLock(hData)))
	     {GlobalFree(hData); break;}
	   lpData->cfFormat = CF_TEXT;
	   lstrcpy((LPSTR)lpData->Value,(LPSTR)sendpuffer);
       /*  lstrcat((LPSTR)lpData->Value,(LPSTR)"\r\n"); */ 
	   GlobalUnlock(hData);
	   SendMessage(hWndClient,
			    WM_DDE_DATA,
			    hWnd, 
			    MAKELONG(hData, atomItem));
	   break;

	case WM_DDE_POKE:
	   hWndClient = wParam;
	   atomItem = HIWORD(lParam);
	   GlobalGetAtomName(atomItem,itemText,128);
	   hData = LOWORD(lParam);
	   if(!(lpData = (DDEDATA FAR *)GlobalLock(hData)))
	     {GlobalFree(hData); break;}
	   receive_message((char*)itemText,(LPSTR)lpData->Value);
	   GlobalUnlock(hData);
	   GlobalFree(hData);
	   GlobalDeleteAtom(atomItem);
	   PostMessage(hWndClient,WM_DDE_ACK,
			    hWnd, MAKELONG(0x8000, 0));
	   return(1);

       case WM_DDE_TERMINATE:
	   PostQuitMessage(0);
	   break;

	case WM_COMMAND:
	    caret(0);
	    switch (wParam) 
	    {

		case IDC_EXIT:
		   PostQuitMessage(0);
		   break;

		case IDOK: 
		   send_message("BUTTON","HELP0");
		   break;
    
		case IDC_TOP:
		 /*  SendMessage(hWndTopic,WM_SETTEXT,NULL,
			       (DWORD)(LPSTR)"Ein M�nnlein steht im Flu�");
		 */
		   send_message("BUTTON","TOP");
		   break;

		case IDC_NEXT:
		   send_message("BUTTON","NEXT");
		   break;
		
		case IDC_PREV:
		   send_message("BUTTON","PREVIOUS");
		   break;

		case IDC_REL:
		   send_message("BUTTON","RELATED");
		   break;
		   
		case IDC_APROPOS:
		   send_message("BUTTON","APROPOS");
		   break;

		default:
		     return (DefWindowProc(hWnd, message, wParam, lParam));

	    }; 
	    break;

     
	case WM_MOUSEMOVE:

	    break;
	
	case WM_CHAR:
		 ctrl = 0;
		 caret(0);  
		 if(HIWORD(lParam) == 0x1c) i = do_char('\n');
				       else i = do_char((unsigned char)wParam);
		 
	    break;

	case WM_VSCROLL:
	     scrollbar(wParam,lParam);
	     break;

	case WM_PAINT:
	    hDC = BeginPaint (hWnd, &ps);
	    my_refresh();
	    EndPaint(hWnd, &ps);
	    break;
	
	default:
	    return (DefWindowProc(hWnd, message, wParam, lParam));
    }
	
    SetFocus(hWndTopic);

    return (NULL);
}

send_message(char * token, char * text)
{  ATOM atomItem;
   atomItem = GlobalAddAtom(token);
	   lstrcpy(sendpuffer,text);
	   if(!(hData = GlobalAlloc(GMEM_MOVEABLE | GMEM_DDESHARE,
		 (long)sizeof(DDEDATA) + strlen(sendpuffer) + 2)))
		 return(0);
	   if(!(lpData = (DDEDATA FAR *)GlobalLock(hData)))
	     {GlobalFree(hData); return(0);}
	   lpData->cfFormat = CF_TEXT;
	   lstrcpy((LPSTR)lpData->Value,(LPSTR)sendpuffer);
    /*     lstrcat((LPSTR)lpData->Value,(LPSTR)"\r\n");  */
	   GlobalUnlock(hData);
	   SendMessage(hWndClient,
			    WM_DDE_DATA,
			    hWnd, 
			    MAKELONG(hData, atomItem));
 }

LPSTR gtext;

receive_message(char* item,LPSTR text)
  {
    int i,l;
    char field[20];

    if (0 == lstrcmp(item,"BEGIN_TRANSACTION"))
	;
       else
    if (0 == lstrcmp(item,"~CLEAR"))
     { 
       act_line = 0; 
     }
       else
    if (0 == lstrcmp(item, "PUTLINE"))
     { 
       gtext = text;
       crackoff_name(field);
       l=crackoff_number();
       text = gtext;
       i=0;
       while (lpuffer[act_line][i] = text[i]) i++;
       for(i=i;i<100;i++) lpuffer[act_line][i] = ' ';
       act_line ++;
       for(i=0;i<100;i++) lpuffer[act_line][i] = ' ';
       SetScrollRange(hWnd,SB_VERT,min(wLines,act_line-1),act_line,TRUE);
     }
       else
    if (0 == lstrcmp(item, "END_TRANSACTION"))
     { 
       my_showpage(1);
     }
       else
	 warning("unknown receive",item);
  }

crackoff_number()
   { int l=0;
     char c;
     while(*gtext == ' ') gtext++;
     while((c = *gtext) 
	   && '0' <= c
	   && c <= '9' ) 
       {l=l*10 + (c-'0'); gtext++;}
     while(*gtext == ' ') gtext++;
     return(l);
   }

crackoff_name(char name[])
   { int i=0;
     char c;
     while(*gtext == ' ') gtext++;
     while((c = *gtext) != ' ') 
       {name[i++]=c; gtext++;}
     name[i] = '\0';
     while(*gtext == ' ') gtext++;
   }

melden(char * s, long j)
  { int i;
    char buf[20];
    my_puts(s);
    wsprintf(buf," %lx\n",j);
    my_puts(buf);
  }

/*--------------------------------------------------------------
	      display services
  --------------------------------------------------------------*/

/* FONT resources */



my_prepare()
  {int i,j;
    for(i=0;i<MAXLOPUFFER+1;i++)
     {lpuffer[i] = lpuffer_mem[i];
      for(j=0;j<100;j++) lpuffer_mem[i][j] = ' ';
     }
   }

cursorKey(WORD key)
    {int i,loc;
     PAINTSTRUCT ps; 

      switch(key)
       {
	 case 0x8:     /* backspace */
	
	    if (i_ptr==0) break;
	    i_ptr--;
	    for(i=i_ptr;i<100;i++) 
		ipuffer[i] = ipuffer[i+1];
	    ipuffer[100] = '\0';
	    caret_x = caret_x - cWidth;
	  break;
	 
	 case 0x2e:    /* del */
	    for(i=i_ptr;i<100;i++) 
		ipuffer[i] = ipuffer[i+1];
	    ipuffer[100] = '\0';
	  break;  
	 
	 case 0x2d:    /* ins  (toggle) */
	    insert = !insert;
	 /*
	    for(i=99;i>i_ptr;i--)
		ipuffer[i]=ipuffer[i-1];
	    ipuffer[i_ptr] = ' ';
	 */
	 break;

	 case 0x25:     /* <- */
	    if(i_ptr == 0) break;
	    i_ptr--;
	    caret_x = caret_x - cWidth;
	 break;

	 case 0x27:     /* -> */
	    if(i_ptr >= wColumns || ipuffer[i_ptr] == '\0') break;
	    i_ptr++;
	    caret_x = caret_x + cWidth;
	 break;

	 case 0x26:     /* up */
	    if(liptr > licount)
	    { liptr--;
	      for(i=0;i<100;i++)
		  ipuffer[i] = lipuffer[liptr][i];
	      caret_x = caret_x - cWidth * i_ptr;
	      i_ptr = 0;
	    };
	 break;

	 case 0x28:     /* down */
	    if(liptr < MAXLIPUFFER)
	    { liptr++;
		for(i=0;i<100;i++)
		if(liptr < MAXLIPUFFER)
		  ipuffer[i] = lipuffer[liptr][i];
		    else
		  ipuffer[i] = '\0';
	      caret_x = caret_x - cWidth * i_ptr;
	      i_ptr = 0;
	    }
	 break;

	 case 0x21:     /* Pgup */
	    if (act_show <= wLines || act_line <= wLines) break;
	    my_showpage(act_show - wLines);
	    break;
	 
	 case 0x22:     /* Pgdown */
	    my_showpage(act_show + wLines);
	    break;


	 default:
	   return(0);
       }
    }

scrollbar(WORD wParam,WORD lParam)                                 
  { if(act_line > wLines)
    switch(wParam)
   {
	case SB_BOTTOM:     my_showpage(act_line); break;
	case SB_LINEDOWN:   my_showpage(act_show + 1); break;
	case SB_LINEUP:     my_showpage(act_show - 1); break;
	case SB_PAGEDOWN:   my_showpage(act_show + wLines); break;
	case SB_PAGEUP:     my_showpage(act_show - wLines); break;
	case SB_THUMBPOSITION:
			    my_showpage(lParam); break;
	case SB_TOP:        my_showpage(wLines);
  }}
     
do_char(char c)
     {long i;
      int j,k,l;
   
      if(c != '\n' && c<' ') return(1);
      liptr = MAXLIPUFFER;
      if(act_line != act_show) my_showpage(act_line);

     if(c != '\n')
     { 
       if (insert)
	{   for(i=254;i>i_ptr;i--)
		ipuffer[i]=ipuffer[i-1];
	    ipuffer[i_ptr] = ' ';
	 }
       
       if (o_ptr + i_ptr < wColumns) 
	  { ipuffer[i_ptr] = c; 
	    i_ptr++;
	  } 
	  
       if (o_ptr + i_ptr < wColumns)   
	  {
	    caret_x = caret_x + cWidth;
	    return(1);
	  }
     };
      

       /* save input line */
       licount=max(licount--,0);
       for(j=licount;j<MAXLIPUFFER-1; j++)
	    for(k=0;k<100;k++) lipuffer[j][k] = lipuffer[j+1][k];
       for(k=0;k<l;k++) 
	      lpuffer[act_line][o_ptr+k] = lipuffer[MAXLIPUFFER-1][k] 
					 = ipuffer[k];
					 
       for(k=l;k<100;k++) lipuffer[MAXLIPUFFER-1][k] = '\0';
       o_ptr = o_ptr+l;
       my_putc('\n');
	 
	 /* process the line, surrounded by the hourglass symbol */
       i_ptr = 0;
  
       hSaveCursor = SetCursor(hHourGlass);
       

       for (j=0; j<100; j++) ipuffer[j] = '\0';
       if (i==0) return(0); else return(1);
     }

/*******************************************************************
	 display services
/*******************************************************************/

dumpo(LPSTR txt,int l)
  {int i;
   for(i=0;i<l;i++) 
       {my_putoct(((long)txt[i])&0xff);
	if(!((i+1)&7)) my_putc(' ');
       }
   my_newline();
  }

my_putoct(l)
   long l;
   { wsprintf(aux,"%lx ",l); 
     my_puts(aux);
     my_flush();}

my_putint(l)
   long l;
   { wsprintf(aux,"%ld ",l); 
     my_puts(aux);
     my_flush(); }


my_puts(s)
     char s[];
     {int i=0; char c;
      while(c = s[i++]) my_putc(c);
      my_flush();
     }

far_puts(s)
     LPSTR s;
     {int i=0; char c;
      lstrcpy(buffo,s);
      while(c = buffo[i++]) my_putc(c);
      my_flush();
     }
      
      
my_newline()
     {my_putc('\n');
      my_flush();
     }


my_putc(c)
     char c;
     {int i;

      if(act_line != act_show) my_showpage(act_line);
      
      if (o_ptr>=wColumns || c=='\n') 
	 {my_flush();
	  for (i=o_ptr; i< wColumns; i++) 
	      lpuffer[act_line][i]=' '; /* fill line*/
	  o_ptr = po_ptr = 0; 
	  caret_x = textBase;
	  act_y = act_y + cHeight;
	  caret_y = act_y;
	  act_line ++;
	  /* if(act_line >= wLines) my_scrollup(); */
	 };

      if (c>= ' ' && c< 0x7f)
	 {lpuffer[act_line][o_ptr]=c; o_ptr++;}
     }

my_flush()
    {
	  if(po_ptr == o_ptr) return(0);
	  hDC = GetDC(hWnd);  
	  if (hFont) SelectObject(hDC, hFont); 
	  TextOut(hDC,(po_ptr) * cWidth,textBase+act_y,
		      &lpuffer[act_line][po_ptr],
		      o_ptr-po_ptr+1);
	  ReleaseDC(hWnd, hDC);
	  po_ptr = o_ptr;
	  caret_x = o_ptr * cWidth;
	  return(1);
     }

my_refresh()
    {int i,j,v,b;
     if (hFont) SelectObject(hDC, hFont); 
     FillRect(hDC,(LPRECT)&text_rect,GetStockObject(WHITE_BRUSH)); 
     act_y=0;
     b = max(0,act_line - wLines +1); /* base */
     for(i=b;i<=act_line;i++)
	  {TextOut(hDC,0,textBase+act_y,lpuffer[i],wColumns); 
	   act_y=act_y + cHeight;};
     act_y=act_y - cHeight;
     act_show = act_line;
     SetScrollPos(hWnd,SB_VERT,act_line,1);
    }

my_showpage(n)
   /* display previous page with bottom line n */
    {int i,j,v,b;
     caret(0);
     hDC = GetDC(hWnd);
     FillRect(hDC,(LPRECT)&text_rect,GetStockObject(WHITE_BRUSH));
     if (hFont) SelectObject(hDC, hFont); 
     act_y=0;
     if(n>act_line) n= act_line;
     b = n - wLines +1; /* base */
     if (b<0) {n = min(n-b,act_line); b=0;}
     for(i=b;i<=n;i++)
	  {TextOut(hDC,0,textBase+act_y,lpuffer[i],wColumns); 
	   act_y=act_y + cHeight;};
     act_y=act_y - cHeight;
     act_show = n;
     i=ReleaseDC(hWnd, hDC);
     SetScrollPos(hWnd,SB_VERT,n,1);
    }


char speicher[255];
 
crack(LPSTR cline)
   {int j; char c;
    argc = j = 0;
    if(cline[0]=='\0') {argc=-1; return(0);};
  loop:  
    argv[argc] = & speicher[j];
    while((c = cline[j]) != ' ' 
		    && c != '\0' 
		    && c != 0x0d 
		    && c != 0x0a 
		    && j <= 255)
	 { speicher[j] = c; j++;};
    speicher[j] = '\0';
    j++;
    if (argc<10 && j<255 && c!=0x0d && c!=0x0a && c!='\0') 
    { argc++; goto loop;};
   }

caret(int mode)
  { 
    if(mode == 1) 
    { CreateCaret(hWnd,1,cWidth,cHeight);
      SetCaretPos(caret_x,caret_y);
      ShowCaret(hWnd);
    }
     else DestroyCaret();
  }

     
/***************** function getenv ************************************/
 
int getenv(char * var, char * val)
  { int i;
    char c;
    char d;
    LPSTR env;
    int found=0;
    d = 'a' - 'A';

    env = GetDOSEnvironment();
    if(!env) return(0);
    while(*env!=0x01 && !found)
    {
       i=0;
       while(var[i] &&  (    var[i] == env[i]
			  || var[i]+d == env[i]
			  || var[i] == env[i]+d
			)
	  ) i++;
	  
       if(!var[i] && env[i] == '=') found=i+1;
	 else
	    while(*env++);  /* skip */
    }
    if(!found) return(0);
    env = &env[found];
    while(*val++ = *env++);
    return(1);
  }

warning(LPSTR head,LPSTR s)
  {MessageBox(GetFocus(),s,head,
	 MB_ICONASTERISK | MB_OK); }

iwarning(LPSTR head,long i)
  {wsprintf((LPSTR)buffo,"%lx",i);
   warning(head,(LPSTR) buffo);
  }
 