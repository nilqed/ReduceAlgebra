#define IDM_ABOUT 100

/* file menu items */

#define     IDM_DRIBBLE      101
#define     IDM_CD           102  
#define      IDM_DRI_ON         110
#define      IDM_DRI_OFF        111 
#define      IDM_DRI_FILE       112
#define      IDM_DRI_LINEW      113
#define     IDM_STOREDIR     103
#define     IDM_LOADSESSION  104
#define     IDM_EXIT         105
#define     IDM_BACKGROUND   106

/* edit menu items */

#define     IDM_COPY     200
#define     IDM_PASTE    201
#define     IDM_AUTOCOPY 202

#define     IDM_FONT    220
#define     IDM_FONT1   221
#define     IDM_FONT2   222
#define     IDM_FONT3   223

#define     IDM_HELP     230

/* Control IDs */

#define     IDC_FILENAME  400
#define     IDC_EDIT      401
#define     IDC_FILES     402
#define     IDC_PATH      403
#define     IDC_LISTBOX   404
#define     IDC_EXIT      405
#define     IDC_NEW       406
#define     IDC_NEXT      407
#define     IDC_PREV      408
#define     IDC_REL       409
#define     IDC_TOP       410
#define     IDC_APROPOS   411

#define     IDH_TOPIC     430

int PASCAL WinMain(HANDLE, HANDLE, LPSTR, int);
BOOL InitApplication(HANDLE);
BOOL InitInstance(HANDLE, int);
long FAR PASCAL MainWndProc(HWND, unsigned, WORD, LONG);
BOOL FAR PASCAL About(HWND, unsigned, WORD, LONG);

BOOL yesp(LPSTR);
BOOL yesp2(LPSTR,LPSTR);
BOOL filep(LPSTR);
     warning(LPSTR,LPSTR);
    iwarning(LPSTR,long);
int FAR PASCAL YespDlg(HWND, unsigned, WORD, LONG);
int FAR PASCAL HelpDlg(HWND, unsigned, WORD, LONG);

dumpo(LPSTR,int);
long help(long,LPSTR);
