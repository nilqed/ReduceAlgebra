/****************************************************************************
    PURPOSE: send/receive interface 
*/ 

/* #include "windows.h"  */
#include "psllw.h"
#include "dde.h"

extern   HANDLE      hInst;
extern   HWND        hWnd;
	 HWND        hWndServer;
extern   char        dir[];
extern   LPSTR       banner;
extern   int         storedir;         
	 char        title[120];      
extern   char       *argv[];
extern   char       *iname;
extern   int         ScriptFile;         
extern   HANDLE      hData;
extern   DDEDATA FAR *       lpData;

extern   char       FileName[];

extern   WORD       dde_message[];
extern   WORD       dde_wParam[];
extern   DWORD      dde_lParam[];
extern   int        dde_ptr;
extern   char       dde_block;

WORD wait_for_ACK(int);


/****************************************************************************

    client_open ("server name","topic name");

****************************************************************************/

WORD client_open(LPSTR server,LPSTR topic)
{
    ATOM atomApplication, atomTopic;
    atomApplication = GlobalAddAtom(server);
    atomTopic = GlobalAddAtom(topic);
    SendMessage(-1, WM_DDE_INITIATE, hWnd,
		MAKELONG(atomApplication, atomTopic));
    GlobalDeleteAtom(atomApplication);
    GlobalDeleteAtom(atomTopic);

    /* wait for ACK message */
    wait_for_ACK(WM_DDE_ACK);
    return(hWndServer);
}

WORD client_close(HWND hWndServer)
 {  ATOM atomItem;
    if (!hWndServer) return(NULL);
    PostMessage(hWndServer,WM_DDE_TERMINATE, hWnd, (DWORD)0);
    wait_for_ACK(WM_DDE_ACK); /* only because of timer */
    return(1);
 }

WORD client_fetch(HWND hWndServer,LPSTR item,LPSTR text)
 {  ATOM atomItem;
    if (!hWndServer) return(NULL);
    atomItem = GlobalAddAtom(item);
    SendMessage(hWndServer,
		     WM_DDE_REQUEST,
		     hWnd, 
		     MAKELONG(CF_TEXT, atomItem));
    GlobalDeleteAtom(atomItem);
    if(!(hData = wait_for_ACK(WM_DDE_DATA))) return(NULL);
    if(!(lpData = (DDEDATA FAR *)GlobalLock(hData)))
	     {GlobalFree(hData); 
	      my_puts("Error gobal lock\n");
	      return(NULL);}
    lstrcpy(text,(LPSTR)lpData->Value);
    GlobalUnlock(hData);
    GlobalFree(hData);
    GlobalDeleteAtom(atomItem);
    return(1);
 }

WORD client_ask(LPSTR text)
 /* pick up waiting message */
 {  ATOM atomItem;
    WORD r;
    int msg,l;

    if (dde_ptr<0) return(NULL);
    atomItem = HIWORD(dde_lParam[0]);
    r = dde_wParam[0];
    msg = dde_message[0];
    hData = LOWORD(dde_lParam[0]);
    pop_message();      

    if(msg == WM_DDE_DATA)
    {
       if(!hData) return(NULL);
       if(!(lpData = (DDEDATA FAR *)GlobalLock(hData)))
	     {GlobalFree(hData); 
	      my_puts("Error gobal lock\n");
	      return(NULL);}
       lstrcpy(text,(LPSTR)lpData->Value);
       GlobalUnlock(hData);
       GlobalFree(hData);
    } 
    else if(msg == WM_DDE_ACK) lstrcpy(text,"ACK");
    l=GlobalGetAtomName(atomItem,FileName,127);
    FileName[l] = '\0';
    GlobalDeleteAtom(atomItem);
    return(r);
 }

pop_message()
  {int i;
   for(i=0; i<dde_ptr; i++)
    { dde_message[i] = dde_message[i+1];
      dde_lParam[i] = dde_lParam[i+1];
      dde_wParam[i] = dde_wParam[i+1];
    }
   dde_ptr--;
  
  }


WORD client_send(HWND hWndServer,LPSTR item,LPSTR text)
 {  ATOM atomItem;
    if (!hWndServer) return(NULL);
    atomItem = GlobalAddAtom(item);
    if(!(hData = GlobalAlloc(GMEM_MOVEABLE | GMEM_DDESHARE,
	 (long)sizeof(DDEDATA) + lstrlen(text) + 2)))
		 return(NULL);
    if(!(lpData = (DDEDATA FAR *)GlobalLock(hData)))
	 {GlobalFree(hData); return(NULL);}
    lpData->cfFormat = CF_TEXT;
    lstrcpy((LPSTR)lpData->Value,(LPSTR)text);
 
 /*  lstrcat((LPSTR)lpData->Value,(LPSTR)"\r\n"); */
    GlobalUnlock(hData);
    if (!SendMessage(hWndServer,WM_DDE_POKE,
		     hWnd, MAKELONG(hData, atomItem)))
     {GlobalFree(hData);
      GlobalDeleteAtom(atomItem);
      return(NULL);
     };
    return(wait_for_ACK(WM_DDE_ACK));
 }
    
WORD wait_for_ACK(int ack)
{   
    WORD r=NULL;
    int timer;
    int c=0;
    MSG msg;

    hWndServer = NULL;

    if(dde_ptr <0) 
    {
       timer = SetTimer(hWnd,NULL,100,NULL);
     warten:  
       GetMessage(&msg,hWnd,min(ack,WM_TIMER),max(ack,WM_TIMER));
       if(msg.message != WM_TIMER && msg.message != ack && dde_ptr<0) 
	   goto warten;
       if(msg.message == WM_TIMER && dde_ptr<0 && c++ < 5) 
	   goto warten;
       KillTimer(hWnd,timer);
       if(dde_ptr <0)
       { if(msg.message !=ack) return(NULL);
	 hWndServer = msg.wParam;
	 r = LOWORD(msg.lParam);
	 if (r == 0x8000) r=1;
	 return(r);
       }
    }
  
  next:
    if(dde_ptr >=0 && dde_message[0] == ack) 
      {
       hWndServer = dde_wParam[0]; 
       r = LOWORD(dde_lParam[0]);
       pop_message();
      }
       else
    if(dde_ptr >=0 ) 
      {   
       melden("unexpected DDE message:",(long) dde_message[0]);
       puts_message(dde_message[0]);
       my_puts(" expected: "); puts_message(ack);
       pop_message();
       if(dde_ptr <0) my_puts("---- no more message\n");
       goto next;
      }

   if(r == 0x8000) r=1;
   return(r);
 } 

puts_message(int m)
  { if(m == WM_DDE_DATA) my_puts(" DDE_DATA ");
    else if(m == WM_DDE_ACK) my_puts(" DDE_ACK ");
    else if(m == WM_DDE_INITIATE) my_puts(" DDE_INITIATE ");
    else if(m == WM_DDE_TERMINATE) my_puts(" DDE_TERMINATE ");
  }

dde_reset()
  { return(0);}

int timer=0;

sleep(int time)
{   
    MSG msg;
    
    Yield();
    while(PeekMessage(&msg,hWnd,NULL,NULL,PM_REMOVE)); /*clear msg queue*/
    if(time==0 && timer)
      { KillTimer(hWnd,timer); timer=0;}
      else
    {if(!timer) timer = SetTimer(hWnd,NULL,time,NULL);
     if (!timer) return(0);
     loop:
      GetMessage(&msg,hWnd,NULL,NULL);
      /* if (msg.message !=WM_TIMER) goto loop; */
    }
    return(timer);
}
