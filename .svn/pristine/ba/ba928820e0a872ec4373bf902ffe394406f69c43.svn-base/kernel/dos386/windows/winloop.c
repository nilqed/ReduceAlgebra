/****************************************************************************

****************************************************************************/

#include "psllw.h"
#include "dde.h"
#include "winstruc.c"


/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

    PURPOSE: calls initialization function, processes message loop

****************************************************************************/

LPSTR CmdLine;

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;
HANDLE hPrevInstance;
LPSTR lpCmdLine;
int nCmdShow;
{
    MSG msg;

    CmdLine = lpCmdLine;

    if (hPrevInstance) return(NULL);

    crack(CmdLine);
    
    if (!InitApplication(hInstance))
	    return (FALSE);

    if (!InitInstance(hInstance, nCmdShow))
	return (FALSE);

    if(Catch(CatchBuf)) PostQuitMessage(0);
 
    while (GetMessage(&msg, NULL, NULL, NULL))
    {
	TranslateMessage(&msg);
	DispatchMessage(&msg);
    }
    return (msg.wParam);
}


/****************************************************************************

    FUNCTION: InitApplication(HANDLE)

    PURPOSE: Initializes window data and registers window class

****************************************************************************/

BOOL InitApplication(hInstance)
HANDLE hInstance;
{
    WNDCLASS  wc;

    wc.style = CS_DBLCLKS; 
    wc.lpfnWndProc = MainWndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(hInstance,"psllwrIcon");
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    hArrow = wc.hCursor;
    wc.hbrBackground = GetStockObject(WHITE_BRUSH); 
    wc.lpszMenuName =  "psllMenu";
    wc.lpszClassName = "InputWClass";

    return (RegisterClass(&wc));
}


/****************************************************************************

    FUNCTION:  InitInstance(HANDLE, int)

    PURPOSE:  Saves instance handle and creates main window

****************************************************************************/

BOOL InitInstance(hInstance, nCmdShow)
    HANDLE          hInstance;
    int             nCmdShow;
{


    TEXTMETRIC      textmetric;
    int             nLineHeight;
    LPSTR           b1;
    char            aux[20];
    int             i,j;

    hInst = hInstance;
    LoadAccelerators(hInst,"EditMenuAcc");
    if(argc > 0) banner = argv[0]; else banner = "LISP";
    b1 = banner;
    while (*b1) {if (*b1 == '\\') banner = ++b1; else  b1++;};

    hWnd = CreateWindow(
    "InputWClass",
    banner,
	WS_OVERLAPPEDWINDOW | WS_VSCROLL,  /* horz & vert scroll bars */
	org_x = get_profile_int("WX0",CW_USEDEFAULT),
	org_y = get_profile_int("WY0",CW_USEDEFAULT),
	get_profile_int("WX1",CW_USEDEFAULT),
	get_profile_int("WY1",CW_USEDEFAULT),
	NULL,
	NULL,
	hInstance,
	NULL
    );

    if (!hWnd)
	return (FALSE);

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);
    SetFocus(hWnd);

    hHourGlass = LoadCursor(NULL, IDC_WAIT);
    hPageCurs = LoadCursor(hInstance, "pageCursor");

    dcon();

    hFont = CreateFont(
	 8,
	 0,
	 0,
	 0,
	 FW_NORMAL,
	 FALSE,
	 FALSE,
	 FALSE,
	 ANSI_CHARSET,
	 OUT_DEFAULT_PRECIS,
	 CLIP_DEFAULT_PRECIS,
	 DEFAULT_QUALITY,
	 FIXED_PITCH | FF_MODERN,
	 "System"    
	 );

    if (hFont) SelectObject(hDC, hFont);
       /* font geometry */
    GetTextMetrics(hDC, &textmetric);
    dcoff();
    nLineHeight = /* textmetric.tmExternalLeading + */ textmetric.tmHeight;
    cWidth = textmetric.tmMaxCharWidth;
    cHeight = nLineHeight;
      /* window geometry */
    get_geometry(0);

    if(  ((GetVersion() & 0xf) < 3)
	 || !(GetWinFlags()&WF_ENHANCED))    
	iwarning("GetWinFlags",GetWinFlags());
     /*   error("requires WINDOWS 3 in ENHANCED 386 mode");    */
    
    if(!my_getenv("reduce",renv))
	{  
       warning("variable REDUCE not set","using `\\reduce'");
       lstrcpy(renv,"\reduce");
    }
    if(Catch(CatchBuf)) return(FALSE); /* error exit during init */

    my_prepare();
    font_nr = get_profile_int("FONT",IDM_FONT_SYS);
    font_size = get_profile_int("FONTSIZE",0);
    if (font_nr <= IDM_FONT || IDM_FONT_HI < font_nr) font_nr = IDM_FONT_SYS;

    newfont(font_nr,font_size,0); 
    get_geometry(0);       

    page_mode = (char)get_profile_int("PAGE_MODE",0);

    graphics_mode = (char) get_profile_int("GRAPHICS_MODE",0);
    set_graphics_mode(graphics_mode);

      /* load and initialize LISP module */
    my_start(); 
      /* examine for -i and -o parameters */
    my_mode();
      /* prepare for dialog */
    init = 1;
    
    if(ScriptFile) ScriptIn();

    get_profile_string("DIR","",dir,128);
    if(dir[0]) my_cd((LPSTR)dir);
    storedir = 1;    
    IsActive = 1;
    return (TRUE);

}

/****************************************************************************

    FUNCTION: MainWndProc(HWND, unsigned, WORD, LONG)


    COMMENTS:


****************************************************************************/


long FAR PASCAL MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;
unsigned message;
WORD wParam;
LONG lParam;
{
    FARPROC lpProcAbout;
    PAINTSTRUCT ps;                  /* paint structure              */
    char HorzOrVertText[12];
    char ScrollTypeText[20];
    RECT rect;
    int i,j;
    FARPROC lpFileDlg;
    int Success;                            /* return value from SaveAsDlg() */
    int IOStatus;                           /* result of file i/o      */
    MSG msg;    
   
       caret(0);
 

 switch(message){

	case WM_INITMENU:
	    if (wParam == GetMenu(hWnd)) 
	    {
		if (OpenClipboard(hWnd)) 
		{
		    if (IsClipboardFormatAvailable(CF_TEXT)
			|| IsClipboardFormatAvailable(CF_OEMTEXT))
			EnableMenuItem(wParam, IDM_PASTE, MF_ENABLED);
		    else
			EnableMenuItem(wParam, IDM_PASTE, MF_GRAYED);
		    CloseClipboard();
		}    

		if (graphics_mode)
			  CheckMenuItem(wParam, IDM_GRAPHICS, MF_CHECKED);
			     else
			  CheckMenuItem(wParam, IDM_GRAPHICS, MF_UNCHECKED);

		if (dribble)
		       {  CheckMenuItem(wParam, IDM_DRIBBLE, MF_CHECKED);
			  CheckMenuItem(wParam, IDM_DRI_ON, MF_CHECKED);
			  CheckMenuItem(wParam, IDM_DRI_OFF, MF_UNCHECKED);
		       }
		      else
		       {  CheckMenuItem(wParam, IDM_DRIBBLE, MF_UNCHECKED);
			  CheckMenuItem(wParam, IDM_DRI_ON, MF_UNCHECKED);
			  CheckMenuItem(wParam, IDM_DRI_OFF, MF_CHECKED);
		       };

		if (dri_linew)
			CheckMenuItem(wParam, IDM_DRI_LINEW, MF_CHECKED);
		      else
			CheckMenuItem(wParam, IDM_DRI_LINEW, MF_UNCHECKED);
		    
		if (autocopy)
			CheckMenuItem(wParam, IDM_AUTOCOPY, MF_CHECKED);
		      else
			CheckMenuItem(wParam, IDM_AUTOCOPY, MF_UNCHECKED);
		    
		if (storedir)
			CheckMenuItem(wParam, IDM_STOREDIR, MF_CHECKED);
		      else
			CheckMenuItem(wParam, IDM_STOREDIR, MF_UNCHECKED);
		    
		if (marked)
			EnableMenuItem(wParam, IDM_COPY, MF_ENABLED);
		      else
			CheckMenuItem(wParam, IDM_COPY, MF_GRAYED);
		 
		if (page_mode)
			CheckMenuItem(wParam, IDM_PAGE_MODE, MF_CHECKED);
		      else
			CheckMenuItem(wParam, IDM_PAGE_MODE, MF_UNCHECKED);

		 for(i=IDM_FONT+1; i<=IDM_FONT_HI; i++)
		 { if(i == font_nr)
		      CheckMenuItem(wParam,i,MF_CHECKED);
			else
		      CheckMenuItem(wParam,i,MF_UNCHECKED);
		 };
 
	     for(i=10; i<=IDM_FONT_MAX; i=i+2)
		 { 
	    j = i-10 + IDM_FONT_10;
	    if(i == font_size)
		      CheckMenuItem(wParam,j,MF_CHECKED);
			else
		      CheckMenuItem(wParam,j,MF_UNCHECKED);
		 };

	    }
	    return (TRUE);

	case WM_COMMAND:
	    switch (wParam) {
		case IDM_ABOUT:
		    lpProcAbout = MakeProcInstance(About, hInst);
		    DialogBox(hInst, "AboutBox", hWnd, lpProcAbout);
		    FreeProcInstance(lpProcAbout);
		    break;

		case IDM_AUTOCOPY:
		   if(autocopy) autocopy=0; else autocopy=1;
		    break;

		case IDM_STOREDIR:
		   if(!storedir)  
		      { storedir=1;
			write_profile_string("DIR",dir);
		      };
		    break;

		case IDM_DRI_OFF:
		   dribble =0; break;

		case IDM_DRI_ON:
		   if(DriFile) { dribble = 1; break;}

		case IDM_DRI_FILE:
		   lstrcpy(FileName, DriFileName);
		   lpFileDlg = MakeProcInstance((FARPROC) FileDlg, hInst);
		   i = DialogBox(hInst, "DribbleFile", hWnd, lpFileDlg);
		   FreeProcInstance(lpFileDlg);
		   
		   if(i == IDOK)
		   { if(FileName[1] == ':')  /* absolute path? */
			lstrcpy(DriFileName, FileName);
		     else
			{i=0;
			 while(DriFileName[i] = dir[i]) i++;
			 DriFileName[i++] = '\\';
			 j=0;
			 while(DriFileName[i++] = FileName[j++]);
			}
		     if(!filep(DriFileName)
			|| yesp2(DriFileName,"overwrite existing file?"))
		     {DriFile = _lcreat((LPSTR) DriFileName,0);
		       if(DriFile >= 0)
		       {_lclose(DriFile); DriFile = -1;
			 dribble = 1;
		       } 
			else warning("DRIBBLE","cannot create file");
		     }
		       else
		     if(yesp2(DriFileName,"extend existing file?"))
			{ dribble = 1; DriFile = -1;}
		  } 
		  break;

		case IDM_DRI_LINEW:
		  if(dri_linew) dri_linew=0; else dri_linew = 1; break;

	case IDM_PRINT:
	  my_print(); break;

		case IDM_LOADSESSION:
		    warning("WARNING",
			    "all data in memory will be overwritten");
		    load_session();
		    break;  
 

		case IDM_EXIT: 
               /* probeweise 3.10.93 */
           PostMessage(hWnd,WM_DESTROY,0,0);

         /*
		   if(DriFile>0) _lclose(DriFile);
           write_defaults();
	       destroy = 1;
		   PostMessage(hWnd,WM_DESTROY,0,0);
		   beenden(0); 
         */
		 
          break;
  
		/* edit menu commands */

		case IDM_COPY: my_copy(); break;

		case IDM_CCOPY: copy_bitmap(); break; 

		case IDM_PASTE:    my_paste(); break;

		case IDM_FONT_SYS:
	case IDM_FONT_ARIAL:
	case IDM_FONT_COURIER:
	    case IDM_FONT_MODERN:
	    case IDM_FONT_TIMES:    
		   newfont(wParam,0,1); get_geometry(0); break;
 
	case IDM_FONT_10:
	case IDM_FONT_12:
	case IDM_FONT_14:
	case IDM_FONT_16:
	case IDM_FONT_18:
	case IDM_FONT_20:
	case IDM_FONT_22:
	case IDM_FONT_24:
	   newfont(0,10 + wParam - IDM_FONT_10,1);  get_geometry(0); break;

		case IDM_PAGE_MODE: 
		     page_mode = ! page_mode; 
		     update_defaults = 1;    
		     break;
			  
		case IDM_GRAPHICS: 
		     graphics_mode = ! graphics_mode; 
		     update_defaults = 1;     
		     set_graphics_mode(graphics_mode);  
		     break;

    case IDM_SHOW_F: show_f_keys(); break;

	case IDM_F1: case IDM_F2: case IDM_F3: case IDM_F4:
	case IDM_F5: case IDM_F6: case IDM_F7: case IDM_F8:
	case IDM_F9: case IDM_F10: case IDM_F11: case IDM_F12:
	     define_F_key(wParam-IDM_F1+1);
	     break;

	case IDM_HELP: 
		    help_menu();
		     break;
		
	default:
	     if (IDM_HELP < wParam && wParam < IDM_HELP+100) help_do(wParam);

	     return (DefWindowProc(hWnd, message, wParam, lParam));

	    }; 
	    InvalidateRect(hWnd,NULL,TRUE);
	    break;

	case WM_MOUSEMOVE:
	    if (mausdruck) move_pick(LOWORD(lParam),HIWORD(lParam),0);
	    break;

	case WM_RBUTTONDOWN:
	case WM_MBUTTONDOWN: my_paste(); break;

	case WM_LBUTTONDOWN:
	    mausdruck = 1;
	    prevent_caret=1;
	    start_pick(LOWORD(lParam),HIWORD(lParam));
	    break;

	case WM_LBUTTONUP:
	    prevent_caret=0;
	    if(mausdruck)
	      {mausdruck=0;
	       move_pick (LOWORD(lParam),HIWORD(lParam),1);
	      }
	end_pick();
	    break;
	
	case WM_SYSCHAR:
	SetFocus(hWnd);  /* 27.3. neu */
	    if((lParam>>16) & 0x20) 
	      {
		SetFocus(hWnd);
		goto char_in;
	      }
	      break;

	case WM_KEYDOWN:
	if(0x70 <= wParam && wParam<=0x7b)
	    paste_F_key(wParam-0x70+1);
	  else
	    if(wParam==0x11) ctrl=1;
	      else
	    if (wParam == 0x8 || (0x1b <= wParam && wParam <= 0x2e))
		    cursorKey(wParam);
	    break;

	case WM_KEYUP:
	    if(wParam==0x11) ctrl=0;              
	    break;

	case WM_CHAR:
      /* 21.7.93 neu */
	 { unsigned char c;
	   c = (unsigned char)wParam;
	   if (c == 0x03)  /* Ctrl C */ 
	      { my_copy(); break; };
	   if (c == 0x16)  /* Ctrl V */
	      { my_paste(); break; };
       if (c == 0x18)  /* Ctrl X */
          { char_delete(0); break; };
       if (c == 0x7)   /* Ctrl G */
             wParam = 0x1b;  /* Esc, transferred to LISP */
       if (c == 0x1b)  /* Esc - already handled by KEYDOWN */
             break;
	 }  
      char_in:
		 ctrl = 0; 
		 prevent_caret = 0;
		 page_count = 0;
		 state = CALL;

         if(Catch(CatchBuf)) goto destroy;

		 if(HIWORD(lParam) == 0x1c) 
		    { 
		      i = do_char('\n');
		      if(dribble && DriFile>0) 
			{ _lclose(DriFile); DriFile=-1;}
		    }
		   else i = do_char((unsigned char)wParam);

         if(i==0)  goto destroy;
          	
		 state = LOOP;
	    break;

	case WM_VSCROLL:
	     scrollbar(wParam,lParam);
	     break;

	case WM_PAINT:
	    hDC = BeginPaint (hWnd, &ps);
	    if(!during_scroll) 
	{ 
	  SetBkMode(hDC,TRANSPARENT); 
	  if (act_show == act_line) my_refresh(); else  my_showpage(act_show); 
	}
	    EndPaint(hWnd, &ps);
	    break;
	
	case WM_DESTROY: 
       destroy:
         write_defaults();
	     destroy = 1;
	     prevent_caret=1;
	     state = CALL;
	     if(!exitflag) Beenden(0);
	     PostQuitMessage(0);
	    break;

	case WM_ACTIVATE:
	    if(init)
	       {if(wParam == 0) 
		  {  
	     SetWindowText(hWnd,banner);
	     de_select_ext();                  /* 8.5.93 neu */ 
		 state = CALL;
		     IsActive = 0;
		  }
		       else 
		  {
	     set_title(); 
		     IsActive = 1;
		 state = LOOP;
	     SetFocus(hWnd);
		  }
	       };
	  /*  return (DefWindowProc(hWnd, message, wParam, lParam));    */
	     break;
	    

	case WM_SIZE:
	     if(wParam!=SIZEICONIC)
	     {  get_geometry(1);
		InvalidateRect(hWnd,NULL,TRUE);
		psl_msg = psl_msg | PSL_RESIZE;          /* resize message */
		caret_y = act_y;
	     }
	     break;

	case WM_MOVE:
	     org_x = LOWORD(lParam); org_y = HIWORD(lParam);
	     get_geometry(1);
	     break;

	case WM_DDE_ACK:
	     /* my_puts("\n ACK asynchron eingetroffen \n"); */
	case WM_DDE_DATA:
	     /* my_puts("\n DATA asynchron eingetroffen \n"); */
	     dde_ptr++;
	     if(dde_ptr >= MSG_STACK) 
		{ warning("Message system","message buffer overflow");
		  dde_ptr--;
		  break;
		};
	     dde_message[dde_ptr] = message;
	     dde_wParam[dde_ptr]  = wParam;
	     dde_lParam[dde_ptr]  = lParam;
	     break;

	default:
	  def:
	    if(!during_scroll && hWnd == GetFocus() && state==LOOP) caret(1);
	    return (DefWindowProc(hWnd, message, wParam, lParam));
    }
      

    if (PeekMessage(&msg,NULL,WM_PAINT,WM_PAINT,PM_NOREMOVE))
       goto exit;

      /* process paste input */
    if (!during_scroll && hdef_input != NULL)
    {
	LPSTR lpszText;
	char c;

	if (lpszText = GlobalLock(hdef_input)) 
	  {  
	     state = CALL;
	     while(c=*lpszText++) 
	       { int save=insert;
	     /* insert=1;    27.9.93 weggenommen fuer FJW */
	     do_char(c);
	     insert=save;
	   } 
	     GlobalUnlock(hdef_input);
	     GlobalFree(hdef_input);
	     prevent_caret = 0;
	     state = LOOP;
	  } 
	   else warning("paste","impossible");
	hdef_input = NULL;
    }

     /* process eventual deferred input */
    if(during_scroll && ahead_buf[0])
    { char c; int l; 
      l = lstrlen(ahead_buf);
      state = CALL;
      for(i=0;i<l;i++) { c = ahead_buf[i]; ahead_buf[i] =0 ; do_char(c);}
      state = LOOP;
      ahead_buf[0]=0;
    };
	     
    /* process waiting message */
    if(!during_scroll && state == LOOP && !dde_block && dde_ptr>=0) 
    {
      psl_msg = psl_msg | PSL_MESSAGE;          /*  asynchronous message */
      state = CALL;
      my_input("");
      state = LOOP;
    }

    if(!during_scroll  && hWnd==GetFocus() && state==LOOP) caret(1);

exit:
    return (NULL);
}

terminieren(int s)
 {
    write_defaults();
    destroy = 1;
    prevent_caret=1;
    state = CALL;
    if(!exitflag) Beenden(0);
    PostQuitMessage((int)s);
 }

scrollbar(WORD wParam,WORD lParam)                                 
  { if(act_line > wLines)
    switch(wParam)
   {
	case SB_BOTTOM:     my_showpage(act_line); break;
	case SB_LINEDOWN:   my_movepage(1); //my_showpage(act_show + 1);
                        break;
	case SB_LINEUP:     my_movepage(-1); //my_showpage(act_show - 1); 
                        break;
	case SB_PAGEDOWN:   my_showpage(act_show + wLines); break;
	case SB_PAGEUP:     my_showpage(act_show - wLines); break;
	case SB_THUMBPOSITION:
			    my_showpage(lParam); break;
	case SB_TOP:        my_showpage(wLines);
  }}

/****************************************************************************

    FUNCTION: About(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages for "About" dialog box

    MESSAGES:

	WM_INITDIALOG - initialize dialog box
	WM_COMMAND    - Input received

****************************************************************************/

BOOL FAR PASCAL About(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
    switch (message) {
	case WM_INITDIALOG:
	    return (TRUE);

	case WM_COMMAND:
	    if (wParam == IDOK) {
		EndDialog(hDlg, TRUE);
		return (TRUE);
	    }
	    break;
    }
    return (FALSE);
}

set_graphics_mode(char m)
{
     if(m) psl_msg = psl_msg | PSL_GRAPHICS_ON; 
     else  psl_msg = psl_msg | PSL_GRAPHICS_OFF;
}
 
