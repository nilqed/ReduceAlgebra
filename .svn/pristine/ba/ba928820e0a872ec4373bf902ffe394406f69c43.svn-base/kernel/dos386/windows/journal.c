Seit Testers 3.4.2
==================

Fehler  copy-paste, wenn Zeilenpuffer uebergelaufen.  27.3.93

Fehler  Keine Eingabe nach Reaktivierung mit Ctrl/Esc 27.3.93

Total-Schw�rzung bei Reaktivierung

Neu 16.4.93: Funtkion Copy bitmap

Neu 30.4.93: Funktion PRINT

8.5.93  Selektion mit Maus nur wenn mindestens 2 character

28.5.    Tex-Output: beim Blaettern und Refresh (auch print)
        wird die erste nicht mehr vollstaendige Formel noch
        mit gedruckt.

23.7.  F.Wright#s Klagen alle korrigiert in Windows 3.1, ausser
       File/Directory-menu
