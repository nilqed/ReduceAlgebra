/***************************************************************************
  support of unix style pipes
****************************************************************************/

int vorlesen = 0;

HWND hpipe,hparent;

BOOL FAR PASCAL Vorlesen(HWND hwnd,DWORD dummy);

char wndname[50];

HWND pipe_open(LPSTR name)
  { WORD r;
    char name1[50];
    char * c, *d;
    FARPROC lpProc;        
    int subwindow;
    
    c = name; d = name1;
    if (*c == '*') { vorlesen=1; c++;} else vorlesen=0;
    
    while(*c && *c!=';') *d++ = *c++;
    if(!*c) return(0);
    *d = 0; *c++; d=wndname;
    while(*c && *c!=';' ) *d++ = *c++; *d=0;

    r = WinExec(name1,SW_MINIMIZE);      
    if(r<=32 && !vorlesen) return(0);
    
    lpProc = MakeProcInstance(Vorlesen, hInst);
    if(vorlesen) my_puts("current windows are:"); my_newline();
    EnumWindows(lpProc,0);
    hparent = hpipe;
    if (*c == 0) return(hpipe);

    if(vorlesen) my_puts("Childs\n"); 
    /* subwindows name */
    *c++; d=wndname;
    while(*c) *d++ = *c++; *d=0;

    EnumChildWindows(hpipe,lpProc,1);
    ShowWindow(hpipe,SW_HIDE);
    return(hpipe);
  }


pipe_puts(HWND pipe,LPSTR s)
  {
      while(*s) 
	{ if(*s != '\n')
	    SendMessage(pipe,WM_CHAR,*s,MAKELONG(1,0x1e));
	      else
	    SendMessage(pipe,WM_CHAR,0xd,MAKELONG(1,0x1c));
	   s++;
	}

  }

pipe_write(HWND pipe,LPSTR s,long l)
  {
      HWND w; 
     
      while(l>0) 
	{ if(*s != '\n')
	    SendMessage(pipe,WM_CHAR,*s,MAKELONG(1,0x1e));
	      else
	    SendMessage(pipe,WM_CHAR,0xd,MAKELONG(1,0x1c));
	   s++; l--;
	}

      if(w = FindWindow(NULL,"gnuplot graph"))
	  SetWindowText(w,"REDUCE plot");

  }


pipe_close(HWND pipe)
  {
      SendMessage(hparent,WM_DESTROY,0,0);
      hpipe = 0; hparent = 0;   
  }

BOOL FAR PASCAL Vorlesen(HWND hwnd,DWORD dummy)
  {
    char buff1[80];
    char buff2[80];
    int l;

    hpipe = NULL;
    buff2[0]=0;
    l=GetClassName(hwnd,(LPSTR)buff2,80);
    if(vorlesen)  
    {
       my_puts("title:");
       my_puts(buff2); my_newline();
    }
    if(0==lstrcmp(buff2,wndname)) hpipe=hwnd;
    if(hpipe) return(0); else return(1);
  }

