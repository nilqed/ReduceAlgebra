/****************************************************************************
    PURPOSE: Filename Dialog 
*/ 

/* #include "windows.h" */
#include "psllw.h"

 
extern   HANDLE      hInst;
extern   HWND        hWnd;
extern   char        dir[];
extern   LPSTR       banner;
extern   int         storedir;         
	 char        title[120];      
extern   char       *argv[];
extern   char       *iname;
extern   int         ScriptFile;         
	 LPSTR       comment=NULL;
extern   char        ahead_buf[];

/* Additional includes needed for the fstat() function */

#include <sys\types.h>
#include <sys\stat.h>

extern char FileName[];
char DefPath [128];
char ActPath [128];
char  str[128];
char DefSpec[5] = "*.red";
char DefExt[5] = "";
char OpenName[128];

void ChangeDefExt(PSTR Ext, PSTR Name);
void SeparateFile(HWND hDlg, LPSTR lpDestPath, 
		  LPSTR lpDestFileName, LPSTR lpSrcFileName);
void AddExt(PSTR Name,PSTR Ext);
void UpdateListBox(HWND hDlg,int mode);



/****************************************************************************

    FUNCTION: FileDlg(HWND, unsigned, WORD, LONG)

    PURPOSE: Allows user to select a file name

    COMMENTS:

	This will initialize the window class if it is the first time this
	application is run.  It then creates the window, and processes the
	message loop until a PostQuitMessage is received.  It exits the
	application by returning the value passed by the PostQuitMessage.

****************************************************************************/

int FAR PASCAL FileDlg(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
    char TempName[128];
    int name_found;

    switch (message) {
	case WM_INITDIALOG:

		/* Process the path to fit within the IDC_PATH field */

	    if(comment)
	       SetDlgItemText(hDlg, IDC_PATH, comment);
	    else
	       DlgDirList(hDlg, DefPath, NULL, IDC_PATH, 0x4010);

		/* Send the current filename to the edit control */

	    SetDlgItemText(hDlg, IDC_EDIT, FileName);

		/* Accept all characters in the edit control */

	    SendDlgItemMessage(hDlg, IDC_EDIT, EM_SETSEL, 0,
		    MAKELONG(0, 0x7fff));
	    

	    EnableWindow(GetDlgItem(hDlg, IDOK), TRUE);

	    /* Set the focus to the edit control within the dialog box */

	    SetFocus(GetDlgItem(hDlg, IDC_EDIT));
	    return (FALSE);                 /* FALSE since Focus was changed */

	case WM_COMMAND:
	    switch (wParam) {
		case IDC_EDIT:

		    return (TRUE);

		case IDOK:

		    GetDlgItemText(hDlg, IDC_EDIT, FileName, 128);
		    EndDialog(hDlg, IDOK);
		    return (TRUE);

		case IDCANCEL:

		    /* Tell the caller the user canceled the SaveAs function */

		    EndDialog(hDlg, IDCANCEL);
		    return (TRUE);
	    }
	    break;

    }
    return (FALSE);
}

load_session()
   {
    FARPROC lpFileDlg;
    int r;
    lstrcpy(FileName,argv[0]);
    lpFileDlg = MakeProcInstance((FARPROC) FileDlg, hInst);
    r = DialogBox(hInst, "LoadSession", hWnd, lpFileDlg);
    FreeProcInstance(lpFileDlg);
    if(r!=IDOK) return(1);
    if(!filep(FileName)) 
      { warning("Load Session","File not Found"); return(0);}
    iname = FileName;
    if(load_image(1) >=0) my_init();
    }

read_parameter(char* s)
   {
    FARPROC lpFileDlg;
    int r;

    comment = s;
    lpFileDlg = MakeProcInstance((FARPROC) FileDlg, hInst);
    r = DialogBox(hInst, "ReadParameter", hWnd, lpFileDlg);
    FreeProcInstance(lpFileDlg);
    comment = NULL;
    if(r=IDOK) return(1); else return(0);
    }


/*------------------------------------------------------------------
      Directory service
  ------------------------------------------------------------------*/


set_dir()
   {
    dir[0]=Wgdrv()+'A';
    dir[1]=':';
    dir[2]='\\';
    Wgwd(&dir[3]);
    if(!dir[3]) dir[2] = 0;
   }

my_cd(LPSTR pard)
   {
     char c; int dr,r;     
     int l=0;
     char d[128],*q;

     while(d[l]=pard[l]) l++;
 
     if (d[1] == ':')
     { c=d[0];
       if(c < 'Z') dr = c-'A'; else dr = c-'a';
       Wcdrv(dr);
     }
     r = Wcwd(d);
     set_title();  
     storedir = 0;
     return(r);
   }

yesp(LPSTR text1)
   { return(yesp2(text1,(LPSTR) ""));} 
   
LPSTR tx1,tx2;

yesp2(LPSTR text1,LPSTR text2)
   {
    FARPROC lpYespDlg;
    int r;
    
    tx1 = text1;
    tx2 = text2;
    lpYespDlg = MakeProcInstance((FARPROC) YespDlg, hInst);
    r = DialogBox(hInst, "Yesp", hWnd, lpYespDlg);
    FreeProcInstance(lpYespDlg);
    if(r==IDOK) return(1); else return(0); ;
   }

int FAR PASCAL YespDlg(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
    switch (message) {
	case WM_INITDIALOG:


		/* Send the current filename to the edit control */
	    SetDlgItemText(hDlg, IDC_PATH, tx1);
	    SetDlgItemText(hDlg, IDC_EDIT, tx2);
	    EnableWindow(GetDlgItem(hDlg, IDOK), TRUE);
	    SetFocus(GetDlgItem(hDlg, IDC_EDIT));
	    return (FALSE);                 /* FALSE since Focus was changed */

	case WM_COMMAND:
	    switch (wParam) {
		case IDC_EDIT:
		    return (TRUE);

		case IDOK:

		    EndDialog(hDlg, IDOK);
		    return (TRUE);

		case IDCANCEL:

		    /* Tell the caller the user canceled the SaveAs function */

		    EndDialog(hDlg, IDCANCEL);
		    return (TRUE);
	    }
	    break;

    }
    return (FALSE);
}

filep(LPSTR name)
  { int f;
    if((f=_lopen(name,OF_READ))==-1) return(0);
    _lclose(f); return(1);
  }

set_title()
  { int i,j;
    set_dir();
    i = 0;
    for(j=0; dir[j]; j++)  title[i+j] = dir[j];
    title[i+j++]='\\';
    title[i+j++]='.';  title[i+j++]='.'; title[i+j++]='.';
    title[i+j] = '\0';
    SetWindowText(hWnd,title);
  }
		   
askUser(char * question)
   {
    FARPROC lpFileDlg;
    int r;
    comment = question;
    /* FileName[0] = '\0'; */
    lpFileDlg = MakeProcInstance((FARPROC) FileDlg, hInst);
    r = DialogBox(hInst, "AskUser", hWnd, lpFileDlg);
    FreeProcInstance(lpFileDlg);
    return(r == IDOK);
    }




HANDLE FAR PASCAL OpenDlg(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
    WORD index;
    PSTR pTptr;
    HANDLE hFile;

    switch (message) {
	case WM_COMMAND:
	    switch (wParam) {

		case IDC_LISTBOX:
		    switch (HIWORD(lParam)) {

			case LBN_SELCHANGE:
			    /* If item is a directory name, append "*.*" */
			    if (DlgDirSelect(hDlg, str, IDC_LISTBOX)) 
				strcat(str, DefSpec);

			    SetDlgItemText(hDlg, IDC_EDIT, str);
			    SendDlgItemMessage(hDlg,
				IDC_EDIT,
				EM_SETSEL,
				NULL,
				MAKELONG(0, 0x7fff));
			    break;

			case LBN_DBLCLK:
			    goto openfile;
		    }
		    return (TRUE);

		case IDOK:
		    EndDialog(hDlg, NULL);
		    return (TRUE);

openfile:
		    GetDlgItemText(hDlg, IDC_EDIT, OpenName, 128);
		    if (strchr(OpenName, '*') || strchr(OpenName, '?')) {
			SeparateFile(hDlg, (LPSTR) str, (LPSTR) DefSpec,
			    (LPSTR) OpenName);
			if (str[0])
			    strcpy(DefPath, str);
			ChangeDefExt(DefExt, DefSpec);
			UpdateListBox(hDlg,1);
			return (TRUE);
		    }

		    if (!OpenName[0]) {
			MessageBox(hDlg, "No filename specified.",
			    NULL, MB_OK | MB_ICONHAND);
			return (TRUE);
		    }

		    AddExt(OpenName, DefExt);
		    lstrcpy(FileName,OpenName);
		    return (TRUE);

		case IDCANCEL:
		    EndDialog(hDlg, NULL);
		    return (TRUE);
	    }
	    break;

	case WM_INITDIALOG:                        /* message: initialize    */
	    UpdateListBox(hDlg,1);
	    SetDlgItemText(hDlg, IDC_EDIT, DefSpec);
	    SendDlgItemMessage(hDlg,               /* dialog handle      */
		IDC_EDIT,                          /* where to send message  */
		EM_SETSEL,                         /* select characters      */
		NULL,                              /* additional information */
		MAKELONG(0, 0x7fff));              /* entire contents      */
	    SetFocus(GetDlgItem(hDlg, IDC_EDIT));
	    return (FALSE); /* Indicates the focus is set to a control */
    }
    return FALSE;
}


void ChangeDefExt(PSTR Ext, PSTR Name)

{
    PSTR pTptr;

    pTptr = Name;
    while (*pTptr && *pTptr != '.')
	pTptr++;
    if (*pTptr)
	if (!strchr(pTptr, '*') && !strchr(pTptr, '?'))
	    strcpy(Ext, pTptr);
}

void SeparateFile(HWND hDlg, LPSTR lpDestPath, 
		  LPSTR lpDestFileName, LPSTR lpSrcFileName)
{
    LPSTR lpTmp;
    char  cTmp;

    lpTmp = lpSrcFileName + (long) lstrlen(lpSrcFileName);
    while (*lpTmp != ':' && *lpTmp != '\\' && lpTmp > lpSrcFileName)
	lpTmp = AnsiPrev(lpSrcFileName, lpTmp);
    if (*lpTmp != ':' && *lpTmp != '\\') {
	lstrcpy(lpDestFileName, lpSrcFileName);
	lpDestPath[0] = 0;
	return;
    }
    lstrcpy(lpDestFileName, lpTmp + 1);
    cTmp = *(lpTmp + 1);
    lstrcpy(lpDestPath, lpSrcFileName);
     *(lpTmp + 1) = cTmp;
    lpDestPath[(lpTmp - lpSrcFileName) + 1] = 0;
}


void AddExt(PSTR Name,PSTR Ext)

{
    PSTR pTptr;

    pTptr = Name;
    while (*pTptr && *pTptr != '.')
	pTptr++;
    if (*pTptr != '.')
	strcat(Name, Ext);
}

/****************************************************************************

    FUNCTION: CheckFileName(HWND, PSTR, PSTR)

    PURPOSE: Check for wildcards, add extension if needed

    COMMENTS:

	Make sure you have a filename and that it does not contain any
	wildcards.  If needed, add the default extension.  This function is
	called whenever your application wants to save a file.

****************************************************************************/

BOOL CheckFileName(hWnd, pDest, pSrc)
HWND hWnd;
PSTR pDest, pSrc;
{
    PSTR pTmp;
    OFSTRUCT OfStruct;

    if (!pSrc[0])
	return (FALSE);               /* Indicates no filename was specified */

    pTmp = pSrc;
    while (*pTmp) {                     /* Searches the string for wildcards */
	switch (*pTmp++) {
	    case '*':
	    case '?':
		MessageBox(hWnd, "Wildcards not allowed.",
		    NULL, MB_OK | MB_ICONEXCLAMATION);
		return (FALSE);
	}
    }

    AddExt(pSrc, DefExt);            /* Adds the default extension if needed */

    if (OpenFile(pSrc, (LPOFSTRUCT) &OfStruct, OF_EXIST) >= 0) {
	sprintf(str, "Replace existing %s?", pSrc);
	if (MessageBox(hWnd, str, "EditFile",
		MB_OKCANCEL | MB_ICONHAND) == IDCANCEL)
	    return (FALSE);
    }
    strcpy(pDest, pSrc);
    return (TRUE);
}

void UpdateListBox(HWND hDlg,int mode)
   /* mode: 0 = only directories */
{
    strcpy(str, DefPath);
    strcat(str, DefSpec);
    if(mode) DlgDirList(hDlg, str, IDC_LISTBOX, IDC_PATH, 0x4010);
      else   DlgDirList(hDlg, str, IDC_LISTBOX, IDC_PATH, 0xc010);

    /* To ensure that the listing is made for a subdir. of
     * current drive dir...
     */
    if (!strchr (DefPath, ':'))
	DlgDirList(hDlg, DefSpec, IDC_LISTBOX, IDC_PATH, 0x4010);

    /* Remove the '..' character from path if it exists, since this
     * will make DlgDirList move us up an additional level in the tree
     * when UpdateListBox() is called again.
     */
    if (strstr (DefPath, ".."))
	DefPath[0] = '\0';

    SetDlgItemText(hDlg, IDC_EDIT, DefSpec);
}




/*---------------------------------------------------------------------
	 local DPMI interface
  ---------------------------------------------------------------------*/

struct myregs{
    WORD ax;
    WORD bx;
    WORD cx;
    WORD dx;
    WORD si;
    WORD di;} regs;

#define MAX_ALIAS 5
#define MAX_REGIONS 5

int seg_count=0;
int s16_count=0;

long seg_len[MAX_REGIONS] ;
long seg_base[MAX_REGIONS];
long seg_hand[MAX_REGIONS] = {0,0,0,0,0};
WORD seg_desc[MAX_REGIONS] = {0,0,0,0,0};

#define MAX_ALIAS 5
WORD s16_desc[MAX_ALIAS] ={0,0,0,0,0};
long s16_offset[MAX_ALIAS];
WORD s16_alias[MAX_ALIAS] ={0,0,0,0,0};


WORD DESCalloc(int e)
  { int i;
    regs.ax =0;
    regs.cx =1;
    if(int31h(&regs.ax)) mem32err(e+1);
    return(regs.ax);
  }

DESCfree(int i,int e)
  {
    int j;
    regs.ax =1;
    regs.bx =i;
    j=int31h(&regs.ax);
  }

freemem(DWORD hand,int e)
  { 
    int i;
    regs.ax = 0x502;
    regs.si = hand>>16;
    regs.di = hand;
    i=int31h(&regs.ax);
    if(i) warning("ERROR","freemem failed; restart Windows");
  }


DESCsetbase(WORD seg,long base,int e)
  { regs.ax = 0x7;
    regs.bx = seg;
    regs.cx = base>>16;
    regs.dx = base;
    if(int31h(&regs.ax)) mem32err(e+5);
  }

DESCsetlimit(WORD seg,long limit,int e)
  { limit = limit | 0xfff;   /* page aligned */
    regs.ax = 0x8;
    regs.bx = seg;
    regs.cx = limit>>16;
    regs.dx = limit;
    if(int31h(&regs.ax)) mem32err(e+6);
  }
   
DESCsetright(WORD seg,unsigned int right,int e)
   { regs.ax = 0x9;
     regs.bx = seg;
     regs.cx = right;
     if(int31h(&regs.ax)) mem32err(e+7);
  }
     
WORD DESCmk16(int e)
 {  WORD sel;
    long n,sb;
    unsigned int access;
    sel = DESCalloc(e+0x10);
    DESCsetlimit(sel,(long)0xffff,e+0x10);
    access = lar(sel);   /* extract access rights from descriptor */
    access =   (access | 0x0002)   /* not big            */
		       & 0xbff2 ;  /* 0010  data r/w   */
    DESCsetright(sel,access,e+0x10);
    return(sel);
 }

my32Alloc(DWORD n,LPWORD psel,DWORD max,WORD wflags)
  { int i;
    long sb,sh;
    WORD sel;
    unsigned int access;    /* access rights */
    
			    /* align to next page boundary */
    n = ( (n+0xfff) >> 12) << 12;
    regs.ax = 0x501;
    regs.bx = n>>16;
    regs.cx = n & 0xffff;
    i = int31h(&regs.ax);
    if(i) return(1); /* no memory found */
    seg_len[seg_count] = n;
    seg_base[seg_count] = sb= (((unsigned long)regs.bx) << 16) + 
				(unsigned long)regs.cx;
    seg_hand[seg_count] = sh= (((unsigned long)regs.si) << 16) + 
				(unsigned long)regs.di;
    sel = DESCalloc(0x100);

    DESCsetbase(sel,sb,0x100);

    access = lar(sel);   /* extract access rights from descriptor */
				   /* page,big              data r/w */
    access =   (access | 0xc000)   /*            1100 xxxx xxxx 0010 */
		       & 0xfff2 ;  /*            xxxx xxxx xxxx 0010 */
    DESCsetright(sel,access,0x100);
    DESCsetlimit(sel,n-1,0x100);
    seg_desc[seg_count++] = sel;
    *psel = sel;
    return(0);
 }

my32CodeAlias(WORD sel,LPWORD csel,WORD nullum)
 {  int sp;
    long n,sb;
    unsigned int access;

    for(sp=0;sp<seg_count && seg_desc[sp] != sel;sp++);
    if(sp>=seg_count) mem32err(0x200);
    seg_len[seg_count] = n = seg_len[sp];
    seg_base[seg_count] = sb= seg_base[sp];
    seg_hand[seg_count] = 0;
    sel = DESCalloc(0x200);
    DESCsetbase(sel,sb,0x200);
    DESCsetlimit(sel,n-1,0x200);

    access = lar(sel);   /* extract access rights from descriptor */
				   /* page,big              code r   */
    access =   (access | 0xc00a)   /*            1100 xxxx xxxx 1010 */
		       & 0xfffa ;  /*            xxxx xxxx xxxx 1010 */

    DESCsetright(sel,access,0x200);
    seg_desc[seg_count++] = sel;
    *csel = sel;
    return(0);
 }

 my16PointerAlloc(WORD sel,DWORD offset,LPDWORD ptr,DWORD size,WORD nbr)
  {
    int i,d;

    if(d = s16_alias[nbr])
      {if(s16_desc[nbr] == sel &&
	 s16_offset[nbr] == offset) goto ret;
      }
	else 
       d = s16_alias[nbr] = DESCmk16(0x300);
   
    for(i=0;i<seg_count && sel != seg_desc[i];i++);
    if(i>=seg_count) error("base for alias16 not found");
    DESCsetbase(d,seg_base[i]+offset,0x300);
    s16_offset[nbr] = offset;
    s16_desc[nbr] = sel;
  ret:
    *ptr = (long)d << 16;
    return(0);
  }

my16PointerFree(WORD sel,DWORD alias,WORD nullum)
  {return(0);}

my32purge()
  /* give up all memory and descriptors */
  { int i;
    for(i=0;i<MAX_ALIAS;i++)
       if(s16_alias[i]) DESCfree(s16_alias[i],0x400);
    for(i=0;i<MAX_REGIONS;i++)
      {if(seg_desc[i]) DESCfree(seg_desc[i],0x400);
       if(seg_hand[i]) freemem(seg_hand[i],0x400);
      }
    }
       
mem32err(int n)
   {wsprintf(FileName," ***** 32 bit memory error: %x\n",n);
    error(FileName);
   }

#include "winpipes.c"
