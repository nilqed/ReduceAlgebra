/****************************************************************************

****************************************************************************/

/*  #include "windows.h"     */
/*  #include "winmem32.h"    */
#include "psllw.h"

extern  CATCHBUF CatchBuf;
extern  int     init;
extern  LPSTR   CmdLine;
        LPSTR   PSPsel;
        DWORD   env;
        DWORD   h_len=2500000,
                s_len=40000;
        int     h_sel,s_sel,c_sel;
        DWORD   input_buffer;
        WORD    mode = 0;            /* 4711 = image load */
        char    *iname; 
        char    *dname;
extern  int     argc;
extern  char    *argv[];
extern  char    dir[];
extern  char    FileName[];
extern  int     psl_msg;
        LPSTR   environment;
extern  WORD    error_seg,error_adr,error_sptr,code_seg,code32_seg;
extern  int     destroy;

long psl_input(long,int);
long string2long(char*);
long gl_read(int ex,long adr,long siz);

char * pick_env(char * var)
  { 
    char aux[20]; int i=0; char c;
    var++;      /*skip over initial % */
    while((c=var[i]) && c!='%') aux[i++]=c;
    aux[i]=0;   
    FileName[0]=0;
    my_getenv(aux,FileName);
    return(FileName);
  }

long my_start()
   { int i;
     char c;

        /* read directory from windows profile */
     dir[0] = '\0';
     i = GetProfileString((LPSTR)"PSLLW",(LPSTR)"DIR",(LPSTR)"",
         (LPSTR)dir,128);    

        /* pick off PSP segment base */
     (unsigned long)PSPsel = ((unsigned long)CmdLine >> 16)<<16;
     
     environment = (LPSTR)
         ( ( (((long)PSPsel[44]) & 255) +
             (((long)PSPsel[45]) & 255) * 256 
           ) << 16
         );

     if(argc < 0 || (argv[0][0] == '-' && argv[0][1] == 'k')) 
      { mode = 0;
        if(argc>0) iname = argv[1]; 
               else iname = "kern.exp";
        if(argc>1) dname = argv[2]; 
               else dname = "c:\\psl\\nonkern\\dos386\\lap";
      }
         else
      { mode=4711;
        iname = argv[0];
        i = GetProfileString((LPSTR)"PSLLW",(LPSTR)"MEMORY",(LPSTR)"3500000",
            (LPSTR)FileName,128); 
       if(argc>0 && (c=argv[1][0]) && '0'<=c && c<='9')
            h_len = string2long(argv[1]);
              else if(c=='%') h_len = string2long(pick_env(argv[1]));
              else if(c=='&' && read_parameter("memory size"))
                { h_len = string2long(FileName);
                  WriteProfileString  ((LPSTR)"PSLLW",(LPSTR)"MEMORY",
                                       (LPSTR)FileName);
                }
        if(h_len <= 2500000) h_len = 2500000;
             /* melden("hlen",h_len); */

        i = GetProfileString((LPSTR)"PSLLW",(LPSTR)"STACK",(LPSTR)"40000",
            (LPSTR)FileName,128); 
        if(argc>1 && (c=argv[2][0]) && '0'<=c && c<='9')
            s_len = string2long(argv[2]);
              else if(c=='%') s_len = string2long(pick_env(argv[2]));
              else if(c=='&' && read_parameter("stack size"))
                { s_len = string2long(FileName);
                  WriteProfileString  ((LPSTR)"PSLLW",(LPSTR)"STACK",
                                       (LPSTR)FileName);
                }
        if(s_len <= 20000) s_len = 20000;
            /* melden("slen",s_len);  */

      };
     if (my_alloc() <0) return(-1);
     if (mode != 4711) i=load_kern(); else i=load_image(0);
     if (i<0) return(-1);
    
     set_title();
     
     my_init();
   }

/*****************************************************************
     hooks for signal handling
/*****************************************************************/

long signal_table[10];
int  signal_type[10];
int signal_counter = 0;
int fatal_counter = 0;

int terminal_handler  = 0;     /* index to handler for terminal interrupt */

terminalInterrupt()
   {
    if(terminal_handler) 
         lisp_alarm((long) signal_table[terminal_handler],0,0);
    }

                     
my_signalhandler(int i)
   { 
     if(error_seg == code_seg && !destroy)   
     {  
      /*
        melden("alarm in PSLLw code segment:",(long)error_adr);
        melden("code16seg :",(long)code_seg);
        melden("code32seg :",(long)code32_seg);
        melden("errorseg  :",(long)error_seg);
        melden("erroradr  :",(long)error_adr);
        melden("errornr   : ",(long)i);
        melden("type      :",(long)signal_type[i]);
        melden("handler   :",signal_table[i]);
      */
        if(fatal_counter++ >= 5 || destroy) PostQuitMessage(1);
        if(fatal_counter   >= 6) exit(0);
     }
     lisp_alarm((long)signal_table[i],error_sptr,error_adr);
   }

my_csignal(long nr,long adr)
    /* connect interrupt number with handler address */
   { int i;
     if(nr == 0) signal_counter = 0;
     if(nr == 0x1b) terminal_handler = signal_counter;
     i= csignal((int) nr, my_signalhandler, (int) signal_counter * 6);
     if (i !=0)
        {i= csignal2((int) nr, my_signalhandler, (int) signal_counter * 6);
         signal_type[signal_counter] = 2;
        }
          else  signal_type[signal_counter] = 1;
     if (i !=0 ) 
        { melden(" no exception handler accepted for ",nr);
        };
     signal_type[signal_counter] = signal_type[signal_counter] + nr*256;
     signal_table[signal_counter] = adr;
     signal_counter++;
   }

/*****************************************************************
     general subroutines
/*****************************************************************/

long string2long(char * s)
   {char c;
    long l=0; 
    while((c=*s++) && ('0'<=c) && (c<='9')) l = l*10 + (c-'0');
    return(l);
   }
   
char local_string[200];

char * global_to_local_string(DWORD offs)
   /* copy a string from 32 bit memory to local memory */
   { char c; int i,k;
     DWORD ptr16;
     LPSTR strumpf;
     k = my16PointerAlloc(h_sel,offs,(LPDWORD) & ptr16, 0x8000, 0);
     (long)strumpf = (long)ptr16;
     i=0;
     while((c = strumpf[i]) && i<200) 
         { local_string[i] = c; i++; local_string[i] = '\0'; };
     my16PointerFree(h_sel, ptr16,0); 
     return(local_string);
   }

int local_to_global_string(DWORD offs,char ls[],long m)
   /* copy a local string ls to 32 bit memory, max. m bytes */
   { char c; int i,k;
     DWORD ptr16;
     LPSTR strumpf;
     k = my16PointerAlloc(h_sel,offs,(LPDWORD) & ptr16, 0x8000, 0);
     (long)strumpf = (long)ptr16;
     i=0;
     while((c = ls[i]) && i<m) strumpf[i++] = c; strumpf[i] = '\0'; 
     my16PointerFree(h_sel, ptr16,0); 
     return(i);
   }

/*****************************************************************
     memory management
/*****************************************************************/

my_alloc()   
   { int i;
        i= my32Alloc(s_len,(LPWORD)&s_sel,s_len,0);
     /* i= Global32Alloc(s_len,(LPWORD)&s_sel,s_len,0);  */ 
     if (i) return (mem_error(i,"stack alloc:"));
     
     /* GlobalLock(GlobalHandle(s_sel)); */
     i= my32Alloc(h_len,(LPWORD)&h_sel,h_len,0);   
     if (i) return (mem_error(i,"heap alloc:"));
     i=my32CodeAlias(h_sel,(LPWORD)&c_sel,0);
     if(i) return (mem_error(i,"code alias:"));
   }

int beende_count=0;
beenden(int i)
   {   
     if(beende_count) PostQuitMessage(0);
     delete_all_objects();
     my32purge(); my16purge(); 
     beende_count=1;
     schluss(i);
   }

/* hprog:          memory handle from wtex2.c */
/* lpuffer_handle: memory handle for output buffer */

extern HANDLE hprog,lpuffer_handle;

my16purge()
  /* give up dynamic 16 bit memory */
   {     
     LocalUnlock(lpuffer_handle);
     LocalFree(lpuffer_handle);
    if(hprog)
    {
     LocalUnlock(hprog);
     LocalFree(hprog);
    }
   }

/*****************************************************************
     loading of kernel or image
/*****************************************************************/


load_kern()
   { int j,ex; 
     long siz,i,start;
     OFSTRUCT ffstruct;
     char * dir;

     mode = 0;
     ex = _lopen(iname,OF_READ);
     if(ex<=0) {load_error("no kernel found"); return(-1);}
     siz = _llseek(ex,0,2);
     i = _llseek(ex,0,0);
     for (j=0;j<4;j++)_lread(ex,(LPSTR)&start,4);  /* read dword # 4 */
     i = _llseek(ex,start,0);
     i = gl_read(ex,(long)0,(long)(siz - start+1));
     _lclose(ex);
     my_cd ((LPSTR)dname); 
     set_title();
   }

load_image(int m)
  {
   struct hdr_ {
      long magic;
      long heaplast;
      long nextbps;
      long lastbps;
      long lth2;
      long total;
      long start;
      } hdr;
   int ex,i;
   long lw,lf;

     mode = 4711;
     my_puts("loading: "); my_puts(iname); my_newline(); 
     ex = _lopen(iname,OF_READ);
     if(ex<=0) return(load_error("image file not found")); 
     _lread(ex,(LPSTR)&hdr,sizeof(hdr));
     if (hdr.magic != 4713) 
         if(m){warning("load","bad image file");
               return(-1);
              }
             else
               return(load_error("bad image file"));
     if (hdr.lastbps+1000 > h_len)
               return(load_error("image too big for current memory size"));
     lf = gl_read(ex,(long)0,hdr.nextbps+4);
     lf = gl_read(ex,hdr.lastbps, lw = (hdr.heaplast - hdr.lastbps + 4));
     _lclose(ex);
     if(lf < lw)
     { melden("missing bytes in load file:",lw-lf);
       error("image file incomplete");
     }

     return(0);
    }

/*****************************************************************
     binary IO
/*****************************************************************/

long gl_read(int ex,long adr,long siz)
   /* read "siz" bytes from file "ex" into 32bit memory at addr "adr" */
   {long i,count; int k,j; int ii; unsigned int l;
    DWORD offs;
    DWORD ptr16; 
    count = 0;
    for(i=0;i<siz;i=i+ 0x8000)
    { offs = adr + i;
      if(siz-i < 0x8000) j = siz-i; else j = 0x8000;
      k = my16PointerAlloc(h_sel,offs,(LPDWORD) & ptr16, 0x8000, 1);
      if(k != 0) pointer16_error(k,offs);
      l = _lread(ex,(LPSTR)ptr16,j);
      count = count+l;
      my16PointerFree(h_sel, ptr16,0); 
    }
    return(count);
   }

long gl_write(int ex,long adr,long siz)
   /* read "siz" bytes from file "ex" into 32bit memory at addr "adr" */
   {long i,total=0; int k,j; int ii;
    DWORD offs;
    DWORD ptr16; 
    for(i=0;i<siz;i=i+ 0x8000)
    { offs = adr + i;
      if(siz-i < 0x8000) j = siz-i; else j = 0x8000;
      k = my16PointerAlloc(h_sel,offs,(LPDWORD) & ptr16, 0x8000, 2);
      k = _lwrite(ex,(LPSTR)ptr16,j);
      total = total + k;
 //     if(k != j)
 //     { warning("ERROR during write","file system full?");
 //       terminalInterrupt();
 //     }
      my16PointerFree(h_sel, ptr16,0); 
    }
    return(total);
   }


melden(char * s,long x)
  { int i;
    my_puts(s); my_putoct(x); my_newline();
    }

/*****************************************************************
     interface for calling PSL kernel
/*****************************************************************/


long psl_init(long h_len,long s_len,WORD h_sel,WORD s_sel,WORD c_sel,
              WORD env,WORD mode); 

my_init()
   { long i;
        /* melden("calling:",c_sel);   */
     i = psl_init(h_len,s_len,h_sel,s_sel,c_sel,
         (int) (((long)PSPsel)>>16),mode);
     input_buffer = i;
     return(i);
   }

long my_input(s)
     char s[];
   { DWORD ptr16; int i; char c;
     LPSTR strumpf;
     if(input_buffer == NULL) return(0);
     if(i=my16PointerAlloc(h_sel,input_buffer, (LPDWORD)&ptr16, 0x8000,3))
       { melden("no 16 bit Pointer :",(long)i);
         melden("sel:",(long)h_sel);
         warning("PSLLW","error during terminal input");
       }
         else
       {
        (long) strumpf = (long) ptr16;
        i = 0;
        while( strumpf[i] = s[i]) i++;  i--;   
        my16PointerFree(h_sel, ptr16,0);
        input_buffer = psl_input((long)i,psl_msg);
        psl_msg=0;
       };
      return(input_buffer);
   }

/*****************************************************************
     error management
/*****************************************************************/

mem_error(i,s)
    int i; char s[];
    {my_puts("memory request failed; error code ");
     my_putoct((long)i);
     my_puts(" for ");
     my_puts(s);
     my_newline();
     error( "memory request failed");
    }

pointer16_error(int k,long adr)
   {melden("error when allocating 16 bit pointer:",k);
    melden("for 32 bit address:",adr);
    error("32 to 16 address conversion");
   }

error(char * s)
   {warning("ERROR",s);
    beenden(0);
   }

load_error(char * s)
   { warning("LOAD ERROR:",s);
     beenden(0);
   }


schluss(int i)
   {  
    destroy = 1; 
    if (!init) Throw(CatchBuf,1);
    PostQuitMessage(0); 
    }
