/****************************************************************************

***************************************************************************/

/* #include "windows.h"   */
/* #include "winmem32.h"  */
#include "psllw.h"
#include "psllcall.h"

extern DWORD   h_len,s_len;
extern int     h_sel,s_sel,c_sel;
extern DWORD   input_buffer;
extern int     wColumns;
extern HWND    hWnd;
extern int     ctrl;
extern int     storedir;
extern char    FileName[];
extern char    ahead_buf[];
extern char    dde_block;
extern HANDLE  hPageCurs;
extern CATCHBUF CatchBuf;
extern HANDLE  hpipe;
extern int     destroy;

long gl_read (int file,long adr,long size);
long gl_write (int file,long adr,long size); 

melden(char * s,long x);
int            Wdate(LPSTR);
char * global_to_local_string(DWORD str);
pipe_write(HANDLE ,LPSTR ,long);     


long psll_call(p1,p2,p3,p4)
    long p1,p2,p3,p4;
   { DWORD ptr16;
     LPSTR sptr;
     int k; long l;
     char c;
     MSG msg;

        /* first catch envetual BREAK message */
    if(GetInputState()) 
     while(PeekMessage(&msg,NULL,WM_KEYFIRST,WM_KEYLAST,PM_REMOVE)) 
      {
       if ((msg.message ==WM_KEYUP || msg.message == WM_KEYDOWN) 
            &&
               (msg.wParam == 0x13 
             || msg.wParam == 0x3
             || msg.wParam == 0x90
               )) terminalInterrupt();
         else
       if (msg.message ==WM_KEYDOWN && msg.wParam == 0x11) ctrl=1;
         else
       if (msg.message == WM_KEYUP && msg.wParam == 0x11) ctrl=0;
         else
           /* ctrl-C */
       if ((msg.message == WM_KEYDOWN || msg.message == WM_KEYUP)
             && ctrl && msg.wParam == 0x43)
            terminalInterrupt();
         else
           /* other characters: stack for later processing */
       if (msg.message == WM_CHAR)
       {  
         caret(0);
         if(HIWORD(msg.lParam) == 0x1c) c = '\n';
                               else c = (unsigned char)msg.wParam;
         
         k=0;
         while(k<126 && ahead_buf[k]) k++;
         if(k<126) ahead_buf[k++]=c; ahead_buf[k]='\0';
        }
        else
           TranslateMessage(&msg);

      };
     
    /*
      SetTimer(hWnd,17,5,NULL);
      GetMessage(&msg,NULL,WM_TIMER,WM_TIMER);
      KillTimer(hWnd,17);
   */

    switch((unsigned int) p4){
     case YIELD: return(0);      /* only yield */
       
     case PUTS: 
       k = my16PointerAlloc(h_sel,p1,(LPDWORD) & ptr16, 0x8000, 4);
       far_puts(ptr16);
       my16PointerFree(h_sel, ptr16,0);
       break;

     case PUTINT: my_putint((long) p1);  break;
    
     case PUTOCT: my_putoct((long) p1);  break;
   
     case NEWLINE: my_newline(); break;
   
     case PUTC: my_putc((char)p1); break;      /* 5  unixputc */
     
     case BINARYOPENREAD:                        /* 6  binaryopenread */
       k = my16PointerAlloc(h_sel,p1,(LPDWORD) & ptr16, 0x8000, 0);
       k = _lopen((LPSTR)ptr16,OF_READ);
       my16PointerFree(h_sel, ptr16,0);
       if(k <=0) return((long)2); else return((long) k);
       break;
 
     case BINARYOPENWRITE:                        /* 7  binaryopenwrite */
       k = my16PointerAlloc(h_sel,p1,(LPDWORD) & ptr16, 0x8000, 0);
       k = _lcreat((LPSTR)ptr16,0);
       my16PointerFree(h_sel, ptr16,0);
       if(k <= 0) return((long)2); else return((long) k);
       break;
  
     case BINARYCLOSE: 
         if((int) p1 == hpipe) pipe_close((int) p1);
             else  _lclose((int) p1); break;              /* 8 binaryclose */
      
     case BINARYREADBLOCK:                                /* 9 binaryreadblock */
        gl_read((int)p1,p2,p3); break;
     
     case BINARYWRITEBLOCK:                              /* 10 binarywriteblock */
         if((int) p1 == hpipe) 
          pipe_write(hpipe,global_to_local_string(p2),p3);
           else
        return(gl_write((int)p1,p2,p3)); break;  
      
     case GETDATE:                              /* 12 getdate */
       k = my16PointerAlloc(h_sel,p1,(LPDWORD) & ptr16, 0x8000, 0);
       k = Wdate((LPSTR)ptr16);
       my16PointerFree(h_sel, ptr16,0);
       return((long)k);
      
      case  TIMC: return(GetCurrentTime());
      
                                          /* 14 sigset */
      case SIGNAL: my_csignal(p1,p3); break;   
      
      case CD:                            /* 15 cd */
         k=my_cd((LPSTR)global_to_local_string(p1)); 
         return((long)k);
        
     case FGETS:                             /* 16 fgets */
        return(gl_read((int)p1,p2,p3) ); 
   
     case SYSTEM:                             /* 17 system */
        return(WinExec(global_to_local_string(p1),SW_SHOWNORMAL));
    
     case YESP:                             /* 18 yesp  */
        return((long)yesp(global_to_local_string(p1)));
     
     case GETTIME:                             /* 19 gettime (DOS) */
       k = my16PointerAlloc(h_sel,p1,(LPDWORD) & ptr16, 0x8000, 0);
       k = Wtime((LPSTR)ptr16);
       my16PointerFree(h_sel, ptr16,0);
       return((long)k);
      
     case LINELENGTH:
       return((long) local_linelength());      /* get window linelength */
    
     case ASKUSER:                             /* ask user */
        if(askUser(global_to_local_string(p1)))
        return((long)local_to_global_string(p2,FileName,p3));
        else return((long)0);

     case LSEEK:                             /* lseek */
        return(_llseek((int)p1,p2,(int)p3));
     
     case HELP:                             /* help entry */
        my16PointerAlloc(h_sel,p2,(LPDWORD) & ptr16, 0x8000, 0);
        l= psl_help((int)p1,(LPSTR) ptr16);
        return(0);

     case CONNECT_OPEN:                             /* open connection */
        my16PointerAlloc(h_sel,p1,(LPDWORD) & ptr16, 0x8000, 0);
        lstrcpy(FileName,(LPSTR)ptr16);
        return((long) client_open((LPSTR)FileName,
                                  (LPSTR)global_to_local_string(p2)));

     case CONNECT_CLOSE:
        return((long) client_close((HWND)p1));

     case CONNECT_FETCH:
        sptr = (LPSTR)global_to_local_string(p2);
        my16PointerAlloc(h_sel,p3,(LPDWORD) & ptr16, 0x8000, 0);
        return((long) client_fetch((HWND)p1,
                                   (LPSTR)sptr, 
                                   (LPSTR)ptr16));

     case CONNECT_SEND:
        sptr = (LPSTR)global_to_local_string(p2); 
        my16PointerAlloc(h_sel,p3,(LPDWORD) & ptr16, 0x8000, 0);
        return((long) client_send((HWND)p1,
                                  (LPSTR)sptr, 
                                  (LPSTR)ptr16));

     case CONNECT_ASK:
        my16PointerAlloc(h_sel,p2,(LPDWORD) & ptr16, 0x8000, 0);
        k= client_ask((LPSTR)ptr16);
        local_to_global_string(p1,FileName,127);
        return((long)k);

     case CONNECT_BLOCK:
        dde_block = (char) p1;
        return((long) 0);

     case SLEEP:
        return((long)sleep((int)p1));
   
     case PSLL_RESET:
        dde_reset(); 
        main_reset(); 
        break;

     case EXIT_WITH_STATUS:
        Throw(CatchBuf,1);

     case PIPE_OPEN:
        return(pipe_open((LPSTR)global_to_local_string(p1)));
        break;

     case PIPE_CLOSE: 
        return(pipe_close((int)p1));

     default:
        my_puts("psll_call unknown mode:"); my_newline();
        melden("p1:",(long) p1);
        melden("p2:",(long) p2); 
        melden("p3:",(long) p3); 
        melden("p4:",(long) p4); 
        break; 
     }

     return((long)0);
   }


