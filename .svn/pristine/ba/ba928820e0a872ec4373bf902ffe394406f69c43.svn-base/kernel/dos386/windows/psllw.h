#include <windows.h>
#include "pcommon.h"

int PASCAL WinMain(HANDLE, HANDLE, LPSTR, int);
BOOL InitApplication(HANDLE);
BOOL InitInstance(HANDLE, int);
long FAR PASCAL MainWndProc(HWND, unsigned, WORD, LONG);
BOOL FAR PASCAL About(HWND, unsigned, WORD, LONG);

BOOL yesp(LPSTR);
BOOL yesp2(LPSTR,LPSTR);
BOOL filep(LPSTR);
     warning(LPSTR,LPSTR);
    iwarning(LPSTR,long);
int FAR PASCAL YespDlg(HWND, unsigned, WORD, LONG);
int FAR PASCAL HelpDlg(HWND, unsigned, WORD, LONG);

int my32Alloc(DWORD n,LPWORD psel,DWORD max,WORD wflags);
int my32CodeAlias(WORD sel,LPWORD csel,WORD nullum);
int my16PointerAlloc(WORD sel,DWORD offset,LPDWORD ptr,DWORD size,WORD nbr);
my16PointerFree(WORD,DWORD,WORD);

dumpo(LPSTR,int);
long help(long,LPSTR);



/*----------------------------------------------------------------*/


TextOutProp(HDC hDC,int x,int y,LPSTR s,int lth);    
TextOutFix(HDC hDC,int x,int y,LPSTR s,int lth);
