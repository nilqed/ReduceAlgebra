/****************************************************************************

****************************************************************************/

#include "windows.h"
#include "psllw.h"
#include "dde.h"

#define  MAXLIPUFFER        30
#define  MAXLOPUFFER        300    
#define  LINELENGTH         100

CATCHBUF        CatchBuf;
HANDLE          hInst;
HANDLE          hFile;
HWND            hWnd;  
HFONT           hFont=0; 
HDC             hDC; 
int             cHeight=0;                /* character height  */
int             cWidth=0;
int             wLines,wColumns;          /* window size in chars */
int             wpLines,wpColumns;        /* window size in pixels */
int             caret_x,caret_y;
char            overwrite_caret=0,prevent_caret=0;
int             argc;
char           *argv[10];
HANDLE hData, hClipData;                  /* handles to clip data  */
HANDLE hText = NULL;
LPSTR lpData, lpClipData;                 /* pointers to clip data */
HANDLE         hdef_input=NULL;           /* handle for deferred input */
HCURSOR        hSaveCursor, hHourGlass, hArrow, hActCursor, hPageCurs;
int            dribble=0;                 /* dribble file to be written */  
int            dri_linew=0;               /* linewise mode for dirbble file*/
int            dri_cls=1;                 /* dynamic close control */
int            autocopy=1;
int            storedir=1;
char           page_mode=0;
int            page_count=0;
int            mausdruck=0;
int            marked=0;
int            insert=0;                   /* =0 : insert ON */
int            ctrl = 0;                   /* control key pressed */
int            init=0;
char           destroy=0;
int            ScriptFile=0;      /* indicates script mode */
int            exitflag=0;                /* if 1, terminate windows */
int            background=0;
int            psl_msg = 1;               /* messages for PSL */
char           during_paint = 0;
char           has_DC = 0;

	       warning(LPSTR,LPSTR);
	       do_char(char);
char           FileName[128];
char           DriFileName[128] = "reduce.lst";
int            DriFile;
char           dir[128];
char           renv[128] = "\0";
char           ahead_buf[128] = "\0";
LPSTR          banner;

int            font_nr = 0;
int            font_res = 0;  /* indicates that font resource is present */
int            font_height[2], font_width[2];
HFONT          font[2];

int            fancy_xrange,fancy_yrange,fancy_tab,fancy_start=0;
char           fancy_on = 0;
LPSTR          fancy_lines[15];
#define        FANCY '@'


int            act_line=0;     /* actual line for new output */
int            act_show=0;     /* last line of actual display */
int            abs_line=0;     /* absolute line number */

int            org_x=0,org_y=0; /* screen basis */

int            mmm = 0;
char           buffo[255];

far pascal    FileDlg(HWND, unsigned, WORD, LONG);
int           getenv(char *,char *);
long          my_input(char s[]);

WORD          dde_message[MSG_STACK];
WORD          dde_wParam[MSG_STACK];
DWORD         dde_lParam[MSG_STACK];
int           dde_ptr=-1;
char          dde_block=0;            /* prevent against cyclic dde */

int           state = LOOP;
char          IsActive=0;

 /* variables for input/output   */


int act_x=0, act_y=0;
int i_ptr=0; /* input pointer */
int o_ptr=0; 
int po_ptr=0;

    /* buffer for input lines */

int liptr = MAXLIPUFFER;
int licount = MAXLIPUFFER;
char ipuffer[255] = "";
char lipuffer[MAXLIPUFFER][LINELENGTH];

    /* buffer for output lines */

HANDLE  lpuffer_handle;
char * lpuffer_mem;
char * lpuffer[MAXLOPUFFER+1];
char aux[80];


/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

    PURPOSE: calls initialization function, processes message loop

****************************************************************************/

LPSTR CmdLine;

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;
HANDLE hPrevInstance;
LPSTR lpCmdLine;
int nCmdShow;
{
    MSG msg;

    CmdLine = lpCmdLine;

    if (hPrevInstance) return(NULL);
     
    crack(CmdLine);
    
    if (!InitApplication(hInstance))
	    return (FALSE);

    if (!InitInstance(hInstance, nCmdShow))
	return (FALSE);

    while (GetMessage(&msg, NULL, NULL, NULL)) 
    {
	TranslateMessage(&msg);
	DispatchMessage(&msg);
    }
    return (msg.wParam);
}


/****************************************************************************

    FUNCTION: InitApplication(HANDLE)

    PURPOSE: Initializes window data and registers window class

****************************************************************************/

BOOL InitApplication(hInstance)
HANDLE hInstance;
{
    WNDCLASS  wc;

    wc.style = CS_DBLCLKS; 
    wc.lpfnWndProc = MainWndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(hInstance,"psllwrIcon");
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    hArrow = wc.hCursor;
    wc.hbrBackground = GetStockObject(WHITE_BRUSH); 
    wc.lpszMenuName =  "psllMenu";
    wc.lpszClassName = "InputWClass";

    return (RegisterClass(&wc));
}


/****************************************************************************

    FUNCTION:  InitInstance(HANDLE, int)

    PURPOSE:  Saves instance handle and creates main window

****************************************************************************/

BOOL InitInstance(hInstance, nCmdShow)
    HANDLE          hInstance;
    int             nCmdShow;
{


    TEXTMETRIC      textmetric;
    int             nLineHeight;
    LPSTR           b1;
    char            aux[20];
    int             i,j;

    hInst = hInstance;
    LoadAccelerators(hInst,"EditMenuAcc");
    if(argc > 0) banner = argv[0]; else banner = "LISP";
    b1 = banner;
    while (*b1) {if (*b1 == '\\') banner = ++b1; else  b1++;};

    hWnd = CreateWindow(
    "InputWClass",
    banner,
	WS_OVERLAPPEDWINDOW | WS_VSCROLL,  /* horz & vert scroll bars */
	CW_USEDEFAULT,
	CW_USEDEFAULT,
	CW_USEDEFAULT,
	CW_USEDEFAULT,
	NULL,
	NULL,
	hInstance,
	NULL
    );

    if (!hWnd)
	return (FALSE);

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    hHourGlass = LoadCursor(NULL, IDC_WAIT);
    hPageCurs = LoadCursor(hInstance, "pageCursor");

    {
       int x0,x1,y0,y1;

       if((x0=GetProfileInt((LPSTR)"PSLLW",(LPSTR)"WX0",-1)) >=0
	 &&
	  (x1=GetProfileInt((LPSTR)"PSLLW",(LPSTR)"WX1",-1)) >=0
	 &&
	  (y0=GetProfileInt((LPSTR)"PSLLW",(LPSTR)"WY0",-1)) >=0
	 &&
	  (y1=GetProfileInt((LPSTR)"PSLLW",(LPSTR)"WY1",-1)) >=0)
       MoveWindow(hWnd,x0,y0,x1,y1,0);
    }
    dcon();

    hFont = CreateFont(
	 8,   /* 10, */
	 0,   /* 8,  */
	 0,
	 0,
	 FW_NORMAL,
	 FALSE,
	 FALSE,
	 FALSE,
	 ANSI_CHARSET,
	 OUT_DEFAULT_PRECIS,
	 CLIP_DEFAULT_PRECIS,
	 DEFAULT_QUALITY,
	 FIXED_PITCH | FF_MODERN,
	 "System" 
	 );
    if (hFont) SelectObject(hDC, hFont);
       /* font geometry */
    GetTextMetrics(hDC, &textmetric);
    dcoff();
    nLineHeight = textmetric.tmExternalLeading + textmetric.tmHeight;
    cWidth = textmetric.tmMaxCharWidth;
    cHeight = nLineHeight;
      /* window geometry */
    get_geometry(0);

    if(  ((GetVersion() & 0xf) < 3)
	 || !(GetWinFlags()&WF_ENHANCED))    
	error("requires WINDOWS 3 in ENHANCED 386 mode");
    
    if(!getenv("reduce",renv))
	error("environment variable REDUCE not set");

    if(Catch(CatchBuf)) return(FALSE); /* error exit during init */

    my_prepare();

    font_nr = GetProfileInt((LPSTR)"PSLLW",(LPSTR)"FONT",IDM_FONT_SYS);
    if (font_nr <= IDM_FONT || IDM_FONT_HI < font_nr) font_nr = IDM_FONT_SYS;
    if (font_nr != IDM_FONT_SYS) newfont(font_nr,0);      

    page_mode = GetProfileInt((LPSTR)"PSLLW",(LPSTR)"PAGE_MODE",0);

      /* load and initialize LISP module */
    my_start(); 
      /* examine for -i and -o parameters */
    my_mode();
      /* prepare for dialog */
    init = 1;
    
    if(ScriptFile) ScriptIn();

    GetProfileString((LPSTR)"PSLLW",(LPSTR)"DIR",(LPSTR)"",(LPSTR)dir,128);
    if(dir[0]) Wcwd(&dir[0]);
    set_title();    
    IsActive = 1;
    return (TRUE);

}

get_geometry(int save)
  {
    RECT rect; DWORD w;

    if(cHeight==0) return(0);
    GetClientRect(hWnd,&rect);
    wpLines = rect.bottom - rect.top - 15;
    wLines = wpLines / cHeight;
    wpColumns = rect.right - rect.left - 5;
    wColumns = wpColumns / cWidth;
    wColumns = min(99,wColumns);
    if (save)
    {
      w = GetWindowOrg(hDC);
      write_profile("WX0",org_x);
      write_profile("WX1",rect.right-rect.left);
      write_profile("WY0",org_y);
      write_profile("WY1",rect.bottom-rect.top);
     }  
      
  }

/****************************************************************************

    FUNCTION: MainWndProc(HWND, unsigned, WORD, LONG)


    COMMENTS:


****************************************************************************/


long FAR PASCAL MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;
unsigned message;
WORD wParam;
LONG lParam;
{
    FARPROC lpProcAbout;
    PAINTSTRUCT ps;                  /* paint structure              */
    char HorzOrVertText[12];
    char ScrollTypeText[20];
    RECT rect;
    int i,j;
    FARPROC lpFileDlg;
    int Success;                            /* return value from SaveAsDlg() */
    int IOStatus;                           /* result of file i/o      */
       
       caret(0);

       if(Catch(CatchBuf)) 
	  {
	    if(ScriptFile && exitflag) ExitWindows(0,0);
	    message=WM_DESTROY;
	  }
   
/*   
	if(init && message!=15 && message!=20)
	{   my_puts("mess");
	    my_putint((long)message);
	    my_puts(" ");
	    my_putoct((long)wParam);
	    my_puts(" ");
	    my_putoct(lParam);
	    my_puts("\n");
	}
*/

       switch(message){

	case WM_INITMENU:
	    if (wParam == GetMenu(hWnd)) 
	    {
		if (OpenClipboard(hWnd)) 
		{
		    if (IsClipboardFormatAvailable(CF_TEXT)
			|| IsClipboardFormatAvailable(CF_OEMTEXT))
			EnableMenuItem(wParam, IDM_PASTE, MF_ENABLED);
		    else
			EnableMenuItem(wParam, IDM_PASTE, MF_GRAYED);
		    CloseClipboard();
		}    
		if (dribble)
		       {  CheckMenuItem(wParam, IDM_DRIBBLE, MF_CHECKED);
			  CheckMenuItem(wParam, IDM_DRI_ON, MF_CHECKED);
			  CheckMenuItem(wParam, IDM_DRI_OFF, MF_UNCHECKED);
		       }
		      else
		       {  CheckMenuItem(wParam, IDM_DRIBBLE, MF_UNCHECKED);
			  CheckMenuItem(wParam, IDM_DRI_ON, MF_UNCHECKED);
			  CheckMenuItem(wParam, IDM_DRI_OFF, MF_CHECKED);
		       };
		if (dri_linew)
			CheckMenuItem(wParam, IDM_DRI_LINEW, MF_CHECKED);
		      else
			CheckMenuItem(wParam, IDM_DRI_LINEW, MF_UNCHECKED);
		    
		if (autocopy)
			CheckMenuItem(wParam, IDM_AUTOCOPY, MF_CHECKED);
		      else
			CheckMenuItem(wParam, IDM_AUTOCOPY, MF_UNCHECKED);
		    
		if (storedir)
			CheckMenuItem(wParam, IDM_STOREDIR, MF_CHECKED);
		      else
			CheckMenuItem(wParam, IDM_STOREDIR, MF_UNCHECKED);
		    
		if (marked)
			EnableMenuItem(wParam, IDM_COPY, MF_ENABLED);
		      else
			CheckMenuItem(wParam, IDM_COPY, MF_GRAYED);
		 
		if (page_mode)
			CheckMenuItem(wParam, IDM_PAGE_MODE, MF_CHECKED);
		      else
			CheckMenuItem(wParam, IDM_PAGE_MODE, MF_UNCHECKED);

		 for(i=IDM_FONT+1; i<=IDM_FONT_HI; i++)
		 { if(i == font_nr)
		      CheckMenuItem(wParam,i,MF_CHECKED);
			else
		      CheckMenuItem(wParam,i,MF_UNCHECKED);
		 };

	    }
	    return (TRUE);

	case WM_COMMAND:
	    switch (wParam) {
		case IDM_ABOUT:
		    lpProcAbout = MakeProcInstance(About, hInst);
		    DialogBox(hInst, "AboutBox", hWnd, lpProcAbout);
		    FreeProcInstance(lpProcAbout);
		    break;

		case IDM_AUTOCOPY:
		   if(autocopy) autocopy=0; else autocopy=1;
		    break;

		case IDM_STOREDIR:
		   if(!storedir)  
		      { storedir=1;
			WriteProfileString("PSLLW","DIR",dir);
		      };
		    break;

		case IDM_DRI_OFF:
		   dribble =0; break;

		case IDM_DRI_ON:
		   if(DriFile) { dribble = 1; break;}

		case IDM_DRI_FILE:
		   lstrcpy(FileName, DriFileName);
		   lpFileDlg = MakeProcInstance((FARPROC) FileDlg, hInst);
		   i = DialogBox(hInst, "DribbleFile", hWnd, lpFileDlg);
		   FreeProcInstance(lpFileDlg);
		   
		   if(i == IDOK)
		   { if(FileName[1] == ':')  /* absolute path? */
			lstrcpy(DriFileName, FileName);
		     else
			{i=0;
			 while(DriFileName[i] = dir[i]) i++;
			 DriFileName[i++] = '\\';
			 j=0;
			 while(DriFileName[i++] = FileName[j++]);
			}
		     if(!filep(DriFileName)
			|| yesp2(DriFileName,"overwrite existing file?"))
		     {DriFile = _lcreat((LPSTR) DriFileName,0);
		       if(DriFile >= 0)
		       {_lclose(DriFile); DriFile = -1;
			 dribble = 1;
		       } 
			else warning("DRIBBLE","cannot create file");
		     }
		       else
		     if(yesp2(DriFileName,"extend existing file?"))
			{ dribble = 1; DriFile = -1;}
		  } 
		  break;

		case IDM_DRI_LINEW:
		  if(dri_linew) dri_linew=0; else dri_linew = 1; break;

		case IDM_LOADSESSION:
		    warning("WARNING",
			    "all data in memory will be overwritten");
		    load_session();
		    break;  
	   
		case IDM_BACKGROUND:
		    if(background) 
		      background = 0; /* psl_msg=4;}  */
		    else
		      background = 1; /* psl_msg=2;}  */
		    break;

		case IDM_EXIT: 
		   if(DriFile>0) _lclose(DriFile);
	       Throw(CatchBuf,1);
		   PostMessage(hWnd,WM_DESTROY,0,0);
		   beenden(0); 
		   break;
    
		/* edit menu commands */

		case IDM_COPY: my_copy(); break;

		case IDM_PASTE:    my_paste(); break;

		case IDM_CD:  my_cd(); break;

		case IDM_FONT_SYS:
		case IDM_FONT_BF15:
		case IDM_FONT_BF13:
		case IDM_FONT_BF11:
		case IDM_FONT_BF9:
		case IDM_FONT_NF13:
		case IDM_FONT_NF10:
		case IDM_FONT_NF8:
		   newfont(wParam,1); break;

		case IDM_PAGE_MODE: 
		     page_mode = ! page_mode; 
		     if(page_mode) WriteProfileString("PSLLW","PAGE_MODE","1");
			else WriteProfileString("PSLLW","PAGE_MODE","0");       
		     break;

		case IDM_HELP: 
		     /* post this message to hWnd main loop */
		     PostMessage(hWnd,UM_HELP,NULL,NULL);
		     break;
		
		default:
		     return (DefWindowProc(hWnd, message, wParam, lParam));

	    }; 
	    InvalidateRect(hWnd,NULL,TRUE);
	    break;

       case UM_HELP:     
	    state = CALL;
	    psl_help (0,(LPSTR) NULL);
	    state = LOOP;
	    break;

     
	case WM_MOUSEMOVE:
	    if (mausdruck) move_pick(LOWORD(lParam),HIWORD(lParam),0);
	    break;

	case WM_RBUTTONDOWN:
	case WM_MBUTTONDOWN: my_paste(); break;

	case WM_LBUTTONDOWN:
	    mausdruck = 1;
	    prevent_caret=1;
	    start_pick(LOWORD(lParam),HIWORD(lParam));
	    break;

	case WM_LBUTTONUP:
	    prevent_caret=0;
	    if(mausdruck)
	      {mausdruck=0;
	       move_pick (LOWORD(lParam),HIWORD(lParam),1);
	      }
	    break;
	
	case WM_SYSCHAR:
	    if((lParam>>16) & 0x20) 
	      {
		SetFocus(hWnd);
		goto char_in;
	      }
	      break;

	case WM_KEYDOWN:
	    if(wParam==0x11) ctrl=1;
	      else
	    if (wParam == 0x8 || (0x1b <= wParam && wParam <= 0x2e))
		    cursorKey(wParam);
	    break;

	case WM_KEYUP:
	    if(wParam==0x11) ctrl=0;              
	    break;

	case WM_CHAR:  char_in:
		 ctrl = 0;
		 prevent_caret = 0;
		 page_count = 0;
		 state = CALL;
		 if(HIWORD(lParam) == 0x1c) 
		    { 
		      i = do_char('\n');
		      if(dribble && DriFile>0) 
			{ _lclose(DriFile); DriFile=-1;}
		    }
		   else i = do_char((unsigned char)wParam);
		 if(i==0) {Beenden(1); 
			   /* Throw(CatchBuf,1); */
			   PostQuitMessage(0);
			   };
		 state = LOOP;
	    break;

	case WM_VSCROLL:
	     scrollbar(wParam,lParam);
	     break;

	case WM_PAINT:
	    hDC = BeginPaint (hWnd, &ps);
	    my_refresh();
	    EndPaint(hWnd, &ps);
	    break;
	
	case WM_DESTROY:
	     prevent_caret=1;
	     if(!exitflag) Beenden(0);
	     PostQuitMessage(0);
	    break;

	case WM_ACTIVATE:
	    if(init)
	       {if(wParam == 0) 
		  {SetWindowText(hWnd,banner); 
		   caret(0);
		   IsActive = 0;
		  }
		       else 
		  {set_title(); 
		   IsActive = 1;
		  }
	       };
	  /*  return (DefWindowProc(hWnd, message, wParam, lParam));    */
	     break;
	    

	case WM_SIZE:
	     if(wParam!=SIZEICONIC)
	     {  get_geometry(1);
		InvalidateRect(hWnd,NULL,TRUE);
		psl_msg = psl_msg | PSL_RESIZE;          /* resize message */
		caret_y = act_y;
	     }
	     break;

	case WM_MOVE:
	     org_x = LOWORD(lParam); org_y = HIWORD(lParam);
	     get_geometry(1);
	     break;

	case WM_DDE_ACK:
	     /* my_puts("\n ACK asynchron eingetroffen \n"); */
	case WM_DDE_DATA:
	     /* my_puts("\n DATA asynchron eingetroffen \n"); */
	     dde_ptr++;
	     if(dde_ptr >= MSG_STACK) 
		{ warning("Message system","message buffer overflow");
		  dde_ptr--;
		  break;
		};
	     dde_message[dde_ptr] = message;
	     dde_wParam[dde_ptr]  = wParam;
	     dde_lParam[dde_ptr]  = lParam;
	     break;

	default:
	  def:
	    caret(1);
	    return (DefWindowProc(hWnd, message, wParam, lParam));
    }
      
      /* process paste input */
    if (hdef_input != NULL)
    {
	LPSTR lpszText;
	char c;

	if (lpszText = GlobalLock(hdef_input)) 
	  {  
	     state = CALL;
	     while(c=*lpszText++) 
	       do_char(c); 
	     GlobalUnlock(hdef_input);
	     GlobalFree(hdef_input);
	     prevent_caret = 0;
	     caret(1);
	     state = LOOP;
	  } 
	   else warning("paste","impossible");
	hdef_input = NULL;
    }

     /* process eventual deferred input */
    if(ahead_buf[0])
    { char c; int l; 
      l = lstrlen(ahead_buf);
      state = CALL;
      for(i=0;i<l;i++) { c = ahead_buf[i]; ahead_buf[i] =0 ; do_char(c);}
      state = LOOP;
      ahead_buf[0]=0;
    };
	     
    /* process waiting message */
    if(state == LOOP && !dde_block && dde_ptr>=0) 
    {
      psl_msg = psl_msg | PSL_MESSAGE;          /*  asynchronous message */
      state = CALL;
      my_input("");
      state = LOOP;
    }

    caret(1);
    return (NULL);
}

/* Device Context */

dcon()
  { 
    int r;
    if(!during_paint && !has_DC) 
       { hDC = GetDC(hWnd); r=1; has_DC = 1;}  else r=0;
    if (hFont) SelectObject(hDC, hFont);
    return(r);
  }

dcoff()
  { 
    if(!during_paint && has_DC) 
      {
	ReleaseDC(hWnd, hDC); 
	has_DC = 0;
      }
  }
      
/* FONT resources */

char * font_name(int i)
   {
     switch(i) 
     { 
	case IDM_FONT_SYS: return("system");
	case IDM_FONT_BF15: return("BF15"); 
	case IDM_FONT_BF13: return("BF13");
	case IDM_FONT_BV13: return("BV13");
	case IDM_FONT_BF11: return("BF11"); 
	case IDM_FONT_BV11: return("BV11");
	case IDM_FONT_BF9:  return("BF9");
	case IDM_FONT_BV9:  return("BV9");
	case IDM_FONT_NF13: return("NF13");
	case IDM_FONT_NV13: return("NV13");
	case IDM_FONT_NF10: return("NF10");
	case IDM_FONT_NV10: return("NV10");
	case IDM_FONT_NF8:  return("NF8");
	case IDM_FONT_NV8:  return("NV8");
    }
   }

int font_pitch(int i)
   {
     switch(i) 
     { 
	case IDM_FONT_SYS: 
	case IDM_FONT_BF15: 
	case IDM_FONT_BF13:
	case IDM_FONT_BF11:  
	case IDM_FONT_BF9: 
	case IDM_FONT_NF8:            
	case IDM_FONT_NF10:
	case IDM_FONT_NF13:
	    return(FIXED_PITCH);

	case IDM_FONT_BV13:
	case IDM_FONT_BV11: 
	case IDM_FONT_BV9: 
	case IDM_FONT_NV13:
	case IDM_FONT_NV10:
	case IDM_FONT_NV8: 
	    return(VARIABLE_PITCH);
    }  }

newfont(int nr,int save)
   { int i,j;
     char c;
     char * s;
     HFONT font2;
     TEXTMETRIC      textmetric; 
     int sec = 0;

    s = "pslfn.fon";
    if (!font_res && (nr != IDM_FONT_SYS))
    { for(i=0;c=argv[0][i];i++)
      {FileName[i] = c;
       if(c=='\\') j=i;
      }
      j++;
      while(FileName[j++] = *s++);
      if(!filep(FileName)) warning("cannot open font file:",FileName);
      j = AddFontResource(FileName);
      if(!j)
	warning("cannot activate font resource:",FileName);
	else font_res=1;
    }  
    font_nr = nr;
    hFont = load_font(font_name(nr),FIXED_PITCH);
    if(save) write_profile("FONT",nr);
    
    dcon();
       /* font geometry */
    GetTextMetrics(hDC, &textmetric);
    dcoff();
    caret_x = caret_x / cWidth; 
    caret_y = caret_y / cHeight;
    cHeight = textmetric.tmExternalLeading + textmetric.tmHeight;
    cWidth = textmetric.tmMaxCharWidth;
font[0] = hFont;
font_height[0] = cHeight;    
font_width[0] = cWidth;
font[1] = hFont;
font_height[1] = cHeight;    
font_width[1] = cWidth;
    caret_x = caret_x * cWidth;  
    caret_y = caret_y * cHeight;  
     
 /* load proportional fonts   */
    if(nr == IDM_FONT_SYS) ; else
    if(nr == IDM_FONT_BF15) 
	prop_fonts(IDM_FONT_BF15,IDM_FONT_BF13); else
    if(nr == IDM_FONT_BF13) 
	prop_fonts(IDM_FONT_BV13,IDM_FONT_BV11); else
    if(nr == IDM_FONT_BF11) 
	prop_fonts(IDM_FONT_BV11,IDM_FONT_BV9); else
    if(nr == IDM_FONT_BF9) 
	prop_fonts(IDM_FONT_BV9,IDM_FONT_BV9); else 
    if(nr == IDM_FONT_NF13) 
	prop_fonts(IDM_FONT_NV13,IDM_FONT_NV10); else 
    if(nr == IDM_FONT_NF10) 
	prop_fonts(IDM_FONT_NV10,IDM_FONT_NV8); else 
    if(nr == IDM_FONT_NF8) 
	prop_fonts(IDM_FONT_NV8,IDM_FONT_NV8); else 
    InvalidateRect(hWnd,NULL,TRUE);  

   }
    
prop_fonts(int f1,int f2)    
   {
    HANDLE hfnt;
    TEXTMETRIC      textmetric;   

    if(f1 == font_nr) goto font2;

    hfnt = load_font(font_name(f1),font_pitch(f1));
    if(!hfnt) return(0);
    font[0] = hfnt; font[1] = hfnt;
    dcon();
    SelectObject(hDC,font[0]);
    GetTextMetrics(hDC, &textmetric);
    dcoff();
    font_height[0] = textmetric.tmExternalLeading + textmetric.tmHeight;
    font_width[0] = textmetric.tmMaxCharWidth;
    font_height[1] = font_height[0];
    font_width[1] = font_width[0];
    if(f1 == f2) return(0);
  font2:
    hfnt = load_font(font_name(f2),font_pitch(f2));
    if(!hfnt) return(0);
    font[1] = hfnt;
    dcon();
    SelectObject(hDC,font[1]);
    GetTextMetrics(hDC, &textmetric);
    dcoff();
    font_height[1] = textmetric.tmExternalLeading + textmetric.tmHeight;
    font_width[1] = textmetric.tmMaxCharWidth;
   }

load_font(char * name,int pitch)
   {
    HFONT fnt;
    
    fnt = CreateFont(
	 8,   /* 10, */
	 0,   /* 8,  */
	 0,
	 0,
	 FW_NORMAL,
	 FALSE,
	 FALSE,
	 FALSE,
	 ANSI_CHARSET,
	 OUT_DEFAULT_PRECIS,
	 CLIP_DEFAULT_PRECIS,
	 DEFAULT_QUALITY,
	 pitch | FF_MODERN,
	 name
	 );
    if(!fnt) warning("font not found:",name);
    return(fnt);
    }



my_prepare()
  {int i,j;
    for(i=0;i<255;i++) ipuffer[i]='\0';
      /* create output buffer */
    lpuffer_handle = LocalAlloc(LMEM_FIXED,(LINELENGTH+1)*(MAXLOPUFFER+1));
    if(!lpuffer_handle) warning("cannot allocate output buffer","");
    lpuffer_mem=LocalLock(lpuffer_handle);

    for(i=0;i<MAXLOPUFFER+1;i++)
     {lpuffer[i] = lpuffer_mem+(i*(LINELENGTH+1));
      for(j=0;j<LINELENGTH;j++) lpuffer_mem[i*(LINELENGTH+1)+j] = ' ';
      lpuffer_mem[i*(LINELENGTH+1)+LINELENGTH] = 0;
     }
   }

cursorKey(WORD key)
    {int i,loc;
     PAINTSTRUCT ps; 

      switch(key)
       {
	 case 0x8:     /* backspace */
	
	    if (i_ptr==0) break;
	    i_ptr--;
	    for(i=i_ptr;i<LINELENGTH;i++) 
		ipuffer[i] = ipuffer[i+1];
	    ipuffer[LINELENGTH] = '\0';
	    caret_x = caret_x - cWidth;
	  break;
	 
	 case 0x2e:    /* del */
	    for(i=i_ptr;i<LINELENGTH;i++) 
		ipuffer[i] = ipuffer[i+1];
	    ipuffer[LINELENGTH] = '\0';
	  break;  
	 
	 case 0x2d:    /* ins  (toggle) */
	    insert = !insert;
	 /*
	    for(i=99;i>i_ptr;i--)
		ipuffer[i]=ipuffer[i-1];
	    ipuffer[i_ptr] = ' ';
	 */
	 break;

	 case 0x25:     /* <- */
	    if(i_ptr == 0) break;
	    i_ptr--;
	    caret_x = caret_x - cWidth;
	 break;
	 
	 case 0x24:     /* home */
	    while(i_ptr > 0) 
	    { i_ptr--; caret_x = caret_x - cWidth;}
	 break;

	 case 0x27:     /* -> */
	    if(i_ptr >= wColumns || ipuffer[i_ptr] == '\0') break;
	    i_ptr++;
	    caret_x = caret_x + cWidth;
	 break;

	 case 0x23:     /* end */
	    while(i_ptr < wColumns && ipuffer[i_ptr] != '\0')
	    { i_ptr++; caret_x = caret_x + cWidth;}
	 break;

	 case 0x1b:     /* esc */
	    while(i_ptr > 0) 
	    { i_ptr--; 
	      ipuffer[i_ptr] = '\0';
	      caret_x = caret_x - cWidth;}
	 break;
	    

	 case 0x26:     /* up */
	    if(liptr > licount)
	    { liptr--;
	      for(i=0;i<LINELENGTH;i++)
		  ipuffer[i] = lipuffer[liptr][i];
	      caret_x = caret_x - cWidth * i_ptr;
	      i_ptr = 0;
	    };
	 break;

	 case 0x28:     /* down */
	    if(liptr < MAXLIPUFFER)
	    { liptr++;
		for(i=0;i<LINELENGTH;i++)
		if(liptr < MAXLIPUFFER)
		  ipuffer[i] = lipuffer[liptr][i];
		    else
		  ipuffer[i] = '\0';
	      caret_x = caret_x - cWidth * i_ptr;
	      i_ptr = 0;
	    }
	 break;

	 case 0x21:     /* Pgup */
	    if (act_show <= wLines || act_line <= wLines) break;
	    my_showpage(act_show - wLines);
	    break;
	 
	 case 0x22:     /* Pgdown */
	    my_showpage(act_show + wLines);
	    break;


	 default:
	   return(0);
       }
       show_inputline();
    }

scrollbar(WORD wParam,WORD lParam)                                 
  { if(act_line > wLines)
    switch(wParam)
   {
	case SB_BOTTOM:     my_showpage(act_line); break;
	case SB_LINEDOWN:   my_showpage(act_show + 1); break;
	case SB_LINEUP:     my_showpage(act_show - 1); break;
	case SB_PAGEDOWN:   my_showpage(act_show + wLines); break;
	case SB_PAGEUP:     my_showpage(act_show - wLines); break;
	case SB_THUMBPOSITION:
			    my_showpage(lParam); break;
	case SB_TOP:        my_showpage(wLines);
  }}
     
show_inputline()
    {
	int i,j;
	my_flush();
	for(i=0; i<LINELENGTH && ipuffer[i] && ipuffer[i]!='\n'; i++); 
	dcon(); 
	if(lpuffer[act_line][0])
	     TextOut(hDC,0,act_y,lpuffer[act_line],o_ptr);
	TextOut(hDC,o_ptr*cWidth,act_y,ipuffer,i);
	for(j=o_ptr+i;j<wColumns;j=j+10)
	   TextOut(hDC,j * cWidth,act_y, "          ",10);
	dcoff();
	caret_y=act_y; 
		       /* hier falsch, weil cursor mitten im Text stehen kann
		       /*     caret_x=(o_ptr+i)*cWidth; /*hierrr*/
	return(i);
     }


my_paste()
      {
      LPSTR lpszText;
      char c;
      int i,l;

    if (OpenClipboard(hWnd)) {
	/* get text from the clipboard */
	if (!(hClipData = GetClipboardData(CF_TEXT))) {
	    CloseClipboard();
	    return(0);
	}
	l =  GlobalSize(hClipData);

	if (hText != NULL) {GlobalFree(hText);}
	if (!(hText = GlobalAlloc(GMEM_MOVEABLE,l)))
		       {
			    warning("paste","OutOfMemory");
			    CloseClipboard();
			    return(0);
			}
	
	if (!(lpszText = GlobalLock(hText)))       
		       {  warning("paste","no lock");
			  CloseClipboard();
			  return(0);
		       }

	if (!(lpClipData = GlobalLock(hClipData))) {
			    warning("paste","noClipData");
			    CloseClipboard();
			    return(0);
			}
	lstrcpy(lpszText,lpClipData);
	
	GlobalUnlock(hClipData);
	
	CloseClipboard();
	
	GlobalUnlock(hText);
	hdef_input = hText;
	hText = NULL;
	return (TRUE);
		    }
    else
	return (FALSE);
	    }

RECT rect;
int sel_x,sel_y,s_x,s_y;

start_pick(int x,int y)
   { x = x/cWidth;
     y = y/cHeight;
     my_showpage(act_show);
     mach_schwarz(x,y);
     s_x = sel_x = x;
     s_y = sel_y = y;
   }

move_pick(int x,int y,int m)
   { int xx,yy;
     x = x/cWidth;
     y = y/cHeight;
     if(y!=s_y || (y==s_y && x<s_x) || y<sel_y) 
     {my_showpage(act_show);   /*moved backwards: refresh screen */
      s_x = sel_x; s_y = sel_y;
      mach_schwarz(s_x,s_y);
     }
     for(yy=s_y;yy<=y;yy++)
      for(xx=0;xx <wColumns;xx++)
       if ( (xx > s_x || yy > s_y)
	  &&(xx <= x || yy < y)  )
	    mach_schwarz(xx,yy);
     s_x = x;
     s_y = y;
     if(m==0) return(0);
     marked = 1;
     if(autocopy) my_copy();
   }

dbl_pick(int x,int y,int m)
   { int b;
     b = max(0,act_line - wLines +1); /* base */
     s_x = sel_x = x;
     s_y = sel_y = y;
     my_showpage(act_show);
     mach_schwarz(x,y);
     if(wordp(lpuffer[x][b+y]))
     {
	while(sel_x>0 && wordp(lpuffer[b+y][sel_x-1]) )
	    {sel_x--; mach_schwarz(sel_x,y);}
	while(s_x<wColumns && wordp(lpuffer[b+y][s_x+1]) )
	    {s_x++; mach_schwarz(s_x,y);}
     }
     marked = 1;
     if(autocopy) my_copy();
   }

int wordp(char c)
   {return ( ('A' <= c && c <= 'Z')
	   ||('a' <= c && c <= 'z')
	   ||('0' <= c && c <= '9')
	   ||(c == '_') );}

mach_schwarz(int x,int y)
  {  x = x*cWidth;
     y = y*cHeight;
     rect.top = y;
     rect.bottom = y + cHeight;
     rect.left = x;
     rect.right = x + cWidth;
     InvertRect(hDC,&rect);
   }

my_copy()
	  {
    LPSTR lpData;
    int l,b,xx,yy;
    HANDLE hData;
    if(!marked) return(0);
    
       /* compute length of text */
    if (sel_y == s_y) l = s_x - sel_x +1;
	else          l = wColumns - sel_x +3              /* first line */
			+ (s_y - sel_y -1)*(wColumns+3)    /* full lines */
			+ s_x +1;                          /* last line  */
    if (l<=0) return(0);

	/* Allocate memory and copy the string to it */
    if (!(hData = GlobalAlloc(GMEM_MOVEABLE, l+1))) 
       { warning("Copy:","out of Memory"); return (TRUE);} 
    if (!(lpData = GlobalLock(hData))) 
       {warning("copy:","lock data");return (TRUE);}
	/* move character to data buffer */
    b = max(0,act_show - wLines +1); /* base */ 
    for(yy=sel_y;yy<=s_y;yy++)
     {for(xx=0;xx <wColumns;xx++)
       if ( (xx >= sel_x || yy > sel_y)
	  &&(xx <= s_x || yy < s_y)  )
	    *lpData++ = lpuffer[b+yy][xx];
      if(yy<s_y){*lpData++ = 0xd; *lpData++ = 0xa;} 
     };
    *lpData++ = '\0';
    GlobalUnlock (hData);

	/* Clear the current contents of the clipboard, and set
	 * the data handle to the new string.
	 */

     if (OpenClipboard(hWnd)) {
	    EmptyClipboard();
	    SetClipboardData(CF_TEXT, hData);
	    CloseClipboard();
	} else warning("unable","to set Clipboard");
     hData = NULL;
     marked = 0;        

    }
	
do_char(char c)
     {long i;
      int j,k,l;
   
      if(c != '\n' && c<' ') return(1);
      liptr = MAXLIPUFFER;
      if(act_line != act_show) my_showpage(act_line);

     if(c != '\n')
     { 
       if (!insert)
	{   for(i=254;i>i_ptr;i--)
		ipuffer[i]=ipuffer[i-1];
	    ipuffer[i_ptr] = ' ';
	 }
       
       if (o_ptr + i_ptr < wColumns) 
	  { ipuffer[i_ptr] = c; 
	    i_ptr++;
	  } 
	  
       if (o_ptr + i_ptr < wColumns)   
	  {
	    caret_x = caret_x + cWidth;
	    l = show_inputline();
	    return(1);
	  }
     };
      
      l = show_inputline();
      if(c == '\n') ipuffer[l]  = '\n';  else ipuffer[l] = '\0';
      ipuffer[l+1] = '\0';
      insert = 0;

       /* save input line */
       licount=max(licount--,0);
       for(j=licount;j<MAXLIPUFFER-1; j++)
	    for(k=0;k<LINELENGTH;k++) lipuffer[j][k] = lipuffer[j+1][k];
       for(k=0;k<l;k++) 
	      lpuffer[act_line][o_ptr+k] = lipuffer[MAXLIPUFFER-1][k] 
					 = ipuffer[k];
					 
       for(k=l;k<LINELENGTH;k++) lipuffer[MAXLIPUFFER-1][k] = '\0';
       o_ptr = o_ptr+l;
       overwrite_caret = 1;
       my_putc('\n');
       overwrite_caret = 0;
	 
	 /* process the line, surrounded by the hourglass symbol */
       i_ptr = 0;
  
       hSaveCursor = SetCursor(hHourGlass);
       if(background) CloseWindow(hWnd);

       dri_cls = 0;
       state = CALL;
       i = my_input(ipuffer);
       state = LOOP;
       dri_cls = 1;
       hActCursor=SetCursor(hSaveCursor);
       if(hActCursor!=hHourGlass) SetCursor(hActCursor);
  
       for (j=0; j<LINELENGTH; j++) ipuffer[j] = '\0';
       if (i==0) return(0); else return(1);
     }

main_reset()
     {  
	hSaveCursor = hArrow;
	SetCursor(hArrow);
     }

/*******************************************************************
	 graphical display services
/*******************************************************************/

int draw_x,draw_y,fancy_line=-1;

fancy_display(int line,int mode,int yy)
   {
     int i,b,initial,free_y;

     initial = (mode == 1);

     /* decode and compute ranges */
     fancy_line = -1; /* lock refresher */
     /* b = max(0,act_show - wLines +1); /* base */ 
     
     /* find the line buffer */ 
     fancy_lines[0] = &lpuffer[line][2]; 
     fancy_lines[1] = 0;
     for(i=1; i<15 && line+i<=act_line && lpuffer[line+i][0]==0;i++)
	 {
	    fancy_lines[i] = & lpuffer[line+i][1];
	    fancy_lines[i+1] = 0;
	  };
     
	  /* close current line and set terminators */
     if(initial)
     { 
       fancy_on=1; my_putc('\n'); my_putc(0); my_putc(0); fancy_on=0;
       yy = yy - cHeight; line--; /* neu */
     }
     
     fancy_decode(initial);
   
     draw_y = yy; /*  (line-b) * cHeight;   */
     free_y = (act_line-line) * cHeight;
 y_range:    
     if(initial && free_y < fancy_yrange)
	{  
	   fancy_on = 1; my_putc('\n'); my_putc(0); my_putc(0); fancy_on =0;
	   draw_y = draw_y - cHeight; free_y = free_y + cHeight;
	   goto y_range;
	}

     /* x range: use tab or center expression */
     if(!fancy_tab ||( (draw_x = fancy_tab*cWidth) + fancy_xrange > wpColumns))
	    draw_x = (wpColumns - fancy_xrange)/2;

     /* start drawing */
     fancy_draw();
     if(initial) fancy_line = abs_line;    /* initial call ? */
	  else fancy_line = 0;
   }


/* 
  characters:
    font 0:     standard size
    font 1:     exponent size
    charset 0:  ascii 
    charset 1:  Greek
    charset 2:  math symbols
*/

inquire_char_box(int * coords,char c,int charset,int ffont)
     /* inquire surrounding box for character */
   {
      int d,fh;
      d=dcon(); 
      fh = font_height[ffont];
      coords[0] = 0; coords[1] = 0;        /* x0,y0 */ 
      if(ffont==0) SelectObject(hDC, font[0]);
	      else SelectObject(hDC, font[1]);
      if(charset == 0 || charset == 1)
      { 
	GetCharWidth(hDC,c,c,&coords[2]);    /* x1,y1 */
	coords[3]=fh;
      }
	else
      if(charset == 2)
      {
	if(c=='I' || c=='S')   /* integral,sum */
	{  coords[2] = font_width[ffont];
	   if(c=='S')  coords[2] = 2*font_width[ffont];
	   coords[3] = 2*fh; coords[1] = -fh;
	}
      }
      if(hFont) SelectObject(hDC, hFont);
      if(d) dcoff();
   }

draw_string(int x,int y,char *c,int lth,int charset,int ffont)
     /* put character to screen */
   {
      int d;

      if(charset == 2) return draw_math(x,y,c,ffont);
      d=dcon(); 
      if(ffont==0) SelectObject(hDC, font[0]);
	      else SelectObject(hDC, font[1]);
      
      if(charset == 1) 
      { 
	if(*c == 'p') *c = 227;   /* pi */
      }
      TextOut(hDC,x+draw_x,y+draw_y,c,lth);
      SelectObject(hDC, hFont);
      if(d) dcoff();
   }

draw_math(int x,int y,char c,int ffont)
     /* put math symbol to screen */
   {
      int d,w,h;

      w = font_width[ffont]; h = font_height[ffont];
      x = x+draw_x; y = y+draw_y;

      d = dcon();
      if(ffont==0) SelectObject(hDC, font[0]);
	      else SelectObject(hDC, font[1]);
      
      if(c == 'I')
      { 
	 
	 c = 0xf4; TextOut(hDC,x,y-h,(LPSTR)&c,1);   
	 c = 0xb3; TextOut(hDC,x,y,(LPSTR)&c,1);
	 c = 0xf5; TextOut(hDC,x,y+h,(LPSTR)&c,1);   
      }
      else if (c == 'S')
      {
	y = y - h/2;
	MoveTo(hDC,x+w+w,y);
	LineTo(hDC,x,y);
	LineTo(hDC,x+w,y=y+h);
	LineTo(hDC,x,y=y+h);
	LineTo(hDC,x+w+w,y);
      }
      if(hFont) SelectObject(hDC, hFont);
      if(d) dcoff();
   }

draw_brack(int x,int y0,int y1,char c,int ffont)
     /* put large bracket to screen */
   {
      int d,h,p,w,x0,x1,ym,r,round,left;
	    
	  /* use font for standard sizes */
      if((y1-y0)<=font_height[ffont]+1)
	   return(draw_string(x,y0,&c,1,0,ffont));

      d=dcon(); 
    
      round = c == '(' || c == ')';
      left  = c == '(' || c == '{';
      x=x+draw_x; y0=y0+draw_y; y1=y1+draw_y; 
      p = font_height[ffont]; w = font_width[ffont];           
      if (round) p = p/3; else p = p/4;
      
      if(left) { x0 = x+ w; x1 = x; }
	  else { x0 = x; x1 = x+ w; }
      x = x + w/2; 
      ym = y0 + (y1-y0)/2;

      for(r=0;r<2;r++)
      {
	MoveTo(hDC,x0+r,y0);
	LineTo(hDC,x+r,y0+p);
	if(!round)
	{ 
	  LineTo(hDC,x+r,ym-p);
	  LineTo(hDC,x1+r,ym);
	  LineTo(hDC,x+r,ym+p);
	}
	LineTo(hDC,x+r,y1-p);
	LineTo(hDC,x0+r,y1);
      }
      if(d) dcoff();
   }


draw_line(int x0,int y0,int x1, int y1)
     /* put line to screen */
   {
     int d,dx,dy;
     d=dcon();
     MoveTo(hDC,x0+draw_x,y0+draw_y);
     LineTo(hDC,x1+draw_x,y1+draw_y);
   /*  
       if(y0 == y1) {dy=1;dx=0;} else {dy=0;dx=1;}
       MoveTo(hDC,x0+draw_x+dx,y0+draw_y+dy);
       LineTo(hDC,x1+draw_x+dx,y1+draw_y+dy);
   */
     if(d) dcoff();
   }
/*******************************************************************
	 display services
/*******************************************************************/

dumpo(LPSTR txt,int l)
  {int i;
   for(i=0;i<l;i++) 
       {my_putoct(((long)txt[i])&0xff);
	if(!((i+1)&7)) my_putc(' ');
       }
   my_newline();
  }

my_putoct(l)
   long l;
   { wsprintf(aux,"%lx ",l); 
     my_puts(aux);
     my_flush();}

my_putint(l)
   long l;
   { wsprintf(aux,"%ld ",l); 
     my_puts(aux);
     my_flush(); }


my_puts(s)
     char s[];
     {int i=0; unsigned char c;
      while(c = s[i++]) my_putc(c);
      my_flush();
     }

far_puts(s)
     LPSTR s;
     {int i=0; unsigned char c;
      lstrcpy(buffo,s);
      while(c = buffo[i++]) my_putc(c);
      my_flush();
     }
      
      
my_newline()
     {my_putc('\n');
      my_flush();
     }


my_putc(c)
     unsigned char c;
     {int i;
      char cc;

      c = c & 0xff;

      if(act_line != act_show) my_showpage(act_line);
     
      if(c == FANCY)
      { if(!fancy_on) 
	 { 
	   fancy_on = 1;
	   fancy_start=act_line+1;
	   my_putc('\n');
	 }
	else 
	 { 
	   fancy_on = 0;
	   return(fancy_display(fancy_start,1,
				act_y-cHeight*(act_line-fancy_start)));
	 }
      }
 
      if (c=='\n' || o_ptr>=(LINELENGTH-1) || (!fancy_on && o_ptr>=wColumns)) 
	 {my_flush();
	    
	 if(page_mode && page_count++ > (wLines-2))
	    {wait_keyboard(); page_count=0;};
	  
	  if(fancy_on) cc = 0; else cc=' ';
	  for (i=o_ptr; i< LINELENGTH; i++) 
	      lpuffer[act_line][i]=cc; /* fill line*/
	      lpuffer[act_line][LINELENGTH] = 0;
	  if(dribble) dribble_line((char*)lpuffer[act_line],o_ptr,dri_cls);
	  o_ptr = po_ptr = 0; 
	  caret_x = 0;
	  act_y = act_y + cHeight;
	  caret_y = act_y;
	  act_line ++; abs_line ++;  act_show ++;  /* show line hier neu*/
	  if(act_line >= wLines) my_scrollup();
	  if(fancy_on) lpuffer[act_line][o_ptr++] = 0;
	 };

      if ((c>= ' ' && c< 0xff) || c==0)
	 {lpuffer[act_line][o_ptr]=c; o_ptr++;}
     }

my_flush()
    {
	  if(po_ptr == o_ptr || fancy_on) return(0);
	  dcon();  
	 if(lpuffer[act_line][0])   /* dont display fancy data */
	  TextOut(hDC,(po_ptr) * cWidth,act_y,
		      &lpuffer[act_line][po_ptr],
		      o_ptr-po_ptr+1);
	  dcoff();
	  po_ptr = o_ptr;
	  caret_x = o_ptr * cWidth;
	  return(1);
     }


dribble_line(char * l,int i,int cls)
     { 
	
	if(DriFile<0) 
	  { DriFile = _lopen((LPSTR) DriFileName,OF_WRITE);
	    _llseek(DriFile,(long)0,2);      /* go to the end */
	    if(!DriFile<0) warning("dribble","cannot open file");
	  }
	_lwrite(DriFile,(LPSTR)l,i);
	_lwrite(DriFile,(LPSTR)"\015\012",2);
	if(cls || dri_linew) 
	  { _lclose(DriFile); DriFile = -1;}
     }

 my_scrollup()
    {int i,j;
    if(act_line > MAXLOPUFFER-1)
    { 
      char * lp0;
      lp0 = lpuffer[0];
      for(i=0;i<MAXLOPUFFER;i++) lpuffer[i]=lpuffer[i+1];
      lpuffer[MAXLOPUFFER] = lp0;
      act_line--; fancy_start--; 
    }
     for(j=0;j<wColumns;j++) lpuffer[act_line][j]= ' ';
     ScrollWindow(hWnd,0, -cHeight,NULL,NULL);
     act_y=act_y - cHeight;
     caret_x = 0; 
     caret_y = act_y;
     act_show = act_line;
     SetScrollRange(hWnd,SB_VERT,min(act_line-1,wLines),act_line,0);
     SetScrollPos(hWnd,SB_VERT,act_line,1);
       /* redisplay last line */
     if(overwrite_caret) 
      {  
	dcon();    
	if(lpuffer[act_line-1][0])
	  TextOut(hDC,0,act_y - cHeight,lpuffer[act_line-1],wColumns);
	dcoff();
      };
    }
     
my_refresh()
    {int i,j,v,b;
     during_paint = 1;
     if (hFont) SelectObject(hDC, hFont); 
     act_y=0;
     b = max(0,act_line - wLines +1); /* base */
     act_show = act_line;  
     for(i=b;i<=act_line;i++)
	  { if(lpuffer[i][0])
	       TextOut(hDC,0,act_y,lpuffer[i],wColumns); 
	    else if(lpuffer[i][1] == FANCY) fancy_display(i,2,act_y);
	   act_y=act_y + cHeight;};
     act_y=act_y - cHeight;
     if (i_ptr != 0) show_inputline();
     SetScrollPos(hWnd,SB_VERT,act_line,1);
     during_paint = 0;
    }

my_showpage(n)
   /* display previous page with bottom line n */
    {int i,j,v,b;
     clear_screen();
     dcon();
     act_y=0;
     if(n>act_line) n= act_line;
     b = n - wLines +1; /* base */
     if (b<0) {n = min(n-b,act_line); b=0;}
     act_show = n;
     for(i=b;i<=n;i++)
	  { if(lpuffer[i][0])
	       TextOut(hDC,0,act_y,lpuffer[i],wColumns); 
	    else if(lpuffer[i][1] == FANCY) fancy_display(i,2,act_y);
	   act_y=act_y + cHeight;};
     act_y=act_y - cHeight;
     dcoff();
     SetScrollPos(hWnd,SB_VERT,n,1);
     if(n == act_line && i_ptr !=0 ) show_inputline();
    }

clear_screen()
  {
     HBRUSH  hBrush;
     RECT rect;
     int d;
     d=dcon();

     hBrush = CreateSolidBrush(0x00ffffff);
     rect.left = 0; rect.top = 0;
     rect.bottom = wpLines+15; rect.right = wpColumns+5;
     FillRect(hDC,&rect,hBrush);
     if(d) dcoff();
  }

/****************************************************************************

    FUNCTION: About(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages for "About" dialog box

    MESSAGES:

	WM_INITDIALOG - initialize dialog box
	WM_COMMAND    - Input received

****************************************************************************/

BOOL FAR PASCAL About(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
    switch (message) {
	case WM_INITDIALOG:
	    return (TRUE);

	case WM_COMMAND:
	    if (wParam == IDOK) {
		EndDialog(hDlg, TRUE);
		return (TRUE);
	    }
	    break;
    }
    return (FALSE);
}


/*-------------------------  help system entry ---------------------*/

void MakePathName(FileName,extens)
char * FileName; char * extens;
{
   char *  pcFileName;
   int     nFileNameLen;

   nFileNameLen = GetModuleFileName(hInst,FileName,128);
   pcFileName = FileName + nFileNameLen;

   while (pcFileName > FileName) {
       if (*pcFileName == '\\' || *pcFileName == ':') {
	   *(++pcFileName) = '\0';
	   break;
       }
   nFileNameLen--;
   pcFileName--;
   }

   if ((nFileNameLen+13) < 128) {
       lstrcat(FileName, extens);
   }

   else {
       lstrcat(FileName, "?");
   }

   return;
}

psl_help (int mode, LPSTR topic)
  {
    MakePathName(FileName,"help.hlp");
    if (mode == 0) WinHelp(hWnd,FileName,HELP_INDEX,0L);
	 else      WinHelp(hWnd,FileName,HELP_KEY,(DWORD)topic);
  } 

/*------------------------------------------------------------------*/


char speicher[255];
 
crack(LPSTR cline)
   {int j; char c;
    argc = j = 0;
    if(cline[0]=='\0') {argc=-1; return(0);};
  loop:  
    argv[argc] = & speicher[j];
    while((c = cline[j]) != ' ' 
		    && c != '\0' 
		    && c != 0x0d 
		    && c != 0x0a 
		    && j <= 255)
	 { speicher[j] = c; j++;};
    speicher[j] = '\0';
    j++;
    if (argc<10 && j<255 && c!=0x0d && c!=0x0a && c!='\0') 
    { argc++; goto loop;};
   }

my_mode()
   /* evaluate special command line parameters */
   { int i; char c;
     for(i=0;i<=argc;i++)
      if(argv[i][0] == '-' && argv[i][2] == '\0')
       { c= argv[i][1];
	if(c == 'x' || c == 'X') exitflag = 1;
	   else
	if(c == 'o' || c == 'O') 
	  {lstrcpy(DriFileName, argv[i+1]);
	   DriFile = _lcreat((LPSTR) DriFileName,0);
	   if(DriFile >= 0) {_lclose(DriFile); dribble = 1;}
		 else warning("cannot open file",argv[i+1]);
	  }
	    else
	if(c == 'i' || c == 'I')
	  {ScriptFile = _lopen((LPSTR) argv[i+1],OF_READ);
	   if(ScriptFile < 0) 
	     { warning("cannot open file",argv[i+1]);
	       ScriptFile = 0;
	     }
	   SetWindowText(hWnd,argv[i+1]);  /* insert as title */
	  }
       }
    }

ScriptIn()
   /* drive session from script file */
   {int i,l,r;
    char b[128];
    r=1; l=128;
  
   while(r && l==128)
   { l = _lread(ScriptFile,b,128);
     i=0; while(i<l && (r=do_char(b[i++])));
   }
   _lclose(ScriptFile);
   ScriptFile = 0;
   if(exitflag) ExitWindows(0,0);
   }

char caret_an=0;

caret(int mode)
  { if (mode && prevent_caret) return(0);
    if (mode==caret_an || !IsActive) return(0);
    if(ScriptFile) return(0);   /* do not display caret then */
    if(mode) 
    { if(insert) CreateCaret(hWnd,NULL,cWidth,cHeight);
	 else    CreateCaret(hWnd,1,cWidth,cHeight);
      SetCaretPos(caret_x,caret_y);
      /* SetCaretBlinkTime(200) */;
      ShowCaret(hWnd);
    }
     else DestroyCaret();
     caret_an=mode;
  }

write_profile(char* title,int nr)     
  { char text[10];
     /* save number */
    text[0] = '0' + nr/1000;
    text[1] = '0' + (nr/100)%10;
    text[2] = '0' + (nr/10)%10;
    text[3] = '0' + nr % 10;
    text[4] = '\0';
    WriteProfileString((LPSTR)"PSLLW",(LPSTR)title,text); 
  }

/***************** function getenv ************************************/
 
int getenv(char * var, char * val)
  { int i;
    char c;
    char d;
    LPSTR env;
    int found=0;
    d = 'a' - 'A';

    env = GetDOSEnvironment();
    if(!env) return(0);
    while(*env!=0x01 && !found)
    {
       i=0;
       while(var[i] &&  (    var[i] == env[i]
			  || var[i]+d == env[i]
			  || var[i] == env[i]+d
			)
	  ) i++;
	  
       if(!var[i] && env[i] == '=') found=i+1;
	 else
	    while(*env++);  /* skip */
    }
    if(!found) return(0);
    env = &env[found];
    while(*val++ = *env++);
    return(1);
  }

warning(LPSTR head,LPSTR s)
  {MessageBox(GetFocus(),s,head,
	 MB_ICONASTERISK | MB_OK); }

iwarning(LPSTR head,long i)
  {wsprintf((LPSTR)buffo,"%lx",i);
   warning(head,(LPSTR) buffo);
  }
