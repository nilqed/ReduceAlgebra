
/****************************************************************************

****************************************************************************/

#include "windows.h"
#include "xredgraf.h"
#include "stdio.h"
#include "dde.h"

#define  MAXLIPUFFER        30
#define  MAXLOPUFFER        100    

HANDLE          hInst;
HANDLE          hFile;
HWND            hWnd;  
HWND            hWndClient;
HWND            hWndOK,hWndTopic;
HFONT           hFont; 
HDC             hDC; 
int             textBase=0;
int             cHeight=0;                /* character height  */
int             cbHeight=0;
int             cWidth=0;
int             wLines,wColumns;          /* window size in chars */
int             wpLines,wpColumns;        /* window size in pixels */       
int             wpMin;
int             argc;
char           *argv[10];
HANDLE hData, hClipData;                  /* handles to clip data  */
HANDLE hText = NULL;
LPSTR          lpClipData;                 /* pointers to clip data */
DDEDATA FAR   *lpData;
HANDLE         hdef_input=NULL;           /* handle for deferred input */
HCURSOR        hSaveCursor, hHourGlass;

int            act_line,act_show;
int            insert=0;
char          *banner;
int            ctrl=0;
int            saved=0;
int            plotted=0;
int            redraw=0;

char           itemText[128];
char           sendpuffer[128];
char           atomtext[128];
char           FileName[128];
char           renv[255];
char           buffo[128];
RECT           text_rect;
HBITMAP        bitmap=NULL;

char           cbuffer[6000];


int act_x=0, act_y=0;
int i_ptr=0; /* input pointer */
int o_ptr=0; 
int po_ptr=0;


int liptr = MAXLIPUFFER;
int licount = MAXLIPUFFER;
char lpuffer_mem[MAXLOPUFFER+1][100];
char * lpuffer[MAXLOPUFFER+1];
char ipuffer[255];
char lipuffer[MAXLIPUFFER][100];
char aux[80];

char   editBuf[40];

int getenv( char * var, char * val);
 

/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

    PURPOSE: calls initialization function, processes message loop

****************************************************************************/

LPSTR CmdLine;

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;
HANDLE hPrevInstance;
LPSTR lpCmdLine;
int nCmdShow;
{
    MSG msg;
    HWND hPrev;

    CmdLine = lpCmdLine;

    if (hPrevInstance) return(NULL);
     
    crack(CmdLine);
    
    if (!InitApplication(hInstance))
	    return (FALSE);

    if (!InitInstance(hInstance, nCmdShow))
	return (FALSE);

    while (GetMessage(&msg, NULL, NULL, NULL)) 
    {
	TranslateMessage(&msg);
	DispatchMessage(&msg);
    }
    return (msg.wParam);
}


/****************************************************************************

    FUNCTION: InitApplication(HANDLE)

    PURPOSE: Initializes window data and registers window class

****************************************************************************/

BOOL InitApplication(hInstance)
HANDLE hInstance;
{
    WNDCLASS  wc;

    wc.style = CS_DBLCLKS || CS_SAVEBITS; 
    wc.lpfnWndProc = MainWndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(hInstance,"graphIcon"); 
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = GetStockObject(WHITE_BRUSH); 
    wc.lpszMenuName =  "xredgrafMenu";
    wc.lpszClassName = "RgrafWClass";

    return (RegisterClass(&wc));
}


/****************************************************************************

    FUNCTION:  InitInstance(HANDLE, int)

    PURPOSE:  Saves instance handle and creates main window

****************************************************************************/

BOOL InitInstance(hInstance, nCmdShow)
    HANDLE          hInstance;
    int             nCmdShow;
{


    TEXTMETRIC      textmetric;
    int             nLineHeight;
    LPSTR           b1;
    char            aux[20];
    int             i,j;
    RECT            rect;
    int             nwidth=400,nheight=400;
    char c;
    char * s;

    
    hInst = hInstance;
    
    if(argc > 0) banner = argv[0]; else banner = "Wgraph";
    b1 = banner;
    while (*b1) {if (*b1 == '\\') banner = ++b1; else  b1++;};
    banner = "Reduce Graphics";

    hWnd = CreateWindow(
    "RgrafWClass",
    banner,
	WS_OVERLAPPEDWINDOW,  
	CW_USEDEFAULT,
	CW_USEDEFAULT,
	nwidth,
	nheight,
	NULL,
	NULL,
	hInstance,
	NULL
    );

    if (!hWnd)
	return (FALSE);

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    hHourGlass = LoadCursor(NULL, IDC_WAIT);

    getenv("reduce",renv);

    hDC = GetDC(hWnd);

    j=0;
    lstrcpy(FileName,renv); 
    s ="\\exe\\pslfn.fon";
    lstrcat(FileName,s);    
    j = AddFontResource(FileName); 
    if(!j)
	s = "System"; 
      else
	s = "PSL3";

    hFont = CreateFont(
	 8,   /* 10, */
	 0,   /* 8,  */
	 0,
	 0,
	 FW_NORMAL,
	 FALSE,
	 FALSE,
	 FALSE,
	 ANSI_CHARSET,
	 OUT_DEFAULT_PRECIS,
	 CLIP_DEFAULT_PRECIS,
	 DEFAULT_QUALITY,
	 FIXED_PITCH | FF_MODERN,
	 s 
	 );
    if (hFont) SelectObject(hDC, hFont);

       /* font geometry */
    GetTextMetrics(hDC, &textmetric);
    i=ReleaseDC(hWnd, hDC);
    nLineHeight = textmetric.tmExternalLeading + textmetric.tmHeight;
    cbHeight = textmetric.tmHeight;
    cWidth = textmetric.tmMaxCharWidth;
    cHeight = nLineHeight;
      /* window geometry */
    get_geometry();
    return (TRUE);

}

get_geometry()
  {
    RECT rect;
    if(cHeight==0) return(0);
    GetClientRect(hWnd,&rect);
    wpLines = rect.bottom - rect.top;
    if(cHeight>0) wLines = wpLines / cHeight;
    wpColumns = rect.right - rect.left;
       /* create a bitmap for saving */
    if(cWidth>0) wColumns = wpColumns / cWidth;
    wpMin = min(wpColumns,wpLines);
  }

/****************************************************************************

    FUNCTION: MainWndProc(HWND, unsigned, WORD, LONG)


    COMMENTS:


****************************************************************************/


long FAR PASCAL MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;
unsigned message;
WORD wParam;
LONG lParam;
{
    FARPROC lpProcAbout;
    PAINTSTRUCT ps;                  /* paint structure              */
    char HorzOrVertText[12];
    char ScrollTypeText[20];
    RECT rect;
    int i,j,l;
    FARPROC lpFileDlg;
    int Success;                            /* return value from SaveAsDlg() */
    int IOStatus;                           /* result of file i/o      */
       
       
    ATOM atomApplication, atomTopic, atomItem;


       switch(message){

	case WM_DDE_INITIATE:
	    hWndClient = wParam;
	    atomApplication = LOWORD(lParam);
	    atomTopic = HIWORD(lParam);

		 /* this application addressed? */
	    if (GlobalGetAtomName(atomApplication,itemText,128)
	       && (0==lstrcmp(itemText,"ReducePlot"))
	       && GlobalGetAtomName(atomTopic,itemText,128)
	       && (0==lstrcmp(itemText,"Plot")))
	   {
	    atomApplication = GlobalAddAtom("ReducePlot");
	    atomTopic = GlobalAddAtom("Plot");
	    SendMessage(hWndClient, 
			    WM_DDE_ACK,
			    hWnd,  /* server */
			    MAKELONG(atomApplication,atomTopic));
	    GlobalDeleteAtom(atomApplication);
	    GlobalDeleteAtom(atomTopic);
	    cbuffer[0] = '\0';
	   }
	   break;

	case WM_DDE_REQUEST:
	   hWndClient = wParam;
	   atomItem = HIWORD(lParam);
	   GlobalGetAtomName(atomItem,itemText,128);

	   if(0==lstrcmp(itemText,"HANDSHAKE"))
		   lstrcpy(sendpuffer,"OK");
	     else
	   lstrcpy(sendpuffer,"don't know which item to send");
 
	   if(!(hData = GlobalAlloc(GMEM_MOVEABLE | GMEM_DDESHARE,
		 (long)sizeof(DDEDATA) + strlen(sendpuffer) + 2)))
		 break;
	   if(!(lpData = (DDEDATA FAR *)GlobalLock(hData)))
	     {GlobalFree(hData); break;}
	   lpData->cfFormat = CF_TEXT;
	   lstrcpy((LPSTR)lpData->Value,(LPSTR)sendpuffer);
	   GlobalUnlock(hData);
	   SendMessage(hWndClient,
			    WM_DDE_DATA,
			    hWnd, 
			    MAKELONG(hData, atomItem));
	   break;

	case WM_DDE_POKE:
	   hWndClient = wParam;
	   atomItem = HIWORD(lParam);
	   GlobalGetAtomName(atomItem,itemText,128);
	   hData = LOWORD(lParam);
	   if(!(lpData = (DDEDATA FAR *)GlobalLock(hData)))
	     {GlobalFree(hData); break;}
	   PostMessage(hWndClient,WM_DDE_ACK,
			    hWnd, MAKELONG(0x8000, 0));
	   receive_message((char*)itemText,(LPSTR)lpData->Value);
	   GlobalUnlock(hData);
	   GlobalFree(hData);
	   GlobalDeleteAtom(atomItem);
	   return(1);

       case WM_DDE_TERMINATE:
	   PostQuitMessage(0);
	   break;

	case WM_COMMAND:
	    switch (wParam) 
	    {

		case IDM_EXIT:
		   PostQuitMessage(0);
		   break;
		   
		case IDM_SAVE:
		   save_screen();
		   break;
		    
		case IDM_RESTORE:
		   restore_screen();
		   break;

		default:
		     return (DefWindowProc(hWnd, message, wParam, lParam));

	    }; 
	    break;

     
	case WM_MOUSEMOVE:
	    break;
	
	case WM_CHAR:
	    break;

	case WM_MOVE:
	case WM_SIZE:
	    get_geometry() ;
	    redraw = 1;
	    break;
	    
	case WM_ACTIVATE:
	    if(wParam) redraw=1;
	    return (DefWindowProc(hWnd, message, wParam, lParam));
 
	case WM_PAINT:
	    hDC = BeginPaint (hWnd, &ps); 
	    EndPaint(hWnd, &ps); 
	    if(!IsIconic(hWnd) && redraw) 
	    { redraw = 0;
	      send_message("REDRAW","",0);
	    }
	    break;
	
	default:
	    return (DefWindowProc(hWnd, message, wParam, lParam));
    }
	
    return (NULL);
}

send_message(char * token, char * text, int mode)
{  ATOM atomItem;
   atomItem = GlobalAddAtom(token);
	   lstrcpy(sendpuffer,text);
	   if(!(hData = GlobalAlloc(GMEM_MOVEABLE | GMEM_DDESHARE,
		 (long)sizeof(DDEDATA) + strlen(sendpuffer) + 2)))
		 return(0);
	   if(!(lpData = (DDEDATA FAR *)GlobalLock(hData)))
	     {GlobalFree(hData); return(0);}
	   lpData->cfFormat = CF_TEXT;
	   lstrcpy((LPSTR)lpData->Value,(LPSTR)sendpuffer);
	   GlobalUnlock(hData);
       if(mode)
	   SendMessage(hWndClient,
			    WM_DDE_DATA,
			    hWnd, 
			    MAKELONG(hData, atomItem));
	 else
	   PostMessage(hWndClient,
			    WM_DDE_DATA,
			    hWnd, 
			    MAKELONG(hData, atomItem));

 }

LPSTR gtext;

receive_message(char* item,LPSTR text)
  {
    int i,l;
    char field[20];
    if (0 == lstrcmp(item, "PLOT")) 
      { if(text[0] >'9'
	    && text[0] != 'e'
	    && text[1] != 'n'
	    && text[2] != 'd'
	    )  /* Must be a command */
	  if(cbuffer[0]) 
	  { 
	    if(IsIconic(hWnd)) ShowWindow(hWnd,SW_SHOWNORMAL);
	    BringWindowToTop(hWnd);
	    hDC = GetDC(hWnd);
	    plot0(cbuffer); 
	    ReleaseDC(hWnd,hDC);
	    cbuffer[0] = '\0';
	    plotted = 1;
	    redraw = 0;
	  }
	  lstrcat(cbuffer,text);
      }
       else
    if (0 == lstrcmp(item, "CLOSE")) PostQuitMessage(0);
       else
	 warning("unknown command received",item);
  }

crackoff_number()
   { int l=0;
     char c;
     while(*gtext == ' ') gtext++;
     while((c = *gtext) 
	   && '0' <= c
	   && c <= '9' ) 
       {l=l*10 + (c-'0'); gtext++;}
     while(*gtext == ' ') gtext++;
     return(l);
   }

crackoff_name(char name[])
   { int i=0;
     char c;
     while(*gtext == ' ') gtext++;
     while((c = *gtext) != ' ') 
       {name[i++]=c; gtext++;}
     name[i] = '\0';
     while(*gtext == ' ') gtext++;
   }

    /*
picture()
  { float xf,yf;
    int   xi,yi;
    int i;
    float f;
    POINT pp[10];
    HANDLE pen=NULL,brush=NULL;
    int fil;

    fil =_lopen((LPSTR)argv[0],OF_READ);
    if (fil==-1)
      {warning("no input file:", argv[0]);
       PostQuitMessage(1);
      }
    plot(fil);
    _lclose(fil);
    return(0);
  }
     
  */

save_screen()
   {
    HDC hmDC;
    HBITMAP obm;
return(0);
    if(!plotted) return(0);
    if (bitmap) DeleteObject(bitmap);
    hDC = GetDC(hWnd);
    bitmap = CreateCompatibleBitmap(hDC,wpColumns,wpLines);
    hmDC = CreateCompatibleDC(hDC);
    obm = SelectObject(hmDC,bitmap);
    BitBlt(hmDC,0,0,wpColumns,wpLines,hDC,0,0,PATCOPY);
    SelectObject(hmDC,obm);
    DeleteDC(hmDC);
    saved = 1;
    ReleaseDC(hWnd, hDC);
	      
    warning("nach","sichern");
   }

restore_screen()
   {
    HDC hmDC;
    HBITMAP obm;
return(0);      
    if(!saved) return(0);
    warning("vor","restaurieren");
    hDC = GetDC(hWnd);
    hmDC = CreateCompatibleDC(hDC);
    obm = SelectObject(hmDC,bitmap);
    BitBlt(hDC,0,0,wpColumns,wpLines,hmDC,0,0,PATCOPY);
    SelectObject(hmDC,obm);
    DeleteDC(hmDC);
    saved = 1;
    ReleaseDC(hWnd, hDC);
	      
    warning("nach","restaurieren");
   }

/***************** function getenv ************************************/
 
int getenv(char * var, char * val)
  { int i;
    char c;
    char d;
    LPSTR env;
    int found=0;
    d = 'a' - 'A';
    *val = '\0';

    env = GetDOSEnvironment();
    if(!env) return(0);
    while(*env!=0x01 && !found)
    {
       i=0;
       while(var[i] &&  (    var[i] == env[i]
			  || var[i]+d == env[i]
			  || var[i] == env[i]+d
			)
	  ) i++;
	  
       if(!var[i] && env[i] == '=') found=i+1;
	 else
	    while(*env++);  /* skip */
    }
    if(!found) return(0);
    env = &env[found];
    while(*val++ = *env++);
    return(1);
  }

/****************************************************************************

    FUNCTION: About(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages for "About" dialog box

    MESSAGES:

	WM_INITDIALOG - initialize dialog box
	WM_COMMAND    - Input received

****************************************************************************/

BOOL FAR PASCAL About(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
    switch (message) {
	case WM_INITDIALOG:
	    return (TRUE);

	case WM_COMMAND:
	    if (wParam == IDOK) {
		EndDialog(hDlg, TRUE);
		return (TRUE);
	    }
	    break;
    }
    return (FALSE);
}

char speicher[255];
 
crack(LPSTR cline)
   {int j; char c;
    argc = j = 0;
    if(cline[0]=='\0') {argc=-1; return(0);};
  loop:  
    argv[argc] = & speicher[j];
    while((c = cline[j]) != ' ' 
		    && c != '\0' 
		    && c != 0x0d 
		    && c != 0x0a 
		    && j <= 255)
	 { speicher[j] = c; j++;};
    speicher[j] = '\0';
    j++;
    if (argc<10 && j<255 && c!=0x0d && c!=0x0a && c!='\0') 
    { argc++; goto loop;};
   }

warning(LPSTR head,LPSTR s)
  {MessageBox(GetFocus(),s,head,
	 MB_ICONASTERISK | MB_OK); }



