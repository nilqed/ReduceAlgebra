#define IDM_ABOUT 100

/* file menu items */

#define     IDM_DRIBBLE      101
#define     IDM_SAVE         103
#define     IDM_RESTORE      104
#define     IDM_EXIT         105

int PASCAL WinMain(HANDLE, HANDLE, LPSTR, int);
BOOL InitApplication(HANDLE);
BOOL InitInstance(HANDLE, int);
long FAR PASCAL MainWndProc(HWND, unsigned, WORD, LONG);
BOOL FAR PASCAL About(HWND, unsigned, WORD, LONG);

BOOL yesp(LPSTR);
BOOL yesp2(LPSTR,LPSTR);
BOOL filep(LPSTR);
     warning(LPSTR,LPSTR);
int FAR PASCAL YespDlg(HWND, unsigned, WORD, LONG);


int my32Alloc(DWORD n,LPWORD psel,DWORD max,WORD wflags);
int my32CodeAlias(WORD sel,LPWORD csel,WORD nullum);
int my16PointerAlloc(WORD sel,DWORD offset,LPDWORD ptr,DWORD size,WORD nbr);
my16PointerFree(WORD,DWORD,WORD);

