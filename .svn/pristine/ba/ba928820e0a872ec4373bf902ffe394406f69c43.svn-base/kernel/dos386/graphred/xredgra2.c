#include "windows.h"
#include <stdio.h>
#include <ctype.h>

#include "xredgraf.h"

fprint(char* s,float i); 
xprint(char *s,long i);

int winX,winY; int winH,winW;
int tmp;
int lwidth,lstyle,cstyle,jstyle;
int oldlinecolor = -1, oldfillcolor = -1;

extern int wpColumns,wpLines,wpMin;
extern int cbHeight,cHeight,cWidth;
extern HANDLE hFont;

long palette[256] ={0};

float xpoints[200];
float ypoints[200];

POINT pp[200];

HDC             hDC;
HWND            hWnd;
HANDLE          brush=NULL, oldbrush,  pen=NULL, oldpen;
int             fil;
char            c;
char            p[1025];
int             pi;
int             pl;
int             eoff;
char           *line;

int readch()
  { 
    c = *line; line++;
    if(!c) 
       {eoff = 1; return(-1);} 
       else return(c);
  }

blanks()
  { 
    while(!eoff && (c==' ' || c==0xa || c==0xd) ) readch();
  }

int r_i(int * j)
  { int i,s,k;
    i=0; k=0;
    blanks();
    if(c=='-') {s = -1; readch();} else s = 1;
    while(!eoff && '0' <= c && c <= '9') 
       {i = 10*i + c-'0'; readch(); k=1;}
    *j = s*i;
    return(k);
  }

int r_f(float * f)
  { float i,q,s;
    int j=0;
    i=0.0;
    blanks();
    if(c=='-') {s = -1.0; readch();} else s = 1.0;              
    while(!eoff && '0' <= c && c <= '9') 
       {i = 10.0*i + (float)(c-'0'); readch(); j=1;}
    if(c=='.')
    {readch();
     q = 1.0;
     while(!eoff && '0' <= c && c <= '9') 
	 {q= q * 0.1; i = i + q*(float)(c-'0'); readch(); j=1;}
    }
    *f = s*i;
    return(j);
  }

r_s(char * s)
   {int j=0;
    blanks();
    while(!eoff && c != 0xa && c != 0xd && c!=' ')
     {*s++ = c; readch(); j=1;}
     *s = '\000';
     return(j);
   }


int transx(float f)
    {return(f*wpMin);}

int transy(float f)
    {return((1.0 - f)*wpMin);}

plot0(char * linein)

{ int nc = 10;
  int np,i,ii;
  int r,g,b;
  char cmd [10], text[1255];
  RECT rect;


  line = linein;
  
  eoff = 0;
  c = ' ';

  if (!palette[0])
  {
  palette[0] = RGB(255,  0,  0);
  palette[1] = RGB(  0,255,  0);
  palette[2] = RGB(  0,  0,255);
  palette[3] = RGB(255,255,  0);
  palette[4] = RGB(255,  0,255);
  palette[5] = RGB(  0,255,255);
  palette[6] = RGB(  0,  0,  0);
  palette[7] = RGB(255,255,255);
  }

  SetBkMode(hDC,TRANSPARENT);   
  if(hFont) SelectObject(hDC,hFont);

while (!eoff)
 { 
  ii=r_s(cmd);
  if(ii==-1) return(0);

  if (strcmp(cmd,"poly")==0)
       { 
	 r_i(&nc);
	 np = 0;
	 for (np=0;;np++)
	 {if(! r_f(&xpoints[np]) || ! r_f(&ypoints[np])) break; }; 

	   if(oldlinecolor != nc)
	   {
	      if(pen) DeleteObject(pen);
	      pen = CreatePen(PS_SOLID,1,palette[nc]);
	      oldlinecolor = nc;
	   }
	   oldpen = SelectObject(hDC,pen);

	   for(i=0;i<np;i++)
	   {pp[i].x = transx(xpoints[i]); pp[i].y = transy(ypoints[i]); };
	   Polyline(hDC,pp,np);
	   SelectObject(hDC,oldpen);
       }

  if (strcmp(cmd,"dash")==0)
       { 
	 r_i(&nc);
	 np = 0;
	while (1)
	{if ((ii=r_i(&i))<1) break;
	 text[np++] = (char) i;
	}
/*      XSetDashes(dpy,DefaultGCOfScreen(scr), nc,text,np); */
       }

  if (strcmp(cmd,"fill")==0)
       { 
	 r_i(&nc);
	 for (np=0;;np++)
	 {if(! r_f(&xpoints[np]) || ! r_f(&ypoints[np])) break; }; 

	   if(oldlinecolor != nc)
	   {
	      if(pen) DeleteObject(pen);
	      pen = CreatePen(PS_SOLID,1,palette[nc]);
	      oldlinecolor = nc;
	   }
	   oldpen = SelectObject(hDC,pen);
	   
	   if(oldfillcolor != nc)
	   {
	      if(brush) DeleteObject(brush);
	      brush = CreateSolidBrush(palette[nc]);
	      oldfillcolor = nc;
	   }
	   oldbrush = SelectObject(hDC,brush);

	   for(i=0;i<np;i++)
	   {pp[i].x = transx(xpoints[i]); pp[i].y = transy(ypoints[i]); };

	   Polygon(hDC,pp,np);

	   SelectObject(hDC,oldpen);
	   SelectObject(hDC,oldbrush);
       }

  if (strcmp(cmd,"text")==0)
       { 
	 r_i(&nc);
	 if(! r_f(&xpoints[0]) || ! r_f(&ypoints[0])) break;
	 ii = 0;
	 tmp= 0;

	 blanks(); /* skip to a new line */

	 tmp = readch();  /* skip the 1st character (leading *) */
	 do { text[ii++] = (char) tmp;
	   tmp = readch();
	   if (eoff) { text[ii++]= '\n'; break; }
	   } while (tmp !=0x0a && tmp != 0x0d);
	 text[ii]=(char) 0x00;
	 if(!IsIconic(hWnd))
	  { SetTextColor(hDC,palette[nc]);
	    TextOut(hDC,transx(xpoints[0]),
			transy(ypoints[0])-(cbHeight*7)/10,
			text,ii);
	  }
	}

  if (strcmp(cmd,"label")==0)
       { ii = 0;

	 blanks();  /* skip over blanks */

	 do { text[ii++] = c;
	   tmp = readch();
	   if (eoff) { text[ii++]= '\n'; break; }
	   } while (tmp !=0x0a && tmp !=0x0d);
	 text[ii++]=(char) 0x00;
	 SetWindowText(hWnd,text);
	}

  if (strcmp(cmd,"ready")==0 ) ;

  if (strcmp(cmd,"background")==0) ;

  if (strcmp(cmd,"exit")==0 
   || strcmp(cmd,"quit")==0) PostQuitMessage(0);

  if (strcmp(cmd,"linestyle")==0)
	{ 
	  r_i(&lwidth);
	  r_i(&lstyle);
	  r_i(&cstyle);
	  r_i(&jstyle);
	}

  if (strcmp(cmd,"erase")==0 || 
      strcmp(cmd,"clear") ==0 ) 
	  {InvalidateRect(hWnd,NULL,NULL);
	   GetClientRect(hWnd,(LPRECT)&rect);
	   FillRect(hDC,(LPRECT)&rect,GetStockObject(WHITE_BRUSH));
	   palette[0] = RGB(255,  0,  0);
	   palette[1] = RGB(  0,255,  0);
	   palette[2] = RGB(  0,  0,255);
	   palette[3] = RGB(255,255,  0);
	   palette[4] = RGB(255,  0,255);
	   palette[5] = RGB(  0,255,255);
	   palette[6] = RGB(  0,  0,  0);
	   palette[7] = RGB(255,255,255);
	  }

  if (strcmp(cmd,"eraseall") == 0) ;

  if (strcmp(cmd,"erasel")==0) ;

  if (strcmp(cmd,"keep")==0) return(0);

  if (strcmp(cmd,"sleep")==0) ;
  
  if (strcmp(cmd,"color") == 0)
      { r_i(&i);
	r_i(&r); r_i(&g); r_i(&b);
	palette[i] = RGB(r,g,b);
      }

  if (strcmp(cmd,"geometry") == 0)
      { r_i(&winW); r_i(&winH); r_i(&winX); r_i(&winY);
	MoveWindow(hWnd,winX,winY,winW,winH,FALSE);
      }

  if(eoff) break;
  }
  
  return(0); }

char pbuf[255];

iprint(char * s,int i)
  {wsprintf(pbuf,"%d",i);
   warning(s,pbuf);
  }

fprint(char* s,float i)
  {
   sprintf(pbuf,"%d %f %lx ",(int)i,i,i);
    /*wsprintf(pbuf,"%d.%d",(int)i,(int)(1000*(i - (int)i))  );  */
   warning(s,pbuf);
  }

xprint(char * s,long i)
  {wsprintf(pbuf,"%lx",i);
   warning(s,pbuf);
  }

