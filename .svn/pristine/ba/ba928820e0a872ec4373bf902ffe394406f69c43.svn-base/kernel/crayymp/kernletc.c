 /*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:                kernletc.c
% Description:       CRAY-UNICOS specific misc routines written in C
% Author:              Winfried Neun, ZIB Berlin
% Created:           2-May-88
% Mode:                C
% Status:              Experimental (Do Not Distribute)
%
% Copyright (c) 1988, Konrad Zuse-Zentrum Berlin for Cray version
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 */

#include <stdio.h>
#include <pwd.h>
struct passwd *getpwuid();
struct passwd *getpwnam();
char *getenv();
 
/**** Expand a filename according to shell variables and ~ notation.
 
(c) Copyright 1984, Hewlett-Packard Company, all rights reserved.
    Copyright (c) 1984 University of Utah
 
    Used with permission from SUN PSL 3.4 version. */
 
static char collect[255];
 
/* The function expand_file_name is used to expand shell variable references
   and ~ notation for directories in file names before calling fopen.
   This eliminates the need for the HPUX-PATH and VAX-PATH kludges that were
   once required, however, such a mechanism may still be used to override the
   values supplied by the shell environment.  The file name is first copied
   to a temporary copy because the parsing algorithm must write into the
   string (this may change).  For now, the maximum string length supported
   is 255 characters, but no checking is done to see if this is exceeded.
   $ and ~ variables are expanded in one pass by calling the functions getenv,
   getuid, getpwuid, and getpwnam.  If any expansion fails, the original
   string is returned.  */
 
char *expand_file_name(fname)
char *fname;
{
  register char *c, *t, *e, *s, save;
  char copy[255];
  struct passwd *p;
  register int tilde;
  c = copy;
  s = fname;
  while (*c++ = *s++);
  s = copy;
  c = collect;
  *c = '\0';
  while (*s)
    {
        if ((tilde = (*s == '~')) || (*s == '$'))
          {
              for (e = ++s; (*e != '/' && *e != '\0' && *e != '$'); e++)
                ;
              t = 0;                                /* default initialization */
              if (e == s)
                {
                  if (tilde) t = ((getpwuid(getuid())) -> pw_dir);
                }
              else
                {
                  save = *e;
                  *e = '\0';
                  if (tilde)
                      {
                        if (p = getpwnam(s))  t = (p -> pw_dir);
                      }
                  else
                      t = getenv(s);
                  *e = save;
                  s = e;
                }
              if (t)
                while (*c++ = *t++)
                  ;
              else return(fname); 
                           /* name not found, just return original fname */
              c--;
          }
    for (; (*s != '\0' && *s != '$'); *c++ = *s++)
        ;
        *c = '\0';
  }
  return (collect);
}
 
char * EXPANDNM (fname)
char **fname;
{ *fname = expand_file_name(*fname);
   return (*fname); }         /* used by set-libpath , LIBNAME , etc. */
 
CHDIR(dirstr)
char *dirstr;
{ chdir(expand_file_name(dirstr));}
 
extern int errno;

/* static int nnn =0; */
 
COSOPENR(ioc,nameptr)  /* both open function return errno (biased)
                          in case of error. That is different from
                          standard unix-io.c (e.g. SUN) */
FILE **ioc; char **nameptr;
{ int *retval;
  retval = (int *)  ioc;
/*  if (nnn++ > 60)
printf(" fopen von %s = %d\n",expand_file_name(*nameptr),fopen(expand_file_name(*nameptr),"r"));
*/
  if((*ioc = fopen(expand_file_name(*nameptr),"r")) == (FILE *) NULL)
          *retval = (-10000 + errno); }
 
COSOPENW(ioc,nameptr)
FILE **ioc; char **nameptr;
{ int *retval;
  retval = (int *) ioc;
/*  * retval = -9998; */
  if((*ioc = fopen(expand_file_name(*nameptr),"w")) == (FILE *) NULL)
          *retval = (-10000 + errno); }
 
 
 
 
COSREADR(size,pstring,ioc)
int *size,*ioc; char **pstring;
{ char * lng;
  FILE* IOC;
  IOC = (FILE*) *ioc;
 
  fflush(stdout);
  if(*ioc == 59) lng = fgets(*pstring,*size,stdin);
       else      lng = fgets(*pstring,*size,IOC);
   if (lng == NULL) {*size = -1;
                     if(*ioc == 59) clearerr(stdin);
                      else  clearerr(IOC); }
                else *size =  strlen(*pstring); }
 
 
COSWRITR(pstring,ioc,size)
int *size,*ioc; char **pstring;
{ if(*ioc == 58) { fputc(' ',stdout); fwrite(*pstring,*size,1,stdout); }
   else if(*ioc == 57) { fputc(' ',stderr);
                                   fwrite(*pstring,*size,1,stderr); }
          else {    fwrite(*pstring,*size,1,(FILE *) *ioc);}
   *pstring =(char *) 0; }
 
 
COSNEWP(ioc)
int *ioc;
{ if(*ioc == 58)          fputs("1\n",stdout);
    else if(*ioc == 57) fputs("1\n",stderr);
           else               fputs("1\n",(FILE *) *ioc);
}
 
COSCLOSE(ioc)
FILE **ioc;
{ fclose(*ioc); }
 
COSBREAD (size,pstring,ioc)
int *size,*ioc; int **pstring;
{ int lng;
  lng = fread(*pstring,8,*size,(FILE *) *ioc);
  if(lng != *size) * size = -1; else *size = 0; }
 
COSBWRIT(size,pstring,ioc)
int *size,*ioc; int **pstring;
{ int lng;
  lng = fwrite (*pstring,8,*size,(FILE *) *ioc);
  if (lng == 0) *size = -1 ; else *size =0;
}
 
#include <fcntl.h>
#include <sys/hpm.h>
 
 /* This file contains some useful C routines for the PSL 3.4 (UNICOS)
   kernel which are coded in C for easy access to system functions.
 
First some Dummies in the kernel, which allow easy redefinition without
complete kernel rebuilding (Its near Christmas, it should be 3, so:) */
 
 
/*Kaspar (a1,a2,a3,a4)
int a1,a2,a3,a4;
{ return(0);}
 
Melchior (a1,a2,a3,a4)
int a1,a2,a3,a4;
{ return(0);}
 
*/

balthasar (a1,a2,a3,a4)
int a1,a2,a3,a4;
{ return(0);} 
 
 /* Help for UCOSIO.f */
 
char Wipf[200];
 
SETWIPF ()  /* Set the FILEENV variable to  ~/UeberAllenWipfeln */
 
{ sprintf(Wipf,"FILENV=%s/UeberAllenWipfeln",getenv("HOME"));
  putenv(Wipf);
  return(0);
}
 
RMWIPF ()  /* unlink the file ~/UeberAllenWipfeln */
 
{ char hugo[200];
  sprintf(hugo,"%s/UeberAllenWipfeln",getenv("HOME"));
  unlink(hugo);
  return(0);
}
 
FINALE()
 
{ exit(0);  exit(0); }  /* To finish gently */
 
extern errno;
 
 
kaspar(a1,a2,a3,a4)   /* one of PSL catastrophic mass entries */
int a1,a2,a3;
char * a4;
 
{ int hpmfil,n;
  if (a1==0)
   { hpmfil = open("/dev/hpm",0);
       if (hpmfil < 0) printf(" ** hpm Error : %d %d\n",hpmfil,errno);
                        else ioctl(hpmfil,HPMSET,a2);
       return(hpmfil); }
 
   if (a1==1)
    { n= read(a2,a4,sizeof(struct hpm));
        return(n); }
 
   if (a1==2)
        return(errno);
}
 
melchior (a1,a2,a3,a4)
int a1,a2,a3,a4;
{ profil(a1,a2,a3,a4); return (0); }
 
COSSAVX (filenam)
 
char **filenam;
 
{ int header [8];
  char * filename;
  FILE * chkfile;
  int i;
 
  filename = *filenam;
 
  chkfile = fopen(expand_file_name(filename),"w");
  if (chkfile == (FILE*) NULL )
   { printf(" Savesystem cannot open file %s, errno = %d\n",filename,errno);
     return(1); }
 
  for(i=0;i<8;i++) header[i] = 0;
 
#ifdef YMP
  header[0] = 265 ; /* 411B */
#else
  header[0] = 263 ; /* 407B */
#endif
  header[5] = GETB00();  /* a0 of the caller */
  header[7] = 1;
  header[1] = sbrk(0) -1;
 
  fwrite(header,8,8,chkfile);
  fwrite(0,8,sbrk(0),chkfile);
 
  fclose(chkfile);
  chmod(expand_file_name(filename),0x1e9);
  return (1);
}
#include <stdio.h>
#include <signal.h>
 
COSCLRIO()
{
    ESSIG(1|SCTL_REG);
    ESSIG(2|SCTL_REG);
    ESSIG(3|SCTL_REG);
    ESSIG(4|SCTL_REG);
    ESSIG(5|SCTL_REG);
    ESSIG(6|SCTL_REG);
    ESSIG(7|SCTL_REG);
    ESSIG(8|SCTL_REG);
    ESSIG(10|SCTL_REG);
    ESSIG(11|SCTL_REG);
    ESSIG(12|SCTL_REG);
    ESSIG(13|SCTL_REG);
    ESSIG(14|SCTL_REG);
    ESSIG(15|SCTL_REG);
    ESSIG(19|SCTL_REG);
    ESSIG(20|SCTL_REG);
    ESSIG(21|SCTL_REG);
    ESSIG(22|SCTL_REG);
    ESSIG(23|SCTL_REG);
    ESSIG(24|SCTL_REG);
    ESSIG(25|SCTL_REG);
    ESSIG(26|SCTL_REG);
    ESSIG(27|SCTL_REG);
 
    stdin->_cnt = 0;
    stdin->_ptr = stdin->_base;
    stdout->_cnt = 0;
    stdout->_ptr = stdout->_base;
    stderr->_cnt = 0;
    stderr->_ptr = stderr->_base;
}
 
#include <fortran.h>
 
#define MAXCMDL 152     /* maximum length of argument list */
 
/*      ISHELL - Fortran callable routine to send a command
 *              to the shell.
 *
 *      For now it takes only 1 character argument.
 */
 
JSHELL(cmdargs)
_fcd cmdargs;
{
        char buf[MAXCMDL];
        int len;
 
        if(len = _fcdlen(cmdargs)) {
                strncpy(buf,cmdargs,len);
                buf[len] = 0;
                cmdargs = (_fcd) buf;
        }
 
        if (system(cmdargs) == -1)
             { perror(" *** Fatal Error invoking shell"); exit (2); }
}
 
#include <sys/types.h>
#include <sys/times.h>
#include <sys/machd.h>
 
 
/* returns cpu time in a CFT like fashion */
 
COSTIMC (INT)
int * INT;
  { struct tms timebuffer;
    times(&timebuffer);
    *INT = ((1000 * timebuffer.tms_utime) / HZ); }
 
 
COSID (STRI)   /* this supports "shellcmd" or system */
int ** STRI;  /* interface for "system" called as CFT */
 
{ int * INT;
   INT = (int *) STRI;
   *INT = system ((char *) (((int) *STRI + 1)&0xffffffff)); }
 
