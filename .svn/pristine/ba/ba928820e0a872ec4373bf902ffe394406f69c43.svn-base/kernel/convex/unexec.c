/*
 * unexec.c - Convert a running program into an SOFF file.
 * 
 * Author:      Winfried Neun (COFF format)
 *              Herbert Melenk (SOFF format)
 *
 * Synopsis:
 *      unexec( new_name, a_name, data_start, bss_start )
 *      char *new_name, *a_name;
 *      unsigned data_start, bss_start;
 *
 * Takes a snapshot of the program and makes an SOFF format file in the
 * file named by the string argument new_name.
 * If a_name is non-NULL, the symbol table will be taken from the given file.
 * 
 * This is a raw version, not many checks are done,etc.
 * Symbols are stripped from file
 *
 */

#include <stdio.h>
#include <convex/filehdr.h>
#include <convex/opthdr.h>
#include <convex/scnhdr.h>
#include <convex/reloc.h>
#include <nlist.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <strings.h>

#define ETEXT (  ( (unsigned)&etext + (PAGSIZ-1) ) & ~(PAGSIZ-1)  )
#define EDATA (unsigned)&edata

extern char etext, edata;

extern int   oldbreakvalue;

static struct filehdr filhdrold,filhdrnew;
static struct opthdr opthdrold,opthdrnew;
static struct scnhdr scnold,scnnew;
static sect_name [20];

static long STEXT, LNGTEXT;
static long SDATA, LNGDATA;
static long numberofsects,oldstringtab,newstringtab;
 
long page_align(l)
     long l;
      {if (l % 4096 != 0)
            l = 4096 * (1+ l / 4096);
       return(l);
      }

/* ****************************************************************
 * unexec
 *
 * driving logic
 */

unexec ( nnnnnn_name, o_name, data_start, bss_start )

char *nnnnnn_name, *o_name;
unsigned data_start, bss_start;
{
    FILE *newf;
    FILE stdin_save;
    int new, a_out = -1 ,i , unexec_error;
    char new_name[256], a_name[256];

    /* Expand both filenames now. Place in seperate static arrays so that
       mallocs are not needed at runtime. Messes up the unexec by
       changing the oldbreakvalue.
     */
    strcpy(new_name, expand_file_name(nnnnnn_name));
    data_start = data_start;
    bss_start  = bss_start;
    printf (" Data Start at %x, bss start at %x \n",data_start,bss_start);

       /* align bss address */
    bss_start = page_align(bss_start);

    printf (" bss page aligned: %x \n",bss_start);

    if (o_name)
      strcpy(a_name, expand_file_name(o_name));

    printf (" parent a.out file is>%s<\n",a_name);

    if ( a_name && (a_out = open( a_name, 0 )) < 0 )
    {
        printf ("cannot open a.out file >%s<\n",a_name);
	perror( a_name );
	return -1;
    }
    if ( (newf = fopen( new_name, "w" )) == NULL )
    {
	perror( new_name );
	return -1;
    }
    fclose(newf);
    new = open( new_name, 1);       /* This fd will be written with zwrite. */

                                    /* save and reconfigure stdin           */
    stdin_save = __ap$iob[0];
    __ap$iob[0]._cnt = 0;
    __ap$iob[0]._ptr = NULL;
    __ap$iob[0]._base = NULL;
    __ap$iob[0]._bufsiz = 0;
    __ap$iob[0]._flag = 1;
    __ap$iob[0]._file = 0;
    
    printf("making file header\n");

    make_filhdr( new, a_out, data_start, bss_start );

    printf("generating %d sections\n",numberofsects);

    for (i=1;i<=numberofsects;i++)
            make_scnhdr ( new, a_out, data_start, bss_start );
                                       
                                    /* restore stdin                       */
    __ap$iob[0] = stdin_save;

	 /*
	copy_sym( new, a_out ) < 0) */
    if(unexec_error == 4711)
    {
	close( new );
	/* unlink( new_name );          /* Failed, unlink new a.out */
	return -1;      
    }

    close( new );
    if ( a_out >= 0 )
	close( a_out );
      mark_x( new_name ); 
    return 0;
}

/* ****************************************************************
 * make_filhdr
 *
 * Make the header in the new a.out from the header in core.
 * Modify the text and data sizes.
 */
static int
make_filhdr( new, a_out, data_start, bss_start )
int new, a_out;
unsigned data_start, bss_start;
{

    /* Get symbol table info from header of a.out file if given one. */
    if ( a_out >= 0 )
    {
	if ( read( a_out, &filhdrold, sizeof filhdrold ) != sizeof filhdrold )
	{
	    perror( "Couldn't read header from a.out file" );
	    return -1;
	}

	if (filhdrold.h_magic != SOFF_MAGIC)
	{
	    fprintf( stderr, "a.out file not in SOFF format; magic: %x\n",
                              filhdrold.h_magic );
	    return -1;
	}
    
	/* Save hdr as it was read in, to find symbol table in a.out file. */
    }
    else
    {
	perror( "symbolfilename* must be specified" );
	return -1;
    }
    /* Construct header from default assumptions.
     * (hdr.a_magic, hdr.a_entry and hdr.a_syms are set above.)
     */
    filhdrnew.h_magic = filhdrold.h_magic;
    filhdrnew.h_version = filhdrold.h_version;
    filhdrnew.h_timdat =filhdrold.h_timdat;
    filhdrnew.h_nscns = filhdrold.h_nscns;
    numberofsects     = filhdrold.h_nscns;
    filhdrnew.h_scnptr  = filhdrold.h_scnptr ;
    filhdrnew.h_opthdr  = filhdrold.h_opthdr ;
      oldstringtab = filhdrold.h_strptr ;
    filhdrnew.h_strptr  = 0;
    filhdrnew.h_strsiz  = filhdrold.h_strsiz ;
    filhdrnew.h_flags   = filhdrold.h_flags  ;
    write (new, &filhdrnew,  sizeof filhdrnew);
 
    if ( read( a_out, &opthdrold, sizeof opthdrold ) != sizeof opthdrold )
    {
            perror( "Couldn't read opt header from a.out file" );
            return -1;
        };
    opthdrnew.o_symptr  = 0;
    opthdrnew.o_nsyms   = 0;
    opthdrnew.o_spare   = opthdrold.o_spare ;
    opthdrnew.o_entry   = opthdrold.o_entry ;
    opthdrnew.o_flags   = opthdrold.o_flags | OF_STRIPPED;
    write (new, &opthdrnew,  sizeof opthdrnew);

            /* move files to first section hdr */
    lseek(a_out,(long)filhdrnew.h_scnptr,SEEK_SET);
    lseek(new,(long)filhdrnew.h_scnptr,SEEK_SET);

}

/* get the name of a section */
get_sct_name(a_out, pos)
     unsigned long long pos;
     { long oldpos,newpos; int i;
       oldpos = tell(a_out);
       if(oldstringtab==NULL) return(0);
       newpos = pos + oldstringtab;
       lseek(a_out,newpos,SEEK_SET);
       if (read( a_out, sect_name,20) != 20)
          {perror("Couldn't read section name string");
           return -1;
          };
       lseek(a_out,oldpos,SEEK_SET);
     }


/* ****************************************************************
 * make_scnhdr
 *
 * Make the header in the new section and copy the section from core.
 */
static int
make_scnhdr( new, a_out, data_start, bss_start )
int new, a_out;

unsigned data_start, bss_start;
{   off_t oldpos,oldoldpos;
    /* Get symbol table info from header of a.out file if given one. */ 
    if (read( a_out, &scnold, sizeof scnold ) != sizeof scnold )
	{   
	    perror( "Couldn't read text scn header from soff file" ); 
	    return -1; 
	}   
    oldoldpos = tell (new);
    
    get_sct_name(a_out,scnold.s_strndx);

            /* PRINT content of lod scnhdr */

/*
    printf ("---------- scnhdr  -------------\n");
    printf ("name:    %s\n",sect_name);
    printf ("vaddr:   %lx\n",scnold.s_vaddr);
    printf ("size:    %llx\n",scnold.s_size );
    printf ("scnptr:  %llx\n",scnold.s_scnptr); 
    printf ("relptr:  %llx\n",scnold.s_relptr); 
    printf ("nrel:    %lx\n",scnold.s_nrel); 
    printf ("prot:    %lx\n",scnold.s_prot); 
    printf ("flags:   %llx\n",scnold.s_flags); 
*/

       /* update headers */

    if (strcmp(sect_name,".data")==0)
     { /* add execute permission */
       scnold.s_prot = scnold.s_prot | 0x00000002;
       printf("protection: %lx\n",scnold.s_prot);
     }
    else if (strcmp(sect_name,".tdata")==0)
     { /* add execute permission */
       scnold.s_prot = scnold.s_prot | 0x00000002;
           /* enlarge such that it includes the defined part of the heap */
       scnold.s_size = bss_start-scnold.s_vaddr;
     } 
    else if (strcmp(sect_name,".tbss")==0) 
     {  /* set to dummy area */
       scnold.s_size = 4096; 
       scnold.s_vaddr = bss_start; 
     }
    else  if (strcmp(sect_name,".bss")==0)
     {  /* include unset portion of heap */
       scnold.s_vaddr = bss_start +4096; 
       scnold.s_size = page_align(oldbreakvalue) - scnold.s_vaddr;
     };
 

       /* write header to file */
           write (new, &scnold , sizeof scnold );
            oldpos = tell (new);
 
       /* if memory part, copy data to file */
      if(scnold.s_scnptr!=0)
         {    
           /* copy the portion from memory to file */
        lseek(new,(long)scnold.s_scnptr,SEEK_SET);
        if ((long)scnold.s_size != 
              write(new,(char*)scnold.s_vaddr,(long)scnold.s_size))
            perror ("uable to write data to output file");
        lseek(new,oldpos,SEEK_SET);
         };   

      
     printf("%s: hdr to %lx, data to %llx, lng=%llx, virt.addr=%lx \n",
          sect_name,oldoldpos,scnold.s_scnptr,scnold.s_size,scnold.s_vaddr);
    return (0);   
}

/* ****************************************************************
 * mark_x
 *
 * After succesfully building the new a.out, mark it executable
 */
static
mark_x( name )
char *name;
{
    struct stat sbuf;
    int um;
 
    um = umask( 777 );
    umask( um );
    if ( stat( name, &sbuf ) == -1 )
    {
        perror ( "Can't stat new a.out" );
        fprintf( stderr, "Setting protection to %o\n", 0777 & ~um );
        sbuf.st_mode = 0777;
    }
    sbuf.st_mode |= 0111 & ~um;
    if ( chmod( name, sbuf.st_mode ) == -1 )
        perror( "Couldn't change mode of new a.out to executable" );
 
}
 
/*
 
    (setq symbolfilename* "~/kern/bpsl.new")
    (savesystem "jawoll" "versuch" nil)
 
*/
