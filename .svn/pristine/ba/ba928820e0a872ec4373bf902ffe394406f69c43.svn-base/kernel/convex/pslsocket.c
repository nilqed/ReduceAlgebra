#include <stdio.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <netdb.h> 
#include <netinet/in.h> 

 
/* #define PORT_NUMBER 1188    /* Port number to listen on. 
                               Must be the same as in client!!!! */ 

unixsocketopen(name , number)

char * name;
int number;

{
}

getsocket (mail_fd , string , length)

int mail_fd,length;
char * string;

{ 
}

writesocket (mail_fd , string , length) 

int mail_fd,length; 
char * string; 
 
{ }

unixclosesocket (conn_fd)
int conn_fd;

{ }

