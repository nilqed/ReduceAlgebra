# Assemblerquellen zur Convex tragen
ftp 130.149.4.20 <<EOF
cd ~/psl/dist/kernel/convex
mput *.c
EOF

