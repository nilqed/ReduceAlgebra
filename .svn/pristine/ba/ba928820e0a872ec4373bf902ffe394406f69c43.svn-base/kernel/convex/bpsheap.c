/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         bpsheap.c
% Description:  Code to dynamically set up bps and heap structures
% Author:       RAM, HP/FSD
% Created:      9-Mar-84
% Modified:     
% Mode:         Text
% Package:      
%
% (c) Copyright 1987, University of Utah, all rights reserved.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
% 27-Aug-90 (Herbert Melenk)
%  Added execute permission to BPS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

/* Use 1 if using compacting collector ($pxnk/compact-gc.sl).
   Use 2 if using copying collector ($pnk/copying-gc.sl).
   Be sure to update $pxnk/load-psl.sl to include correct collector. */

#include <sys/time.h>
#include <sys/resource.h>
#include <errno.h>
#include <stddef.h>


#define MINSIZE        3000000  /* Default total in number of bytes. */
#define MALLOCSIZE     84096    /* Default size for OS support functions. */
#define EXTRABPSSIZE   200000   /* Minimum amount to increase bps by. */
#define MINIMUMHEAPADD 20000    /* Minimum amount to increase heap by */


#ifndef BPSSIZE
#define BPSSIZE	      800000    /* Default bps size in number of bytes */
#endif

int     alreadysetupbpsandheap;
int     max_image_size;
int 	oldbreakvalue;

extern int  alreadysetupbpsandheap;
extern char bps[];
extern int  lastbps;
extern int  nextbps;
extern int  bpslowerbound;
extern int  _infbitlength_;

extern int  heaplowerbound;
extern int  heapupperbound;
extern int  heaplast;
extern int  heaptrapbound;

extern int  oldheaplowerbound;
extern int  oldheapupperbound;
extern int  oldheaplast;
extern int  oldheaptrapbound;

static long saved_lastbps;

/* Write this ourselves to keep from including half the math library */
static power(x, n)
     int x, n;
{
  int i, p;

  p = 1;
  for (i = 1; i <= n; ++i)
    p = p * x;
  return(p);
}

setupbpsandheap(argc,argv)
     int argc;
     char *argv[];
{
  int    i, total, bpssize, heapsize, mallocsize;
  int    current_size_in_bytes, heapsize_in_bytes;
  double bpspercent, heappercent;
  char   *argp, *scanptr, *scanformat;
  void   *temp[17];

  if (alreadysetupbpsandheap)   /* If this session was dumplisped ... */
    { 
      return 0;
    }

  total		= MINSIZE;
  mallocsize	= MALLOCSIZE;
  
  for (i=1; i<argc-1; i++)
    {
      argp = argv[i];
      if (*argp++ == '-')
        {
          scanformat = "";
          switch (*argp++) {
            case 't': scanptr = (char *)&total;
                      switch (*argp) {
		        case 'x': scanformat = "%x";
			          break;
                        case 'd': scanformat = "%d";
                                  break;
		      }
                      break;
            case 'm': scanptr = (char *)&mallocsize;
                      switch (*argp) {
                        case 'x': scanformat = "%x";
                                  break;
                        case 'd': scanformat = "%d";
                                  break;
                      }
                      break;
          }
          if (*scanformat != 0)
            sscanf(argv[i+1],scanformat,scanptr);
        }
    }   /* end of for loop -- arg vector searched */

  /* insure valid values */
  if (total == 0) total = MINSIZE;

  if (mallocsize <= 0) mallocsize = MALLOCSIZE;

  /* Reserve some space for C's usr of io buffers, etc. By mallocing then
     freeing, the memory is sbrk'ed onto the image, but available for future
     calls to malloc, which will not need to call sbrk again. */
  temp[0] = malloc ((size_t)0x14880);
  temp[1] = malloc ((size_t)0x10000);
  temp[2] = malloc ((size_t)0x10000);
  for (i=3; i<8; i++) temp[i] = malloc ((size_t)0x4000);
  temp[9] = malloc ((size_t)0x142c);
  temp[10]= malloc ((size_t)0x2000);
  temp[11]= malloc ((size_t)0x1000);
  temp[12]= malloc ((size_t)0x2000);
  temp[13]= malloc ((size_t)0x3000);
  temp[14] = malloc ((size_t)0x4000);
  temp[15] = malloc ((size_t)0x10000);
  temp[16] = malloc ((size_t)0x8000);

  for(i=0; i<17; i++) free(temp[i]);

  bpssize = BPSSIZE;

  heapsize_in_bytes = total - bpssize;

  /* On systems in which the image does not start at address 0, this won't
     really allocate the full maximum, but close enough. */
  current_size_in_bytes = (int) sbrk(0);
  max_image_size = power(2, _infbitlength_); /* 1 more than allowable size */
  
  if ((heapsize_in_bytes + current_size_in_bytes) >= max_image_size) {
    heapsize_in_bytes = max_image_size - current_size_in_bytes;
    total = heapsize_in_bytes + bpssize;
    printf("Size requested will result in pointer values larger than\n");
    printf(" PSL items can handle. Will allocate maximum size instead.\n\n");
  }

  heapsize =(heapsize_in_bytes / 4) * 2;  /* insure full words */

  getheap(heapsize);
 
  setupbps();

  printf("bpssize = %d (%X), heapsize = %d (%X)\nTotal image size = %d (%X)\n",
          bpssize, bpssize,
          heapsize, heapsize, 
          oldbreakvalue,oldbreakvalue);

  alreadysetupbpsandheap = 1;

}


/* The current procedure is to convert the starting address of the char
   array defined in bps.c to an address and store it in nextbps. A check
   is made to make sure that nextbps falls on an even word boundry.
 */
setupbps()
{
  nextbps  =  ((int)bps + 3) & ~3;		/* Up to a multiple of 4. */
  bpslowerbound = nextbps;
  lastbps  =  ((int)bps + BPSSIZE) & ~3;	/* Down to a multiple of 4. */
                                                /* make executable */
  saved_lastbps = lastbps;
  write_exec_prop((unsigned)bpslowerbound,(unsigned)lastbps);
}  


/* Allocate alternate bps space. Note: The use of sbrk(), and the fact that
   nextbps is now greater than heaplast means that unexec should be not be
   tried after this routine is called. The image would be huge.
 */
allocatemorebps()
{
  int current_size_in_bytes;
  int old_nextbps = nextbps;
  
  current_size_in_bytes = sbrk(0);

  if ((current_size_in_bytes + EXTRABPSSIZE) >= max_image_size)
    return(0);

  if (((int)sbrk(0)) % 2)      /* force to even word boundary*/
     nextbps = (int)sbrk(1);
 
  nextbps = (int)sbrk(EXTRABPSSIZE);   /* allocate extra BPS */
  if (nextbps == -1) {
    nextbps = old_nextbps;
    return(0);
  }
  lastbps = nextbps + EXTRABPSSIZE;
  write_exec_prop((unsigned)nextbps,(unsigned)lastbps);

  return(EXTRABPSSIZE);   /* This will be a paramter later */
}
 
  
/* tag( getheap )
 */
getheap(heapsize)
     int heapsize;
{
  long x,y;

/*
  struct rlimit rlp;
  printf("trying sbrk for %d = %x\n",heapsize,heapsize);

  getrlimit(RLIMIT_DATA,&rlp);
  printf("rlimits: %d %d %x %x \n",rlp.rlim_cur,rlp.rlim_max,
                                   rlp.rlim_cur,rlp.rlim_max);
  rlp.rlim_cur = rlp.rlim_max;
  setrlimit(RLIMIT_DATA,&rlp);

*/

   /* ensure that the upper heap limit will be a page boundary */
  x = sbrk(0);
  y = page_align(x + 2 * heapsize);
  heapsize = (y - x) /2;

  heaplowerbound        = (int)sbrk(2 * heapsize);  /* allocate both heaps */;

  if (heaplowerbound == -1) {
    printf("sbreak Fehler: %d \n",errno);
    perror("GETHEAP");
    exit(-1);
  }
  heapupperbound        = heaplowerbound + heapsize;
  heaplast              = heaplowerbound;
  heaptrapbound         = heapupperbound -120;


  oldheaplowerbound	= heapupperbound;
  oldheapupperbound     = oldheaplowerbound + heapsize;
  oldheaplast           = oldheaplowerbound;
  oldheaptrapbound      = oldheapupperbound -120;
  oldbreakvalue = (int)sbrk(0);
}

/* Tag( alterheapsize ) */
alterheapsize(increment)
int increment;
{
/*
  alters the size of the heap by the specified increment.  Returns
  the increment if successful, otherwise returns 0.  May fail if
  the sbrk is unsuccessful or if the user tries to cut the heap back
  to nothing or the current break value does not match the old value.
  The latter case occurs when a malloc or sbrk has allocated space for
  some other software, in which case we cannot allocate any more space
  contiguously.

  Modifies both the heap and gcarray size.
  NOTE: a garbage collection should probably be performed before this
	routine is called.
  NOTE: only implemented for the one heap version on the 68000.
*/

  int heapsize;
  int current_size_in_bytes;
  
  /* assumes the current heap is the 'lower' one */
  int newbreakvalue;
  struct rlimit lim;

  getrlimit(RLIMIT_DATA,&lim);
  /* 
  printf("rlim_cur: %x rlim_max:%x\n",
              lim.rlim_cur,lim.rlim_max);
  */

 
  if ((int) sbrk(0) != oldbreakvalue)  /* Non contiguous memory */
      {  printf(" unable to allocate %x %x\n",sbrk(0),oldbreakvalue);
        return(0); }
 
  current_size_in_bytes = (sbrk(0) << 1) >> 1; /* get rid of leading bit
 
  if ((current_size_in_bytes + 2* increment) >= max_image_size)
    return(-1);
 
  if ((int)sbrk(2 * increment) == -1)       /* the sbrk failed. */
     return(-2);
 
  newbreakvalue = (int) sbrk(0);
  increment= (increment / 4) * 4;

  heapupperbound        = heapupperbound + increment ;
  heaptrapbound         = heapupperbound - 30;
  oldheaplowerbound     = oldheaplowerbound + increment;
  oldheapupperbound     = oldheapupperbound + 2* increment ;
  oldheaplast           = oldheaplowerbound;
  oldheaptrapbound      = oldheapupperbound -30;
 
  oldbreakvalue = newbreakvalue;
  return(increment);

}

/*
extern pslargc, environ;

extern char *static_argv[20];

int savetheenvironment()

{ int i , diff;
  char *newloc;
  int actsbrk;
  char** newenv;
  actsbrk = (int) sbrk (0);
  printf("%d %x %x\n",alreadysetupbpsandheap,actsbrk,oldbreakvalue);

  if (!alreadysetupbpsandheap) return (0);

  if (actsbrk != oldbreakvalue)
    { diff = actsbrk - oldbreakvalue;
      printf("malloc: %d %x %x \n",diff, (unsigned) diff,(unsigned) diff);
      newloc = (char *) malloc ((unsigned) diff); 
      for (i=0; i < diff; i++) newloc[i] = ((char *) oldbreakvalue) [i]; 
      diff = oldbreakvalue - (int) newloc;
      for (i=0; i < pslargc; i++)
      static_argv[i] += diff;
      newenv = environ + (char **) diff;
      for (i=0; newenv[i] !=(char *) 0; i++) newenv[i] += diff;
      environ = (int) newenv;
      printf(" %x %x %x\n", diff, environ,newenv);
    }
}

*/
