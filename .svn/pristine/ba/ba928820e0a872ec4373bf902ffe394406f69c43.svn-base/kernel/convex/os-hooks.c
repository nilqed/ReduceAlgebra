/******************************************************************************
*
* File:         $PXK/OS-HOOKS.C
* Description:  OS specific startup and cleanup hooks.
* Author:       RAM, HP/FSD
* Created:      9-Mar-84
* Modified:    15-Jul-85 10:10:51 (RAM)
* Mode:         Text
* Package:
* Status:       Experimental (Do Not Distribute)
*
* (c) Copyright 1984, Hewlett-Packard Company, all rights reserved.
*
******************************************************************************
* Revisions:
*
* 27-Aug-90 (Herbert Melenk) 
*  Added execute permission  hook for data areas with code (symfnc, BPS)
*  for the CONVEX
* 23-Feb-89 (Chris Burdorf)
*  Made  call to psl_main in main call copy_argv to pass the static
*  copy of argv to get around unexec problems.
* 15-Jun-88, (Tsuyoshi Yamamoto)
*  Added init-malloc-param(), _iob[] initializer, _dtabsize for SUN4 PORT.
******************************************************************************
*/
#include <stdio.h>
#include <setjmp.h>
#include <pagsiz.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <errno.h>
 
     /*  memory limits for the data segment */
extern unsigned data_start;
extern unsigned data_end;
 
jmp_buf mainenv;
 
main(argc,argv)
int argc;
char *argv[];
{
  int i,val; caddr_t data_base; unsigned lth;
 
  clear_iob();             /* clear garbage pointer in _iob[]    */
  clear_dtabsize();
      /* read write execute permission for the data segment */
  data_base = (caddr_t) ((data_start/NBPG ) * NBPG);
  lth = data_end - ((unsigned) data_base);
  i = mremap(data_base, &lth,PROT_READ | PROT_WRITE | PROT_EXEC,
                       MAP_PRIVATE);
  if (i<0) printf("mremap impossible: %d %lx %lx %lx %lx\n",
                      errno,data_start,data_base,data_end,lth);
  
 
     psl_main(argc,copy_argv(argc,argv)); 
  /*   psl_main(1,0); */
 
exit(0);
 
}
 
write_exec_prop(low,high)
     unsigned low,high;
        /* assign the execute & write permission to the memory */
        /* in the address area <low,high>                      */
      {caddr_t data_base; 
       unsigned lth;
       int i;
       data_base = (caddr_t) ((low/NBPG ) * NBPG);
       lth = high - ((unsigned) data_base);
 printf("mremap : %d %lx %lx %lx %lx\n",
                      errno,low,data_base,high,lth);
       i = mremap(data_base, &lth,PROT_READ | PROT_WRITE | PROT_EXEC,
                       MAP_PRIVATE);
       if (i<0) printf("mremap impossible: %d %lx %lx %lx %lx\n",
                      errno,low,data_base,high,lth);
       return (i);
      }
 
os_startup_hook(argc, argv)
     int argc;
     char *argv[];
{
 
  setupbpsandheap(argc, argv);    /* Allocate bps and heap areas. */
 
}
 
os_cleanup_hook()
{
longjmp(mainenv,1);
}
 
 
#define IOBUFN 30    /* I guess it is 30 */
clear_iob()
{
 int i;
 
/*
 for(i=3;i<IOBUFN;i++){
    bzero(&_iob[i],sizeof(_iob[i]));
    };
*/
}
 
/*
 *    Some static area must be initialized on hot start.
 *    There may be other area to be initialized but we have no idea
 *    to know them.
 *
 *    _dtabsize ----_end
 */
 
 
extern char *end;
/*
 *     Size of dtabsize is 0x34c bytes.
 */
clear_dtabsize()
{
 int i;
 bzero((int)(&end)-0x34c, 0x34c);
 }
 
