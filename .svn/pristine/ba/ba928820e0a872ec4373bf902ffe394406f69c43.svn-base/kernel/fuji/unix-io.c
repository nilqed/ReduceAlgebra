/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         PXK:UNIX-IO.C
% Description:  Unix PSL FileDescriptors are implemented as stdio streams
%                 ("FILE *".)
% Author:       Russell D. Fish
% Created:      Thu Feb 16 1984
% Modified:     17-Jul-84 22:49:12 (RAM)
% Mode:         Text
% Package:      
% Status:       Experimental (Do Not Distribute)
%
% Copyright (c) 1984 Hewlett-Packard Company, all rights reserved.
% Copyright (c) 1984 University of Utah
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
%   AIX version
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

#include <stdio.h>

  /* from os-hooks */
extern char * image,* kerneldir;

/* Initialize some PSL external variables with FileDescriptors for SysClearIO.
 */
extern FILE * ustdin, * ustdout, * ustderr, * utty;

/* Import NULL and EOF constants for error returns from stdio fns.  */

extern int ueof;
extern void * unull;

make_code()
     { 
     }


uinitio()
{
    ustdin = stdin;
    ustdout = stdout;
    ustderr = stderr;
    unull = NULL;
    ueof = EOF;
}

uputc(c)
char c;
{ fputc(c, stdout); }
 
char ufgetc(fp)
    FILE*fp;
    { return(fgetc(fp));}

ufputc(c,fp)
    char c; FILE*fp;
    { fputc(c, fp); }

uputs(str)
char *str;
{
    char estr[255]; int i;
    for(i=0;i<256&&str[i]!='\0';i++)
         estr[i]=str[i];
    estr[i]='\0';
    fputs(estr, stdout);
}


char * ufgets(str,count,fp)
    char*str; 
    int count; 
    FILE*fp;

    {int i; char*s ; char * val; char*t;
     val = fgets(str,count,fp);
     if (val == (char *) NULL) return(val) ;
     s=t=str;
     while(*t++ = *s++);
     return(str);
    }


ufread(buf,size,count,fp)
     char*buf; 
     int count,size; 
     FILE*fp;

    {int i,r,l; char*s; char*t;
     r=fread(buf,size,count,fp);
     l=r*size;

     if(r != count) { r++; buf[l]=(char) 4; }

     for(i=0;i<l;i++) buf[i]=buf[i];
     return(r);
    }

ufwrite(buf,size,count,fp)
     char*buf; 
     int count,size; 
     FILE*fp;

    {int i,r,l; char*s; char*t;
     l=size*count;
         /* buffer is overwritten here */
     for(i=0;i<l;i++) buf[i]=buf[i];
     r=fwrite(buf,size,count,fp);
     return(r);
    }

uputn(n)
int n;
{
    fprintf(stdout, "%x ", n);
}

/* Tag( unixcleario ) */
ucleario()
{
    kerneldir=NULL;
    uinitio();
}

putw(w, stream)
     FILE *stream;
   {
     fwrite(&w,4,1,stream);
   }

unsigned getw(stream)
     FILE *stream;
    { unsigned w;
      fread(&w,4,1,stream);
      return(w);
    }

#include <pwd.h>
struct passwd *getpwuid();
struct passwd *getpwnam();
char *getenv();


char collect[255], copy[255];  /* Made global so it won't be overwritten 
				  Used to be local to expand_file_name */
char *expand_file_name(fname)
char *fname;
{
  register char *c, *t, *e, *s, save;
  struct passwd *p;
  register int tilde;
  c = copy;
  s = fname;
  while (*c++ = *s++);
  s = copy;
  c = collect;
  *c = '\0';
  while (*s)
    {
      if ((tilde = (*s == '~')) || (*s == '$'))
        {
      for (e = ++s; (*e != '/' && *e != '\0' && *e != '$'); e++)
        ;
          t = 0;                        /* default initialization */
          if (e == s)
            {
          if (tilde) t = ((getpwuid(getuid())) -> pw_dir);
        }
          else
            {
          save = *e;
              *e = '\0';
              if (tilde)
               {
          if (p = getpwnam(s))  t = (p -> pw_dir);
        }
              else
                t = getenv(s);
                /* printf("getenv fuer %s  -> %x = %s\n",s,t,t); */
              *e = save;
              s = e;
            }
          if (t)
        while (*c++ = *t++)
          ;
          else
        return(fname);   /* name not found, just return original fname */
          c--;
        }
    for (; (*s != '\0' && *s != '$'); *c++ = *s++)
      ;
      *c = '\0';
  }
      /* printf("fnexpand: %s\n",collect); */
  return (collect);
}

extern int errno;

/* Tag( unixopen )
 */
uopen(filename, type)
     char *filename, type[];
{
  int fptr; char * tp; char c1,c2;
  c1=type[0];
  c2=type[1];
  if (c2!='b')
     {if(c1=='r') tp="r"; else tp="w";}
    else
     {if(c1=='r') tp="rb"; else tp="wb";}; 
  fptr = (int) fopen(expand_file_name(filename), tp);
  return(fptr);
}

cfread(ptr,m,s,fil)
   char * ptr;
   int m,s;
   FILE * fil;
   {int l1,l2,i; 
    l2=fread(ptr,m,s,fil);
    l1=m*l2;
    for(i=0;i<l1;i++) ptr[i] = ptr[i];
    return(l2);
   }
 
cfwrite(ptr,m,s,fil)
   char * ptr;
   int m,s;
   FILE * fil;
   {int l1,l2,i;
    l1=m*s;
    for(i=0;i<l1;i++) ptr[i] = ptr[i];
    l2=fwrite(ptr,m,s,fil);
    return(l2);
   }
   
/* Tag( unixcd )
 */
ucd(filename)
     char *filename;
{
  chdir(expand_file_name(filename));
}

/* Tag( external_system )
 */
e_system(command)
     char *command;
{
  int value;
  value = system(command);
  return(value);
}

/* Tag( external_exit )
 */
e_exit(status)
     int status;
{
  exit(status);
}

char *static_argv[20];  /* static place to hold argv so it doesn't get gc'd */

void * copy_argv(argc,argv)    /* copy argv into static space. */
int argc;
char *argv[];
{
  int i;

  for (i=0; i < argc; i++)
     static_argv[i]=argv[i];

  return(static_argv);
}
 
sleep(i)
     int i;
     {}

