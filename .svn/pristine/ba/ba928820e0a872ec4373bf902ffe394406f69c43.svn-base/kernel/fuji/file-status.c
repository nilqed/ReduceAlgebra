/* 
 * file-status.c - PSL Packaging for the Unix "stat" system call.
 * 
 * Author:	Russell D. Fish
 * 		Computer Science Dept.
 * 		University of Utah
 * Date:	Wed Nov 23 1983
 */

#include <stdio.h>

typedef struct{
    char * string_value;		/* Interpretation of a field. */
    int numeric_value;			/* One of the stat fields. */
} stat_info;

/* Tag( get_file_status )
 */
int				     /* Returns "stat" value, 0 == success. */
get_file_status( file_name_string, info_block, do_strings )
char * file_name_string;		/* File to stat. */
stat_info info_block[7];		/* Space to return values. */
int do_strings;				/* Whether to interpret numbers. */
{
    return 0;
}


/* Tag( get_mode_string )
 * Parse the mode value into a string.  Based on /usr/src/bin/ls.c .
 */
char *
get_mode_string( mode )
unsigned short mode;
{
    return 0;
}
