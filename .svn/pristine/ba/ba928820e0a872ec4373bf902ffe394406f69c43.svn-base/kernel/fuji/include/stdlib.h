/* c copyright fujitsu limited 1987                                 */
/********************************************************************/
typedef struct div_t  {
    int          qout;             /* qoutient                      */
    int          rem;              /* remainder                     */
}  div_t;
typedef struct ldiv_t  {
    long int     qout;            /* qoutient                       */
    long int     rem;             /* remainder                      */
}  ldiv_t;
 
extern double atof();
