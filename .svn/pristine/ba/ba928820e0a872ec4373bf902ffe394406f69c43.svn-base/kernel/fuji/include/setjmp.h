/* c copyright fujitsu limited 1986                                 */
typedef int jmp_buf�5! ;
void   longjmp() ;
