/* c copyright fujitsu limited 1986                                 */
/********************************************************************/
extern char *memcpy();
extern char *memset();
extern void *memchr();
