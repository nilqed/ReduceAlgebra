/* c copyright fujitsu limited 1986                                 */
/********************************************************************/
typedef struct attr {
    int             lrecl          ;
    int             blksize        ;
    unsigned short  option         ;
    unsigned short  devtype        ;
    char            recfm   � 4! ;
    char            dsorg   � 3! ;
    char            memname � 9! ;
    char            ddname  � 9! ;
    char            dsname  �45! ;
    char           *rsvptr1        ;
    char           *rsvptr2        ;
    char           *rsvptr3        ;
    char           *rsvptr4        ;
    char           *rsvptr5        ;
    char           *rsvptr6        ;
    char           *rsvptr7        ;
    char           *rsvptr8        ;
    char           *rsvptr9        ;
    char           *rsvptr10       ;
} FATTRIB;
