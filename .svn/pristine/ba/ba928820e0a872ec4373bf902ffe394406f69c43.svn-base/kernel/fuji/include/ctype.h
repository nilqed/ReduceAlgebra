/* c copyright fujitsu limited 1986                                 */
/********************************************************************/
#define _ALPHA 64
#define _UPPER 32
#define _LOWER 16
#define _DIGIT  8
#define _CONTL  4
#define _PRINT  2
#define _SPACE  1
extern char _isfnc �256!;
extern char atoe �256!;
extern char etoa �256!;
#define isalnum(n) (_isfnc�n!&(_UPPER�_LOWER�_DIGIT))
#define isalpha(n) (_isfnc�n!&(_UPPER�_LOWER))
#define iscntrl(n) (_isfnc�n!&_CONTL)
#define isdigit(n) (_isfnc�n!&_DIGIT)
#define islower(n) (_isfnc�n!&_LOWER)
#define isprint(n) (_isfnc�n!&_PRINT)
#define isspace(n) (_isfnc�n!&_SPACE)
#define isupper(n) (_isfnc�n!&_UPPER)
#define _tolower(n) ((n)-_ALPHA)
#define _toupper(n) ((n)+_ALPHA)
