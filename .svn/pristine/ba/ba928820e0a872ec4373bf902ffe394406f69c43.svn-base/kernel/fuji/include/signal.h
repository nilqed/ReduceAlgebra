/* c copyright fujitsu limited 1986                                 */
void (*signal())() ;
#define SIG_DFL ((void (*)())0)
#define SIG_IGN ((void (*)())1)
#define SIG_ERR ((void (*)())(-1))
#define SIGINT 2
#define SIGILL 3
#define SIGFPE 4
#define SIGSEGV 5
#define SIGABRT 6
#define SIGSYS 7
