/* 
 * sigs.c - External routines to deal with signals
 * 
 * Author:	Leigh Stoller
 
 * 		University of Utah
 * Date:	18-Aug-1986
 * 
 */

#include <signal.h>
#include <setjmp.h>
 
jmp_buf paket;
jmp_buf hpaket;

void hhugo(a)
   int a;
   {int i,j; int stk;
    if(a==SIGABRT) printf("Signal abort\n");
    if(a==SIGFPE) printf("Signal floating point exception\n");
    if(a==SIGILL) printf("Signal illegal instruction\n");
    if(a==SIGINT) printf("Signal interrupt\n");
    if(a==SIGSEGV) printf("Signal segmentation violation\n");
       setjmp(hpaket); stk=hpaket[14];  /* reg 13 */
     for(i=0;i<=3435;i++)
       if((unsigned) hpaket[i] == (unsigned) 0xf0000080) {
     		 printf("nil in %d \n ",i);
		 for (j=i-10;j<i+7;j++)
		  printf(" %d %x \n",j,hpaket[j]);}

       for(i=1;i<=3;i++) 
         stk = * ((int*) (stk+4));
    printf("error stack: %x\n",stk);
    printf ("GP registers:\n");
    for (i=0;i<14;i++)
     {if (i%4 == 0) printf("%dR:%dR : ",i,i+3);
      printf("%x ", * ((int*)(stk+20+i*4))); 
      if ((i+1)%4 == 0) printf("\n");
     };
     printf ("%x %x\n",* ((int*)(stk+12)), * ((int*)(stk+16)));
     exit(-1);
   }
          
versuch()
   { 
     signal(SIGABRT,hhugo);
     signal(SIGFPE,hhugo);
     signal(SIGILL,hhugo);
     signal(SIGINT,hhugo);
     signal(SIGSEGV,hhugo);
   }

/* Tag( psl_sigset )
 */
psl_sigset( sig, action ) 
void (*action)();
int sig;
{
  if (signal(sig, SIG_IGN) != SIG_IGN)
    signal(sig, action);

}


/* Tag( sigrelse )
 */
sigrelse(sig, action)
void (*action)();
int sig;
{
  signal(sig, action); 
}
