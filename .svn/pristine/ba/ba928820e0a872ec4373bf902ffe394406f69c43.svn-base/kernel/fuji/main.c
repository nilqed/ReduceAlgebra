 #include <stdio.h>

 suppe (x,y,z)
    int x,y,z;
    @( x=y+z+r;
      return(z);
    @)

psl_main(argc,argv)
    int argc; char * argv  ;
    @(
       suppe(17,4,1);
       exit(1);
    @)

