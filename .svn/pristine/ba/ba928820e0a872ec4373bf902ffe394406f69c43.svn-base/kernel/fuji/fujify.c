#include <stdio.h>

/* C Quelle in FUJI code umsetzen */
 

main ()
  { int i,j,k,l;
    char c;
   loop:
    while ((c=getchar()) >0)
         if(c =='{') {putchar('@'); putchar('('); }
    else if(c =='}') {putchar('@'); putchar(')'); }
    else if(c =='[') {putchar('@'); putchar('<'); }
    else if(c ==']') {putchar('@'); putchar('>'); }
    else if(c =='@') {putchar('@'); putchar('@'); }
    else if('A' <= c && c <='Z')
        {putchar('@'); putchar('\''); putchar(c); putchar('\'');}
    else putchar(c);
   }

