extern long firstker[],lastker[];
int i,k;
unsigned * ptr;
unsigned j;

main()
   {printf("hello, IBM-world of f....\n\nhello Berlin\n");
    /* kleinup(); */
    
    printf("firstker: %x %d lastker: %x %d\n",
       &firstker[0],&firstker[0],&lastker[0],&lastker[0]);
    k=-36;
    i=(int)&firstker[0];
    for(k=-36;k<=0;k++)
    {
      ptr = (unsigned*)(k+i);
      j = *ptr;
      printf("%x : %x %d\n",k+i,j,j);
    };
    printf("nach UP-Aufruf\n");
    }
