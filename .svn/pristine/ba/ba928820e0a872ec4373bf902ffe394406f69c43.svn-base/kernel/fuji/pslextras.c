/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         PXK:PSLEXTRAS.C
% Description:  Miscellaneous support routines.
% Author:       RAM, HP/FSD
% Created:      9-Mar-84
% Modified:     21-Mar-85 11:25:52
% Mode:         Text
% Package:      
% Status:       Experimental (Do Not Distribute)
%
% (c) Copyright 1984, Hewlett-Packard Company, all rights reserved.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
% 05-Apr-88 (Julian Padget)
%  Reinstated alarm and ualarm (again)
% 29-May-87 (Leigh Stoller & Harold Carr)
%  Added e_setenv and friends.
% 21-Mar-85 11:09:00 (Scott Marovich)
%  Rewrite "timc()" to return time since 1st call, and never cream LISP tag.
% 21-Feb-85 09:02:49 (Vicki O'Day)
%  Fixed bug in uxwritefloat - it was setting the length field of the printable
%  string incorrectly.
% 18-Jul-84 11:14:24 (RAM)
%  Added e_time.  Put call to expand_file_name in e_stat,
%  e_link, and e_unlink.
% 10-Jul-84 (Vicki O'Day)
%  Added e_stat, e_link and e_unlink.
% 29-Jun-84 14:15:53 (RAM)
%  Removed hp_quit (obsolete).
% 27-Jun-84 (Vicki O'Day)
%  Added e_strlen and e_getenv.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <time.h>
#include <string.h>

int e_alarm(sec)
unsigned long sec;
{
}

int e_ualarm(usec,repeat)
unsigned long usec,repeat;
{
}

char *expand_file_name();	/* from unix-io.c */
long time(), times();		/* from kernel */

/* Tag( e_time )
 */

time_t e_time(tloc)
time_t *tloc;
{ 
  return (time(tloc));
}


/* Tag( external_timc )
 */
#define HZ  60

e_timc(buffer)
     struct tms *buffer;
{ times(buffer);
  (*buffer).tms_utime = ((50 * (*buffer).tms_utime / HZ)) * 20;
  return(0);
}


/* Tag( e_stat )
 */
int e_stat(path, buf)
char *path;
struct stat *buf;
{
    return stat(expand_file_name(path), buf);
}

/* Tag( e_link )
 */
int e_link (path1, path2)
char *path1, *path2;
{
}

/* Tag( e_unlink )
 */
int e_unlink (path)
char *path;
{
}

/* Tag( e_strlen )
 */
int e_strlen (s)
     char *s;
{
    return strlen(s);
}

/* Tag( e_getenv )
 */
char *e_getenv (name)
     char *name;
{
    return (char *)getenv(name);
}


int e_setenv (var, val)
    char *var, *val;
{
}

setenv (var, value)
     char *var, *value;
{
}

block_copy (b1, b2, length)
     char *b1, *b2;
     int length;
{
  while (length-- > 0)
    *b2++ = *b1++;
}

#define LISPEOF  4      /* Lisp uses ctrl-D for end of file */

/* Tag( unixreadrecord )
 */
int unixreadrecord(fp, buf)
     FILE *fp;
     char *buf;
{
  int i;
  char c;
  for (i=0, c=' '; ((c != LISPEOF) && (c != '\n')); i++)
    {
      c = fgetc(fp);
      if (c == EOF )
	c = LISPEOF;
      *buf++ = c;
    }
  return i;
}

/* Tag( unixwriterecord )
 */
int unixwriterecord(fp, buf, count)
     FILE *fp;
     char *buf;
int  count;
{
  int i;
  for (i=0; i<count; i++, buf++)
    fputc(*buf, fp);
}





