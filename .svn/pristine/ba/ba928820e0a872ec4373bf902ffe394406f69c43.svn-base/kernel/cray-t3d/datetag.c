char * datetag ()
  { return ( 
" Wed Jun 14 15:24:34 1995 "
           ); } 
