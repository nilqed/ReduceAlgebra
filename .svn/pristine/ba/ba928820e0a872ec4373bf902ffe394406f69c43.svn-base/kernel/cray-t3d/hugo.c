#include <stdio.h>

kuno (x)
int x;

{ return (0);}

hugo (x)
int x;

{ long y; int i;
  long* ad;
 long zz;
  y = 20;
  ad  = &y;
printf ("Alles hugo oder was %lx\n",&y);
  for(i=0;i<50;i++) { ad+= 1;
                      zz = *ad;
		printf("%lx: %lx \n", ad ,*ad);};
 }

int aa[1];

main()

{  int cc;
   cc = -100000;
   signal(31,hugo);
   hugo (20);
   kuno(aa[cc]);
}
