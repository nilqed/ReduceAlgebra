/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         bpsheap.c
% Description:  Code to dynamically set up bps and heap structures
% Author:       RAM, HP/FSD
% Created:      9-Mar-84
% Modified:
% Mode:         Text
% Package:
%
% (c) Copyright 1987, University of Utah, all rights reserved.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

#include <stdio.h>

#define MINHEAPSIZE    1000000  
#define BPSSIZE        2800000 
#define BPSRESERVE     1000000
#define NUMBEROFHEAPS  2

int     alreadysetbpsandheap;
int     max_image_size;
int     obreakvalue;
int     bpsupperbound;
int     oldbps;
int     memhigh;

extern int  alreadysetbpsandheap;
extern int  lastbps;
extern int  nextbps;
extern int  bpslowerbound;
extern int  _infbitlength_;

extern int  heaplowerbound;
extern int  heapupperbound;
extern int  heaplast;
extern int  heaptrapbound;

extern int  oheaplowerbound;
extern int  oheapupperbound;
extern int  oheaplast;
extern int  oheaptrapbound;

  /* from os-hooks */
extern int bpssize,heapsize;
extern char * image,* kerneldir;


static power(x, n)
     int x, n;
{
  int i, p;

  p = 1;
  for (i = 1; i <= n; ++i)
    p = p * x;
  return(p);
}

setbpsandheap(argc,argv)
     int argc;
     char *argv[];
{
  int    i;
  int current_size_in_bytes;
  int total;
  char * membase; int memsize,memoffs,memhigh;

  if (image!=NULL) 
image_hdr();

  /* insure valid values */
  bpssize = BPSSIZE;

  if (heapsize == 0)
    heapsize = MINHEAPSIZE;


  max_image_size = power(2, _infbitlength_) - 4; 

  heapsize =(heapsize / 8) * 8;  /* ensure full words */
  bpssize =(bpssize / 4) * 4;
  heapsize =heapsize / NUMBEROFHEAPS;

        /* allocate total memory */
  memoffs= BPSRESERVE;
 
  memsize= bpssize+heapsize*NUMBEROFHEAPS+memoffs+8;
  membase = (char*)malloc(memsize);

  if ((int)membase <= 0) { 
       printf("*** HEAP not available (region too small?)\n"); 
       exit(-1); };

  memhigh = (int)membase + memsize;
  if (memhigh > max_image_size) memhigh = max_image_size-4;

       /* true final offset */
  if (image!=NULL) memoffs= memoffset(oldbps,(int)membase);
           else memoffs= BPSRESERVE;

         /* bps pointers */
  bpslowerbound = (int)membase+memoffs;
  nextbps=bpslowerbound;
  bpsupperbound  = bpslowerbound+bpssize;
  lastbps = bpsupperbound;

         /* heap pointers */
  heaplowerbound = lastbps+4;
  heapsize = (memhigh - heaplowerbound)/NUMBEROFHEAPS;
  heapsize =(heapsize / 4) * 4;
  heapupperbound        = heaplowerbound + heapsize;
  heaplast              = heaplowerbound;
  heaptrapbound         = heapupperbound -120;

  oheaplowerbound    = heapupperbound;
  oheapupperbound     = oheaplowerbound + heapsize;
  oheaplast           = oheaplowerbound;
  oheaptrapbound      = oheapupperbound -120;

  memhigh             = oheaptrapbound+4;
  obreakvalue = 0;

  if (image!=NULL) image_body();
  printf("heap size: %d LISP items\n", heapsize/4);
  heapsize =heapsize * NUMBEROFHEAPS;

}

int memoffset(oldbase,actbase)
    int oldbase,actbase;
   {int d;
    d=oldbase-actbase;
    if (d<0)
    {printf("old bps %x below current free memory start %x\n",
                                   oldbase,actbase);
     printf("   cannot load image\n");
     exit(-1);};
     /* printf("memory gap: %x = %d\n",d,d); */
     return(d);
   }



allocatemorebps()
{
  int increment,x;
  char * base;
  increment= BPSSIZE/2;
  x = memhigh + increment;
  x = x % 0x7ffffff;
  increment= x - memhigh;
  increment= (increment >> 2) << 2;
  if(increment<50000)
    {printf("current model does not allow more BPS\n");
     return(-1);};
  base=(char*)malloc(increment);
  if(base==NULL)
    {printf("Operating System refuses more memory for BPS\n");
     return(-1);}
  bpslowerbound=(int) base;
  bpsupperbound=bpslowerbound+increment;
  memhigh = memhigh + increment;
  return(increment);
}


/* Tag( alterheapsize )
 */
alterheapsize(increment)
int increment;
{
}
