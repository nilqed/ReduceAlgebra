/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:         PXK:PSLEXTRAS.C
% Description:  Miscellaneous support routines.
% Author:       RAM, HP/FSD
% Created:      9-Mar-84
% Modified:     21-Mar-85 11:25:52
% Mode:         Text
% Package:      
% Status:       Experimental (Do Not Distribute)
%
% (c) Copyright 1984, Hewlett-Packard Company, all rights reserved.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Revisions:
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

#include <stdio.h>
#include <time.h>
#include <string>

int e_alarm(sec)
unsigned long sec;
{
}

int e_ualarm(usec,repeat)
unsigned long usec,repeat;
{
}

char *expand_file_name();	/* from unix-io.c */
long time(), times();		/* from kernel */

/* Tag( e_time )
 */

char * e_time(tloc)
time_t *tloc;
{ char * hilf;
  time(tloc);
  hilf = ctime (tloc);
  rueckcod (hilf,tloc);
  return ((char *) tloc);
}


/* Tag( e_timc )
 */
static unsigned long  altclock;

e_timc(buffer)
  /* IBM:: */
   unsigned long *buffer;
{
  if(buffer ==0) { altclock = clock(); return (0);}

  *buffer = (clock() - altclock) /(CLOCKS_PER_SEC/1000);
  return(0);
}

/* Tag( e_stat )
 */
int e_stat(path, buf)
char *path;
struct stat *buf;
{
}

/* Tag( e_link )
 */
int e_link (path1, path2)
char *path1, *path2;
{
}

/* Tag( e_unlink )
 */
int e_unlink (path)
char *path;
{
}

/* Tag( e_strlen )
 */
int e_strlen (s)
     char *s;
{
    return strlen(s);
}

/* Tag( e_getenv )
 */
char *e_getenv (name)
     char *name;
{
}


int e_setenv (var, val)
    char *var, *val;
{
}

setenv (var, value)
     char *var, *value;
{
}

block_copy (b1, b2, length)
     char *b1, *b2;
     int length;
{
  while (length-- > 0)
    *b2++ = *b1++;
}

#define LISPEOF  4      /* Lisp uses ctrl-D for end of file */

/* Tag( unixreadrecord )
 */
int unixreadrecord(fp, buf)
     FILE *fp;
     char *buf;
{
  int i;
  char c;
  for (i=0, c=' '; ((c != LISPEOF) && (c != '\n')); i++)
    {
      c = fgetc(fp);
      if (c == EOF )
	c = LISPEOF;
      *buf++ = c;
    }
  return i;
}

/* Tag( unixwriterecord )
 */
int unixwriterecord(fp, buf, count)
     FILE *fp;
     char *buf;
int  count;
{
  int i;
  for (i=0; i<count; i++, buf++)
    fputc(*buf, fp);
}

